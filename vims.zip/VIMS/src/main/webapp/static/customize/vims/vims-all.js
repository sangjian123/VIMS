;
(function($, app) {
	"use strict";
	
	app.controller("BasicInfoCtrl", function($scope, $http) {
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("HistoryTrackCtrl", function($scope, $http,$map,$document) {
		$scope.accountList=[{key:"仅显示在线车辆",value:1},{key:"仅显示离线车辆",value:2}];
		
		$map.load().then(function(){
				var map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
				map.clearOverlays();
				// 获取点坐标集
				var points = [  
				              new BMap.Point(121.533615,31.277752),  // 始点
				              new BMap.Point(121.536615,31.274752),  
				              new BMap.Point(121.535615,31.276752),  
				              new BMap.Point(121.537615,31.278752),  
				              new BMap.Point(121.5356439,31.2810635) // 终点 
				            ];  
				
				var p = Math.ceil(points.length / 2);// 设置中心点
				map.centerAndZoom(new BMap.Point(points[p].lng, points[p].lat), 15);
				map.enableScrollWheelZoom();
				map.addControl(new BMap.NavigationControl());
				map.addControl(new BMap.ScaleControl());
				map.addControl(new BMap.OverviewMapControl());
				map.addControl(new BMap.MapTypeControl());
				
				// 定义一个控件类,即function
			    function ZoomControl(){
			      // 默认停靠位置和偏移量
			      this.defaultAnchor = BMAP_ANCHOR_TOP_LEFT;
			      this.defaultOffset = new BMap.Size(60, 15); // 距离左上角位置
			    }

			    // 通过JavaScript的prototype属性继承于BMap.Control
			    ZoomControl.prototype = new BMap.Control();

			    // 自定义控件必须实现自己的initialize方法,并且将控件的DOM元素返回
			    // 在本方法中创建个div元素作为控件的容器,并将其添加到地图容器中
			    ZoomControl.prototype.initialize = function(map){
			      // 创建一个DOM元素
			      var div = document.createElement("div");
			      // 添加文字说明
			      div.appendChild(document.createTextNode("播放/重播"));
			      // 设置样式
			      div.className="BMapbtn";
			      // 绑定事件,点击一次放大两级
			      div.onclick = function(e){
			    	  lushu.start();//	map.setZoom(map.getZoom() + 2); // 放大2倍
			      }
			      // 添加DOM元素到地图中
			      map.getContainer().appendChild(div);
			      // 将DOM元素返回
			      return div;
			    }
			    // 创建控件
			    var myZoomCtrl = new ZoomControl();
			    // 添加到地图当中
			    map.addControl(myZoomCtrl);
				
				//	map.setCurrentCity("北京"); // 仅当设置城市信息时，MapTypeControl 的切换功能才能可用
				// 行车轨迹线
				var polyline = new BMap.Polyline(points, {strokeColor:"red", strokeWeight:5, strokeOpacity:0.5});  
			    map.addOverlay(polyline); 
			    map.setViewport(points);
	            var lushu = new BMapLib.LuShu(map,points,{
	                defaultContent:"苏A88888",//"从天安门到百度大厦"
	                autoView:true,//是否开启自动视野调整，如果开启那么路书在运动过程中会根据视野自动调整
	                icon  : new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34)),
	                speed: 500,
	                enableRotation:true//是否设置marker随着道路的走向进行旋转
	            });
		});
		
	    function drawMarker(point, angle,map) {  
	        var iconImg = new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34));  
	        var marker = new BMap.Marker(point, { icon : iconImg });
	        var label = new BMap.Label('苏A88888', {offset: new BMap.Size(-15, -20)}); //创建marker点的标记
			marker.setLabel(label);
			marker.setRotation(angle);
	        map.addOverlay(marker);  
	        marker.addEventListener("click", function(){
				drawInfoWindow(marker);
			 });
	    }  
	    
	    //获得开始坐标和终点坐标连线，与y轴正半轴之间的夹角
	    function getAngle(pointStart,pointEnd){
	        var px=pointStart.lat,py=pointStart.lng,mx=pointEnd.lat,my=pointEnd.lng;
	    	var x = Math.abs(px-mx);
	        var y = Math.abs(py-my);
	        var z = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
	        var cos = y/z;
	        var radina = Math.acos(cos);//用反三角函数求弧度
	        var angle = Math.floor(180/(Math.PI/radina));//将弧度转换成角度
	        //鼠标在第四象限
	        if(mx>px&&my>py){ angle = 180 - angle; }
	        //鼠标在y轴负方向上
	        if(mx==px&&my>py){ angle = 180; }
	        //鼠标在x轴正方向上
	        if(mx>px&&my==py){ angle = 90; }
	        //鼠标在第三象限
	        if(mx<px&&my>py){ angle = 180+angle; }
	        //鼠标在x轴负方向
	        if(mx<px&&my==py){ angle = 270; }
	        //鼠标在第二象限
	        if(mx<px&&my<py){ angle = 360 - angle; }
	        return angle;
	    }
		
		function drawInfoWindow(marker){
			var opts={
					height:100,
					width:250,
					title:'标题'
			}
			var infoWindow = new BMap.InfoWindow("World",opts); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("HomeCtrl", function($scope, $http,$state) {
		var firstPage = "vimsportal";
		$scope.tabsContents=[
		                     {name:"基本资料",stateName:"vimsportal.basicInfo"},
		                     {name:"管理调度",stateName:"vimsportal.managementSchedue"},
		                     {name:"车辆定位",stateName:"vimsportal.vehiclePosition"},
		                     {name:"历史轨迹",stateName:"vimsportal.historyTrack"},
		                     {name:"电子围栏",stateName:""},
		                     {name:"驻车防盗",stateName:""},
		                     {name:"告警消息",stateName:""},
		                     {name:"运营报表",stateName:""},
		                     {name:"客户服务",stateName:""}
		            ];
		$scope.goState=function(stateName) { $state.go(stateName,{isRouter:true}); }
		$scope.goState(firstPage);// 默认跳转首页
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("LoginCtrl", function($scope, $http) {
		$scope.user={};
		// 点击登陆跳转主页
		$scope.login=function(){
			
			$http.post(basePath + "/doLogin", $scope.user || {}).success(function(result) {
        if (result.success) {
          if($scope.user.loginname == 'root')
          {
            window.location.href = basePath + "/support";
            return;
          } 
          window.location.href = basePath + "/home";
        } else {
          $scope.exception.message = result.msg;
          return;
        }
      })

		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("ManagementSchedueCtrl", function($scope, $http) {
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("VehiclePositionCtrl", function($scope, $http,$map,$document) {
		$scope.accountList=[{key:"仅显示在线车辆",value:1},{key:"仅显示离线车辆",value:2}];
		
		$map.load().then(function(){
			var map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
			map.clearOverlays();
			// 获取点坐标集
			var points = [  
			              new BMap.Point(121.533615,31.277752),  // 始点
			              new BMap.Point(121.536615,31.274752),  
			              new BMap.Point(121.535615,31.276752),  
			              new BMap.Point(121.537615,31.278752),  
			              new BMap.Point(121.5356439,31.2810635) // 终点 
			            ];  
			
			var p = Math.ceil(points.length / 2);// 设置中心点
			map.centerAndZoom(new BMap.Point(points[p].lng, points[p].lat), 15);
			map.enableScrollWheelZoom();
			map.addControl(new BMap.NavigationControl());
			map.addControl(new BMap.ScaleControl());
			map.addControl(new BMap.OverviewMapControl());
			map.addControl(new BMap.MapTypeControl());
			//	map.setCurrentCity("北京"); // 仅当设置城市信息时，MapTypeControl 的切换功能才能可用
		    for (var i = points.length - 1; i > 0; i--){  
		        var angle = getAngle(points[i], points[i-1]); // 获取连接方向
		        drawMarker(points[i], angle,map);
		    } 
		});
		
	    function drawMarker(point, angle,map) {  
	        var iconImg = new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34));  
	        var marker = new BMap.Marker(point, { icon : iconImg });
	        var label = new BMap.Label('苏A88888', {offset: new BMap.Size(-15, -20)}); //创建marker点的标记
			marker.setLabel(label);
			marker.setRotation(angle);
	        map.addOverlay(marker);  
	        marker.addEventListener("click", function(){
				drawInfoWindow(marker);
			 });
	    }  
	    
	    //获得开始坐标和终点坐标连线，与y轴正半轴之间的夹角
	    function getAngle(pointStart,pointEnd){
	        var px=pointStart.lat,py=pointStart.lng,mx=pointEnd.lat,my=pointEnd.lng;
	    	var x = Math.abs(px-mx);
	        var y = Math.abs(py-my);
	        var z = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
	        var cos = y/z;
	        var radina = Math.acos(cos);//用反三角函数求弧度
	        var angle = Math.floor(180/(Math.PI/radina));//将弧度转换成角度
	        //鼠标在第四象限
	        if(mx>px&&my>py){ angle = 180 - angle; }
	        //鼠标在y轴负方向上
	        if(mx==px&&my>py){ angle = 180; }
	        //鼠标在x轴正方向上
	        if(mx>px&&my==py){ angle = 90; }
	        //鼠标在第三象限
	        if(mx<px&&my>py){ angle = 180+angle; }
	        //鼠标在x轴负方向
	        if(mx<px&&my==py){ angle = 270; }
	        //鼠标在第二象限
	        if(mx<px&&my<py){ angle = 360 - angle; }
	        return angle;
	    }
		
		function drawInfoWindow(marker){
			var opts={
					height:100,
					width:250,
					title:'标题'
			}
			var infoWindow = new BMap.InfoWindow("World",opts); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("DeptManagerCtrl", function($scope, $http,$state,$modal) {
		$scope.options={};
		$scope.options.url=basePath + "/static/customize/vims/service/support/data.json";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'ID', field:'ID', visible:false },
                	{ title:'部门名称', field:'deptName'},
                	{ title:'固定电话', field:'telephone', sortable:true },
                	{ title:'部门传真', field:'deptFax', sortable:true },
                	{ title:'上级部门', field:'superDeptName', },
                	{ title:'部门邮箱', field:'deptEmail' },
                	{ title:'创建日期', field:'createTime', sortable:true },
                	{ title:'备注', field:'mark', align:'center' }
            	]
		$scope.addDept=function(){
			$modal.open({
	          	templateUrl:basePath + "/deptInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	controller:function($scope,$modalInstance){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
	          	}
	          });
		}
	})
})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("userModelCtrl", function($scope, $http, $timeout, $compile,
      $element) {

    // 树
    $scope.demo = {};
    $scope.user = {};

    $.ajax({
      type : "POST",
      url : basePath + '/role/tree',
      dataType : "html",
      contentType : "application/json",
      data : JSON.stringify($scope.user),
      async : true,
      success : function(result) {
        if (result) {
          result = JSON.parse(result);
        }
        if (result.success) {
          $timeout(function() {
            $scope.$apply(function() {
              $scope.demo.tree = eval(result.obj.list);
              var checkedData = $.tree($scope.demo.tree).checked;
              var content = [];
              angular.forEach(checkedData, function(data, index) {
                content.push(data.text);
              });
              $scope.content = content.join(",");
            });
          });

        } else {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n
              .prop('ami.role.waring_message'), 'warning');
        }
      }
    });

    $scope.sure = function() {
      var checkedData = $.tree($scope.demo.tree).checked;
      var content = [];
      var roleId = [];
      angular.forEach(checkedData, function(data, index) {
        content.push(data.text);
        roleId.push(data.id);
      });
      $scope.content = content.join(",");
      $scope.user.roleIds = roleId.join(",");

    }
    
 // 新增
    $scope.addUser = function(row) {
      
          $http.post(basePath + "/user/add", $scope.user || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#userTable").datagrid('reload');
            }else{
              $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
            }
          });
        };


  });

})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("OperatorManagerCtrl", function($scope, $http,$state,$modal) {
		$scope.options={};
		$scope.options.url=basePath + "/user/dataGrid";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'ID', field:'id', visible:false },
                	{ title:'用户名', field:'loginname'},
                	{ title:'昵称', field:'nickName', sortable:true },
                	{ title:'所属部门', field:'belongDept', sortable:true },
                	{ title:'电话', field:'phone'},
                	{ title:'角色', field:'roleName'},
                	{ title:'状态', field:'status' },
                	{ title:'创建日期', field:'createdate', sortable:true },
                	{ title:'更新日期', field:'updatedate', sortable:true }
            	]
		$scope.addOperator=function(){
			$modal.open({
	          	templateUrl:basePath + "/user/operatorInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	controller:function($scope,$modalInstance){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); };
	          		 
	          	// 新增
	              $scope.addUser = function(row) {
	                
	                    $http.post(basePath + "/user/add", $scope.user || {}).success(function(result) {
	                      if (result.success) {
	                        alert('保存成功');
	                        $modalInstance.dismiss('cancel'); 
	                      }else{
	                        alert(result.msg);
	                      }
	                    });
	                  };


	          		
	          		
	          	}
	          });
		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("RoleManagerCtrl", function($scope, $http,$state,$modal) {
		$scope.options={};
		$scope.options.url=basePath + "/static/customize/vims/service/support/role.json";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'ID', field:'ID', visible:false },
                	{ title:'名称', field:'roleName'},
                	{ title:'描述', field:'roleDescription', sortable:true },
                	{ title:'所属部门', field:'department', sortable:true },
                	{ title:'类型', field:'roleType', },
                	{ title:'创建日期', field:'createTime', sortable:true }
            	]
		$scope.addRole=function(){
			$modal.open({
	          	templateUrl:basePath + "/roleInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	controller:function($scope,$modalInstance){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
	          	}
	          });
		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("SupportCtrl", function($scope, $http,$state) {
		var firstPage = "vimssupport";
		
		$scope.menus =[
					                 {
					                  id:'1000',name:'组织与权限',children:[
											                                                   {id:'10001',name:'角色管理',stateName:'vimssupport.roleManager'},
											                                                   {id:'10002',name:'部门管理',stateName:'vimssupport.deptManager'},
											                                                   {id:'10003',name:'操作员管理',stateName:'vimssupport.operManager'},
											                                                   {id:'10004',name:'工作流管理',stateName:'vimssupport.workflowManager'}
											                                                ]
					                 },
					                 {
					                	 id:'1002',name:'设备管理',children:[
									 		                                                   {id:'10021',name:'绑定设备与车辆',stateName:''},
									 		                                                   {id:'10022',name:'设备分组管理',stateName:''},
									 		                                                   {id:'10023',name:'设备参数一键设定',stateName:''}
									 		                                                ]
					                 }
					              ];
		  $scope.tabsContents=[];
		  $scope.param={};
		  $scope.tabs=function(tab)
		  {
			  if($scope.tabsContents.indexOf(tab) <= -1) { $scope.tabsContents.push(tab); }	  
			  $scope.param.active = $scope.tabsContents.indexOf(tab);
			  $scope.goState(tab.stateName);
		  }
		  $scope.closeTab=function(tab,index)
		  {
			  if(index <= $scope.param.active)$scope.param.active--;
			  $scope.tabsContents.remove(tab);
			  var tab = $scope.tabsContents[$scope.param.active];
			  $scope.goState(tab ? tab.stateName : firstPage);
		  }
		  $scope.goState=function(stateName) { $state.go(stateName ? stateName : firstPage,{isRouter:true}); }
		  $scope.goState(firstPage);// 默认跳转首页
	})
})(jQuery, app);(function($,app){
    "use strict";
    
    app
    .service("$messager",function($templateCache,$modal){
     var template =[
    	'<div class="modal-header">',
			'<button type="button" class="close" ng-click="close()">&times;</button>',
			'<h4 class="modal-title" ng-bind="title"></h4>',
		'</div>',
		'<div class="modal-body full-width" style="display:inline-block;padding:10px;">',
			'<div class="col-sm-2">',
				'<span ng-if="type==0" class="glyphicon glyphicon-ok-sign" style="font-size:32px;color:#1AA260;"></span>',
				'<span ng-if="type==1" class="glyphicon glyphicon-remove-sign" style="font-size:32px;color:#CF2008;"></span>',
				'<span ng-if="type==2" class="glyphicon glyphicon-exclamation-sign" style="font-size:32px;color:#FDC640;"></span>',
				'<span ng-if="type==3" class="glyphicon glyphicon-question-sign" style="font-size:32px;color:#1AA260;"></span>',
			'</div>',
			'<div class="col-sm-10" ng-bind-html="html" style="margin-top:8px;font-size:14px;"></div>',
		'</div>',
		'<div class="modal-footer" style="margin-top:0;padding:8px;">',
			'<button ng-if="type==2 || type==3" type="button" style="width:60px;margin-top:0;padding:5px;" class="btn btn-login" ng-click="close()">取消</button>',
			'<button type="button" style="width:60px;margin-top:0;padding:5px;" class="btn btn-login" ng-click="sure()">确定</button>',
		'</div>'
		].join("");
    	function newModal(type,$modal,title,html,callback){
    		$modal.open({
    	        template: template,
    	        scope: false,
    	        backdrop: 'static',
    	        keyboard: true,
    	        size: "sm",
    	        controller: function($scope, $modalInstance,$sce) {
    	          $scope.title=title;
    	          $scope.type=type;
    	          $scope.html=$sce.trustAsHtml(html);
    	          $scope.close=function() {$modalInstance.dismiss('cancel');}
    	          $scope.sure=function(){$modalInstance.dismiss('cancel');(callback || angular.noop)($scope,$modalInstance);}
    	        }
    	   });
    	}
    		
    	return {
    		success:function(title,content,callback){newModal(0,$modal,title,content,callback);},//成功提示框
    		error:function(title,content){newModal(1,$modal,title,content);},// 失败提示框
    		warning:function(title,content,callback){newModal(2,$modal,title,content,callback);},//警告提示框
    		confirm:function(title,content,callback){newModal(3,$modal,title,content,callback);}//消息确认框
    	}	
    })
    .service('$map', function($window, $document, $q){
    	  var promise;
    	  this.load = function(){
    	      if(promise){ return promise; }
    	      promise = $q(function(resolve, reject){
    	          $window.initMap = function(){ 
    	        	  //加载maplushu.js,成功后，并执行回调函数
    	        	  $.getScript(basePath + "/static/customize/vims/maplushu.js",function(){ 
    	        		  resolve();
    	        	  });
    	        	  return; 
    	         };
    	          var script = document.createElement("script"); 
    	          script.type = "text/javascript";
    	          script.src = "http://api.map.baidu.com/api?v=2.0&ak=ktMifslxsKlszjkciuhGDaVFb4TTHwt6&callback=initMap";
    	          $document[0].body.appendChild(script);
    	      });
    	      return promise;
    	  };
   });
})(jQuery,app)