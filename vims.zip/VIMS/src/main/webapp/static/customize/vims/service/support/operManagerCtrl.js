;
(function($, app) {
	"use strict";
	
	app.controller("OperatorManagerCtrl", function($scope, $http,$state,$modal) {
		$scope.options={};
		$scope.options.url=basePath + "/user/dataGrid";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'ID', field:'id', visible:false },
                	{ title:'用户名', field:'loginname'},
                	{ title:'昵称', field:'nickName', sortable:true },
                	{ title:'所属部门', field:'belongDept', sortable:true },
                	{ title:'电话', field:'phone'},
                	{ title:'角色', field:'roleName'},
                	{ title:'状态', field:'status' },
                	{ title:'创建日期', field:'createdate', sortable:true },
                	{ title:'更新日期', field:'updatedate', sortable:true }
            	]
		$scope.addOperator=function(){
			$modal.open({
      	templateUrl:basePath + "/user/operatorInfo",
      	scope:false,
      	backdrop:'static',
      	keyboard:true,
      	size:"defalut",
      	controller:function($scope,$modalInstance){
      		$scope.close=function(){ $modalInstance.dismiss('cancel'); };
      		 
      	// 新增
          $scope.addUser = function() {
            
                $http.post(basePath + "/user/add", $scope.user || {}).success(function(result) {
                  if (result.success) {
                    alert('保存成功');
                    $modalInstance.dismiss('cancel'); 
                  }else{
                    alert(result.msg);
                  }
                });
              };
      	}
	    });
		}
		
	})
})(jQuery, app)