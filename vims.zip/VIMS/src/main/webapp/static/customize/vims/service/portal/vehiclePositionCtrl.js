;
(function($, app) {
	"use strict";
	
	app.controller("VehiclePositionCtrl", function($scope, $http,$map,$document) {
		$scope.accountList=[{key:"仅显示在线车辆",value:1},{key:"仅显示离线车辆",value:2}];
		
		$map.load().then(function(){
			var map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
			map.clearOverlays();
			// 获取点坐标集
			var points = [  
			              new BMap.Point(121.533615,31.277752),  // 始点
			              new BMap.Point(121.536615,31.274752),  
			              new BMap.Point(121.535615,31.276752),  
			              new BMap.Point(121.537615,31.278752),  
			              new BMap.Point(121.5356439,31.2810635) // 终点 
			            ];  
			
			var p = Math.ceil(points.length / 2);// 设置中心点
			map.centerAndZoom(new BMap.Point(points[p].lng, points[p].lat), 15);
			map.enableScrollWheelZoom();
			map.addControl(new BMap.NavigationControl());
			map.addControl(new BMap.ScaleControl());
			map.addControl(new BMap.OverviewMapControl());
			map.addControl(new BMap.MapTypeControl());
			//	map.setCurrentCity("北京"); // 仅当设置城市信息时，MapTypeControl 的切换功能才能可用
		    for (var i = points.length - 1; i > 0; i--){  
		        var angle = getAngle(points[i], points[i-1]); // 获取连接方向
		        drawMarker(points[i], angle,map);
		    } 
		});
		
	    function drawMarker(point, angle,map) {  
	        var iconImg = new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34));  
	        var marker = new BMap.Marker(point, { icon : iconImg });
	        var label = new BMap.Label('苏A88888', {offset: new BMap.Size(-15, -20)}); //创建marker点的标记
			marker.setLabel(label);
			marker.setRotation(angle);
	        map.addOverlay(marker);  
	        marker.addEventListener("click", function(){
				drawInfoWindow(marker);
			 });
	    }  
	    
	    //获得开始坐标和终点坐标连线，与y轴正半轴之间的夹角
	    function getAngle(pointStart,pointEnd){
	        var px=pointStart.lat,py=pointStart.lng,mx=pointEnd.lat,my=pointEnd.lng;
	    	var x = Math.abs(px-mx);
	        var y = Math.abs(py-my);
	        var z = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
	        var cos = y/z;
	        var radina = Math.acos(cos);//用反三角函数求弧度
	        var angle = Math.floor(180/(Math.PI/radina));//将弧度转换成角度
	        //鼠标在第四象限
	        if(mx>px&&my>py){ angle = 180 - angle; }
	        //鼠标在y轴负方向上
	        if(mx==px&&my>py){ angle = 180; }
	        //鼠标在x轴正方向上
	        if(mx>px&&my==py){ angle = 90; }
	        //鼠标在第三象限
	        if(mx<px&&my>py){ angle = 180+angle; }
	        //鼠标在x轴负方向
	        if(mx<px&&my==py){ angle = 270; }
	        //鼠标在第二象限
	        if(mx<px&&my<py){ angle = 360 - angle; }
	        return angle;
	    }
		
		function drawInfoWindow(marker){
			var opts={
					height:100,
					width:250,
					title:'标题'
			}
			var infoWindow = new BMap.InfoWindow("World",opts); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
		}
	})
})(jQuery, app)