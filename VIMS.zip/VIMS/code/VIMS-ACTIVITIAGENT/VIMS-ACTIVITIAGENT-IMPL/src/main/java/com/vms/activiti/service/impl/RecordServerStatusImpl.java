package com.icss.ebu.ami.activiti.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.icss.ebu.ami.activiti.mapper.RecordServerStatusMapper;
import com.icss.ebu.ami.activiti.service.RecordServerStatusService;

@Service
@Transactional
public class RecordServerStatusImpl implements RecordServerStatusService
{
    
    @Autowired
    private RecordServerStatusMapper recordServerStatusMapper;
    
    @Override
    public void recordServerStatus (Map <String, Object> map)
    {
        recordServerStatusMapper.recordServerStatus (map);
    }
    
}
