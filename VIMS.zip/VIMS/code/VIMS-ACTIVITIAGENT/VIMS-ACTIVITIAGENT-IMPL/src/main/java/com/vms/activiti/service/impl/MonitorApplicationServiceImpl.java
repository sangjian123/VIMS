package com.icss.ebu.ami.activiti.service.impl;

import org.springframework.stereotype.Component;

import com.alibaba.dubbo.config.annotation.Service;
import com.icss.ebu.ami.activiti.service.MonitorApplicationService;

@Service
@Component ("monitorApplicationService")
public class MonitorApplicationServiceImpl implements MonitorApplicationService
{
    
    @Override
    public String visit ()
    {
        return "visit success";
    }
    
}
