package com.icss.ebu.ami.activiti.core.task;

import java.io.InputStream;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.icss.ebu.ami.commons.aspect.MyJedis;
import com.icss.ebu.ami.commons.constants.ConfigHolder;
import com.icss.ebu.ami.commons.exception.ServiceException;
import com.icss.ebu.ami.commons.util.AesKeyUtils;
import com.icss.ebu.ami.commons.util.ObjectUtils;

public class SystemInit implements ServletContextListener
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(SystemInit.class);
    
    private static WebApplicationContext ctx = null;
    
    private static void setCtx(WebApplicationContext context)
    {
        ctx = context;
    }
    
    public static WebApplicationContext getWebApplicationContext()
    {
        return ctx;
    }
    
    public void init()
    {
        LOGGER.info("system init!!");
        // 初始化系统配置项
        try
        {
            getConfiguration("configuration.properties");
            getConfiguration("redisConfig.properties");
            getConfiguration("dubbo-config.properties");
        }
        catch (Exception e)
        {
            LOGGER.error("Initialized configuration。properties Fail.", e);
        }
        
        String ipAndPorts = ConfigHolder.getCfg("redisCluster");
        String[] ipAndPortArr = ipAndPorts.split(",");
        String requirepass = AesKeyUtils.decrypt(ConfigHolder.getCfg("REDIS_PASSWORD"), ConfigHolder.getCfg("REDIS_PWD_KEY"));
        MyJedis.init(ipAndPortArr, requirepass);
        loadThread("recordServerStatusThread");
    }
    
    private void loadThread(String name)
    {
        
        Runnable dicInit = (Runnable) (ctx.getBean(name));
        Map<String, String> param = ObjectUtils.parseParam("Thread", name);
        if(dicInit != null)
        {
            // 加载数据字典加载线程
            Thread initThread = new Thread(dicInit);
            initThread.setName(name);
            initThread.setDaemon(true);
            initThread.start();
            LOGGER.info("Load data thread started.", param);
        }
        else
        {
            LOGGER.error("Can't find load data thread.", param);
        }
    }
    
    /**
     * 读取系统配置文件 并缓存到系统内存中去
     */
    private void getConfiguration(String fileName)
    {
        InputStream inputStream = null;
        try
        {
            Properties p = new Properties();
            inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
            p.load(inputStream);
            for(Entry<Object, Object> entry : p.entrySet())
            {
                ConfigHolder.setCfg((String) entry.getKey(), (String) entry.getValue());
            }
        }
        catch (Exception e)
        {
            throw new ServiceException(e.getMessage(), e);
        }
        finally
        {
            IOUtils.closeQuietly(inputStream);
        }
    }
    
    @Override
    public void contextInitialized(ServletContextEvent sce)
    {
        setCtx(WebApplicationContextUtils.getRequiredWebApplicationContext(sce.getServletContext()));
        init();
    }
    
    @Override
    public void contextDestroyed(ServletContextEvent sce)
    {
        
    }
    
}
