package com.icss.ebu.ami.activiti.mapper;

import java.util.List;

import com.icss.ebu.ami.activiti.bean.model.ProcessDefinition;
import com.icss.ebu.ami.activiti.bean.model.ProcessInstance;
import com.icss.ebu.ami.activiti.bean.model.WorkFlow;
import com.icss.ebu.ami.commons.pagePlugin.Page;

public interface activitiFlowMapper
{
    
    /**
     * 修改用户
     *
     * @param user
     * @return
     */
    int updateIdBySapp (Long id, Long appid);
    
    WorkFlow queryFlowUser (String processInstance);
    
    int updateAssigneeById (String id, String name);
    
    List <String> queryFlowKey ();
    
    WorkFlow queryFlowUserQe (WorkFlow workFlowQe);
    
    List <WorkFlow> queryProcessNameByPage ();
    
    List <WorkFlow> queryStepName (WorkFlow workFlow);
    
    List <ProcessDefinition> processManageList (Page <ProcessDefinition> page);
    
    List <ProcessInstance> processInstanceList (Page <ProcessInstance> page);
}