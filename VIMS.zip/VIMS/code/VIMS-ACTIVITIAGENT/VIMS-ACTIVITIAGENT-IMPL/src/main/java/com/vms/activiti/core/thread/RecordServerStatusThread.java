package com.icss.ebu.ami.activiti.core.thread;

import java.net.SocketException;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.icss.ebu.ami.activiti.service.RecordServerStatusService;
import com.icss.ebu.ami.commons.constants.ConfigHolder;
import com.icss.ebu.ami.commons.constants.ServiceConstant;
import com.icss.ebu.ami.commons.util.LocalTool;
import com.icss.ebu.ami.commons.util.SeviceIdUtils;

/**
 * 应用启动时记录
 */
public class RecordServerStatusThread implements Runnable
{
    private static final Logger LOGGER = LoggerFactory.getLogger(RecordServerStatusThread.class);
    
    @Autowired
    private RecordServerStatusService recordServerStatusService;
    
    @Override
    public void run()
    {
        recordServerStatus();
    }
    
    /**
    * 记录服务器启动日志状态、url等
    */
    private void recordServerStatus()
    {
        String deployName = ConfigHolder.getCfg("dubbo.application.name");
        String port = ConfigHolder.getCfg("dubbo.protocol.port");
        String ip = "";
        try
        {
            ip = LocalTool.getLocalIP();
        }
        catch (UnknownHostException e)
        {
            LOGGER.error("get ip Fail.", e);
        }
        catch (SocketException e)
        {
            LOGGER.error("get ip Fail.", e);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id", SeviceIdUtils.getUUID(ServiceConstant.INTERFACEAGENT_SEQ, ip));
        map.put("createTime", new Timestamp(System.currentTimeMillis()));
        map.put("updateTime", new Timestamp(System.currentTimeMillis()));
        map.put("ip", ip);
        map.put("serviceUrl", assembleUrl(ip, port, deployName));
        map.put("serviceStatus", "");
        recordServerStatusService.recordServerStatus(map);
        
    }
    
    /**
     * 拼接访问路径
     * @param ip
     * @param port
     * @param deployName
     * @return 完整url
     */
    private String assembleUrl(String ip, String port, String deployName)
    {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("http://").append(ip).append(":").append(port).append("/").append(deployName).append("/visit")
            .append("/index");
        return stringBuffer.toString();
    }
    
}
