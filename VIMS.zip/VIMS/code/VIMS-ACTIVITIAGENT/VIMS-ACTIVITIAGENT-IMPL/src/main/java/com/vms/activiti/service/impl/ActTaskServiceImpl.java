package com.icss.ebu.ami.activiti.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.POST;
import javax.ws.rs.Path;

import org.activiti.engine.FormService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.bpmn.behavior.UserTaskActivityBehavior;
import org.activiti.engine.impl.javax.el.ExpressionFactory;
import org.activiti.engine.impl.javax.el.ValueExpression;
import org.activiti.engine.impl.juel.ExpressionFactoryImpl;
import org.activiti.engine.impl.juel.SimpleContext;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.PvmActivity;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.task.TaskDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.dubbo.config.annotation.Service;
import com.icss.ebu.ami.activiti.bean.model.ActCheckDesc;
import com.icss.ebu.ami.activiti.bean.model.ActHiTaskinst;
import com.icss.ebu.ami.activiti.bean.model.Activiti;
import com.icss.ebu.ami.activiti.common.util.Variable;
import com.icss.ebu.ami.activiti.mapper.ActHiTaskinstMapper;
import com.icss.ebu.ami.activiti.service.ActHiTaskinstService;
import com.icss.ebu.ami.activiti.service.ActTaskService;
import com.icss.ebu.ami.commons.exception.ServiceException;
import com.icss.ebu.ami.commons.util.GeneralUtils;
import com.icss.ebu.ami.commons.util.UUIDUtils;

@Service
@Component ("actTaskService")
public class ActTaskServiceImpl implements ActTaskService
{
    private static final Logger LOGGER = LoggerFactory.getLogger (ActTaskServiceImpl.class);
    
    @Autowired
    private ActHiTaskinstService actHiTaskinstService;
    
    @Autowired
    private FormService formService;
    
    @Autowired
    private TaskService taskService;
    
    @Autowired
    protected HistoryService historyService;
    
    @Autowired
    protected RuntimeService runtimeService;
    
    @Autowired
    protected RepositoryService repositoryService;
    
    @Autowired
    private IdentityService identityService;
    
    @Autowired
    private ActHiTaskinstMapper actHiTaskinstMapper;
    
    @Override
    public List <ActHiTaskinst> queryActTaskList (ActHiTaskinst actHiTaskinst)
    {
        List <ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstService.findgActHiTaskinstForApp (actHiTaskinst);
            
            //获取到自定义表单的url
            for (int i = 0; i < list.size (); i++)
            {
                String customUrl = formService.getTaskFormData (list.get (i).getTaskId ()).getFormKey ();
                list.get (i).setCustomUrl (customUrl);
            }
        }
        catch (Exception e)
        {
            LOGGER.error ("ActTaskServiceImpl queryActTaskList has error ", e);
        }
        return list;
    }
    
    /**
     * 工单查询列表
     * @param actHiTaskinst
     * @return
     */
    @Override
    public List <ActHiTaskinst> queryActHiTaskList (ActHiTaskinst actHiTaskinst)
    {
        List <ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstService.findgActHiTaskinstForApp (actHiTaskinst);
            
        }
        catch (Exception e)
        {
            LOGGER.error ("ActTaskServiceImpl queryActHiTaskList has error ", e);
        }
        return list;
    }
    
    /**
     * 启动高低压流程
     *
     */
    @Override
    public ProcessInstance startApplyWorkflow (Activiti activiti)
    {
        String businessKey = activiti.getId ();
        ProcessInstance processInstance = null;
        try
        {
            // 用来设置启动流程的人员ID，引擎会自动把用户ID保存到activiti:initiator中
            identityService.setAuthenticatedUserId (activiti.getUserId ());
            Map <String, Object> variables = new HashMap <String, Object> ();
            variables.put ("user", activiti.getUserId ());
            processInstance = runtimeService.startProcessInstanceByKey (activiti.getFlowFlag (), businessKey, variables);
            String processInstanceId = processInstance.getId ();
            LOGGER.debug ("start process of {key={}, bkey={}, pid={}, variables={}}",
                new Object[] {activiti.getFlowFlag (), activiti.getId (), processInstanceId, variables });
        }
        catch (Exception e)
        {
            LOGGER.error ("process start error.", e);
            throw new ServiceException ("process start error.", e);
        }
        return null;
    }
    
    @Override
    public Activiti processJumpWorkflow (Activiti activiti)
    {
        activiti.setStartMessage (0);
        String appId = activiti.getAppId ();//申请编号
        String userId = activiti.getUserId ();//用户id
        String taskId = activiti.getTaskId ();//流程id
        String tprocinstId = activiti.getTprocinstId ();
        String status = activiti.getStatus ();//状态位，false：回退
        boolean isPass = false;
        boolean isFee = false;
        if (status.contains (","))
        {
            String str[] = status.split (",");
            isPass = !"false".equals (str[0]);
            isFee = !"false".equals (str[1]);
        }
        else
        {
            isPass = !"false".equals (status);
        }
        
        try
        {
            Variable var = new Variable ();
            if (status.contains (","))
            {
                var.setKeys ("isPass,isFee");
                String str = isPass ? "true" : "false";
                String str1 = isFee ? "true" : "false";
                var.setValues (str + "," + str1);
                var.setTypes ("B,B");
            }
            else
            {
                var.setKeys ("isPass");
                String str = isPass ? "true" : "false";
                var.setValues (str);
                var.setTypes ("B");
            }
            Map <String, Object> variables = var.getVariableMap ();
            taskService.setVariables (taskId, variables);
            
            if (null != userId)
            {
                variables.put ("user", userId);
            }
            else
            {
                variables.put ("user", findBackUserId (tprocinstId, taskId, userId, var));
            }
            taskService.complete (taskId, variables);
            activiti.setStartMessage (1);
            LOGGER.info ("appId:" + appId + ", process jump work flow success.");
        }
        catch (Exception e)
        {
            LOGGER.error ("appId:" + appId + ",process jump work flow success.", e);
        }
        return activiti;
    }
    
    @Override
    public Activiti gridJumpflow (Activiti activiti)
    {
        activiti.setStartMessage (0);
        String appId = activiti.getAppId ();//申请编号
        String deptId = activiti.getDeptId();//部门标识
        String taskId = activiti.getTaskId ();//流程id
        String tprocinstId = activiti.getTprocinstId ();
        String status = activiti.getStatus ();//状态位，false：回退
        boolean isPass = false;
        boolean isFee = false;
        if (status.contains (","))
        {
            String str[] = status.split (",");
            isPass = !"false".equals (str[0]);
            isFee = !"false".equals (str[1]);
        }
        else
        {
            isPass = !"false".equals (status);
        }
        
        try
        {
            Variable var = new Variable ();
            if (status.contains (","))
            {
                var.setKeys ("isPass,isFee");
                String str = isPass ? "true" : "false";
                String str1 = isFee ? "true" : "false";
                var.setValues (str + "," + str1);
                var.setTypes ("B,B");
            }
            else
            {
                var.setKeys ("isPass");
                String str = isPass ? "true" : "false";
                var.setValues (str);
                var.setTypes ("B");
            }
            Map <String, Object> variables = var.getVariableMap ();
            taskService.setVariables (taskId, variables);
            
            if (null != deptId)
            {
                variables.put ("dept", deptId);
            }
            else
            {
                variables.put ("dept", findBackUserId (tprocinstId, taskId, activiti.getUserId(), var));
            }
            taskService.complete (taskId, variables);
            activiti.setStartMessage (1);
            LOGGER.info ("appId:" + appId + ", process jump work flow success.");
        }
        catch (Exception e)
        {
            LOGGER.error ("appId:" + appId + ",process jump work flow success.", e);
        }
        return activiti;
    }
    
    private String findBackUserId (String processInstanceId, String taskId, String userId, Variable var)
    {
        String sourceTaskDefKey = getNextTaskDef (taskId, var).getKey ();
        
        List <HistoricTaskInstance> tasks =
            historyService.createHistoricTaskInstanceQuery ().processInstanceId (processInstanceId)
                .taskDefinitionKey (sourceTaskDefKey).orderByHistoricTaskInstanceEndTime ().desc ().listPage (0, 1);
        String assigneeUserId = "";
        if (null != tasks && !tasks.isEmpty ())
        {
            assigneeUserId = tasks.get (0).getAssignee ();
        }
        if (GeneralUtils.isNullOrZeroLength (assigneeUserId))
        {
            assigneeUserId = userId;
        }
        
        return assigneeUserId;
    }
    
    /**
     * 获取下一个任务定义
     * @param taskId     任务Id信息
     * @return 下一个任务定义
     * @throws Exception
     */
    public TaskDefinition getNextTaskDef (String taskId, Variable var)
    {
        
        ProcessDefinitionEntity processDefinitionEntity = null;
        
        String id = null;
        
        TaskDefinition task = null;
        
        //获取流程实例Id信息
        String processInstanceId = taskService.createTaskQuery ().taskId (taskId).singleResult ().getProcessInstanceId ();
        
        //获取流程发布Id信息
        String definitionId = runtimeService.createProcessInstanceQuery ().processInstanceId (processInstanceId).singleResult ()
            .getProcessDefinitionId ();
        
        processDefinitionEntity =
            (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition (definitionId);
        
        ExecutionEntity execution =
            (ExecutionEntity) runtimeService.createProcessInstanceQuery ().processInstanceId (processInstanceId).singleResult ();
        
        //当前流程节点Id信息
        String activitiId = execution.getActivityId ();
        
        //获取流程所有节点信息
        List <ActivityImpl> activitiList = processDefinitionEntity.getActivities ();
        
        //遍历所有节点信息
        for (ActivityImpl activityImpl : activitiList)
        {
            id = activityImpl.getId ();
            if (activitiId.equals (id))
            {
                
                //获取下一个节点信息
                task = nextTaskDefinition (activityImpl, activityImpl.getId (), var, processInstanceId);
                break;
            }
        }
        
        return task;
    }
    
    /**
     * 下一个任务节点信息,
     *
     * 如果下一个节点为用户任务则直接返回,
     *
     * 如果下一个节点为排他网关, 获取排他网关Id信息, 根据排他网关Id信息和execution获取流程实例排他网关Id为key的变量值,
     * 根据变量值分别执行排他网关后线路中的el表达式, 并找到el表达式通过的线路后的用户任务信息
     * @param activityImpl     流程节点信息
     * @param activityId             当前流程节点Id信息
     * @param var               排他网关顺序流线段判断条件, 例如排他网关顺序留线段判断条件为${money>1000}, 若满足流程启动时设置variables中的money>1000, 则流程流向该顺序流信息
     * @param processInstanceId      流程实例Id信息
     * @return
     */
    private TaskDefinition nextTaskDefinition (ActivityImpl activityImpl, String activityId, Variable var,
        String processInstanceId)
    {
        
        PvmActivity ac = null;
        
        Object s = null;
        
        //如果遍历节点为用户任务并且节点不是当前节点信息
        if ("userTask".equals (activityImpl.getProperty ("type")) && !activityId.equals (activityImpl.getId ()))
        {
            //获取该节点下一个节点信息
            TaskDefinition taskDefinition = ((UserTaskActivityBehavior) activityImpl.getActivityBehavior ()).getTaskDefinition ();
            return taskDefinition;
        }
        else
        {
            //获取节点所有流向线路信息
            List <PvmTransition> outTransitions = activityImpl.getOutgoingTransitions ();
            List <PvmTransition> outTransitionsTemp = null;
            for (PvmTransition tr : outTransitions)
            {
                ac = tr.getDestination (); //获取线路的终点节点
                //如果流向线路为排他网关
                if ("exclusiveGateway".equals (ac.getProperty ("type")) || "parallelGateway".equals (ac.getProperty ("type")))
                {
                    outTransitionsTemp = ac.getOutgoingTransitions ();
                    
                    //如果排他网关只有一条线路信息
                    if (outTransitionsTemp.size () == 1)
                    {
                        return nextTaskDefinition ((ActivityImpl) outTransitionsTemp.get (0).getDestination (), activityId, var,
                            processInstanceId);
                    }
                    else if (outTransitionsTemp.size () > 1)
                    { //如果排他网关有多条线路信息
                        for (PvmTransition tr1 : outTransitionsTemp)
                        {
                            s = tr1.getProperty ("conditionText"); //获取排他网关线路判断条件信息
                            if (isCondition (var.getKeys (), StringUtils.trim (s.toString ()), var.getValues ()))
                            {
                                return nextTaskDefinition ((ActivityImpl) tr1.getDestination (), activityId, var,
                                    processInstanceId);
                            }
                        }
                    }
                }
                else if ("userTask".equals (ac.getProperty ("type")))
                {
                    return ((UserTaskActivityBehavior) ((ActivityImpl) ac).getActivityBehavior ()).getTaskDefinition ();
                }
                else
                {
                }
            }
            return null;
        }
    }
    
    /**
     * 根据key和value判断el表达式是否通过信息
     * @param key    el表达式key信息
     * @param el     el表达式信息
     * @param value  el表达式传入值信息
     * @return
     */
    public boolean isCondition (String key, String el, String value)
    {
        ExpressionFactory factory = new ExpressionFactoryImpl ();
        SimpleContext context = new SimpleContext ();
        context.setVariable (key, factory.createValueExpression (value, String.class));
        ValueExpression e = factory.createValueExpression (context, el, boolean.class);
        return (Boolean) e.getValue (context);
    }
    
    @POST
    @Path ("/test")
    @Override
    public String test ()
    {
        return "test success";
    }
    
    @Override
    public void claim (Activiti activiti)
    {
        taskService.claim (activiti.getTaskId (), activiti.getUserId ());
    }
    
    @Override
    public void unclaim (String taskId)
    {
        taskService.unclaim (taskId);
    }
    
    @Override
    public void suspendProcessInstanceById (String id)
    {
        runtimeService.suspendProcessInstanceById (id);
    }
    
    @Override
    public void setVariables (Activiti act)
    {
        taskService.setVariables (act.getTaskId (), act.getVariables ());
    }
    
    @Override
    public void complete (Activiti act)
    {
        taskService.complete (act.getTaskId (), act.getVariables ());
    }
    
    @Override
    public int insertActDesc (ActCheckDesc actCheckDesc)
    {
        actCheckDesc.setId (UUIDUtils.generate16Str ());
        return actHiTaskinstMapper.insertActDesc (actCheckDesc);
    }
}
