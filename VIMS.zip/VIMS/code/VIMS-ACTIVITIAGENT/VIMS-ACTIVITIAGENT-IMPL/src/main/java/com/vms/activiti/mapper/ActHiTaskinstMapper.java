package com.icss.ebu.ami.activiti.mapper;

import java.util.List;
import java.util.Map;

import com.icss.ebu.ami.activiti.bean.model.ActCheckDesc;
import com.icss.ebu.ami.activiti.bean.model.ActHiTaskinst;
import com.icss.ebu.ami.activiti.bean.model.Activiti;
import com.icss.ebu.ami.commons.pagePlugin.Page;

public interface ActHiTaskinstMapper
{
    
    /**
     * 查询未归档信息
     * 	liuchang
     */
    List <ActHiTaskinst> findgActHiTaskinstByPage (Page <ActHiTaskinst> page);
    
    /**
     * 查询未归档信息(带角色)
     *  tfl
     */
    List <ActHiTaskinst> findWaitHandlesByPage (Page <ActHiTaskinst> page);
    
    /**
     * 查询未归档信息(带网格)
     *  tfl
     */
    List <ActHiTaskinst> findGridHandleByPage (Page <ActHiTaskinst> page);
    
    /**
     * 查询归档信息
     * 
     * 	liuchang
     */
    List <ActHiTaskinst> findFileByPage (Page <ActHiTaskinst> page);
    
    /**
     * 查询 历史任务实例表
     * act_hi_taskinst
     * 	liuchang
     */
    List <ActHiTaskinst> findTaskinstByPage (Page <ActHiTaskinst> page);
    
    /**
     * 所有流程名称
     * ACT_RE_PROCDEF
     * 	liuchang
     */
    List <ActHiTaskinst> quaryPnameByPage ();
    
    /**
     * 根据流程名称 id 查询节点名称
     * 
     * 	liuchang
     */
    List <ActHiTaskinst> quaryName (ActHiTaskinst actHiTaskinst);
    
    /**
     * 查询未归档信息 首页Top5
     *  
     */
    List <ActHiTaskinst> findTop5 (Page <ActHiTaskinst> page);
    
    /**
     * 查询归档信息 首页Top5
     * 
     *  
     */
    List <ActHiTaskinst> findTop5File (Page <ActHiTaskinst> page);
    
    /**
     * 事项统计
     * @param map
     * @return
     */
    Integer findTaskCount (Map <String, Object> map);
    
    /**
     * 事项统计All
     * @param map
     * @return
     */
    Integer findTaskCountAll (Map <String, Object> map);
    
    /**
     * 查询未处理任务
     * @param map
     * @return
     */
    List <ActHiTaskinst> findActHiTasksByPage (Map <String, Object> map);
    
    ActHiTaskinst findTaskinstByTaskKeyAndId (Map <String, Object> map);
    
    /**
     * 提供给前端app查询未归档信息
     *  lucheng
     */
    List <ActHiTaskinst> findgActHiTaskinstForApp (ActHiTaskinst actHiTaskinst);
    
    /**
     * 提供前端app查询归档信息
     * 
     *  lucheng
     */
    List <ActHiTaskinst> findFileForApp (ActHiTaskinst actHiTaskinst);
    
    /**
     * 修改id
     * @param activiti
     * @return
     */
    int updateIdBySapp (Activiti activiti);
    
    /**
     * 新增环节操作备注
     * 
     * @param ActCheckDesc actCheckDesc
     * @return int
     */
    int insertActDesc (ActCheckDesc actCheckDesc);
    
}
