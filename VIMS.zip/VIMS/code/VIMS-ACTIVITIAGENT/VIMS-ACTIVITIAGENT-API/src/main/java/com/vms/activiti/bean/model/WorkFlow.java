package com.icss.ebu.ami.activiti.bean.model;

import java.io.Serializable;
import java.util.Date;

import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;

/**lc
 * 
 * @description：工作流接收待处理公用的bean
 */
public class WorkFlow implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4314280215517209715L;

	private String app_id;//申请编号：
	
	private String appNo;//申请编号
	
    private String processInstanceId;//流程实例ID

    private String businessKey;//业务键

    private String startUserId;//申请人编号
    
    private String consNo;//用户编号
    
    private String consName;//用户名称
    
    private String orgNo;//供电单位编号
    
    private String orgName;//供电单位 
    
    private String name;//申请人

    private String processDefinitionId;//当前节点id
    
    private String activityName;//当前节点名

    private Date createTime;//创建时间

    private String flowversion;//流程状态
    
    private int version;//流程版本
    
    private Task task;//任务
    
    private ProcessInstance processInstance;//实例
    
    private HistoricProcessInstance historicProcessInstance;//结束流程的历史实例
    
    private String customUrl;//工作流模型区域的form表单的url
    
    private String processName;//流程名称
    
    // order、sortCol用于页面查询使用
    private String order;
    private String sortCol;
    
	public String getAppNo() {
        return appNo;
    }

    public void setAppNo(String appNo) {
        this.appNo = appNo;
    }

    public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getCustomUrl() {
		return customUrl;
	}

	public void setCustomUrl(String customUrl) {
		this.customUrl = customUrl;
	}

	public HistoricProcessInstance getHistoricProcessInstance() {
		return historicProcessInstance;
	}

	public void setHistoricProcessInstance(HistoricProcessInstance historicProcessInstance) {
		this.historicProcessInstance = historicProcessInstance;
	}

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public ProcessInstance getProcessInstance() {
		return processInstance;
	}

	public void setProcessInstance(ProcessInstance processInstance) {
		this.processInstance = processInstance;
	}

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProcessDefinitionId() {
		return processDefinitionId;
	}

	public void setProcessDefinitionId(String processDefinitionId) {
		this.processDefinitionId = processDefinitionId;
	}

	public Date getCreateTime() {
	    if(createTime == null)
	    {
	        return null;
	    }
		return (Date) createTime.clone();
	}

	public void setCreateTime(Date createTime) {
	    if(createTime == null)
	    {
	        this.createTime = null;
	    }
	    else
	    {
	        this.createTime = (Date) createTime.clone();   
	    }
	}

	public String getFlowversion() {
		return flowversion;
	}

	public void setFlowversion(String flowversion) {
		this.flowversion = flowversion;
	}

	public String getStartUserId() {
		return startUserId;
	}

	public void setStartUserId(String startUserId) {
		this.startUserId = startUserId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public String getConsNo() {
		return consNo;
	}

	public void setConsNo(String consNo) {
		this.consNo = consNo;
	}

	public String getConsName() {
		return consName;
	}

	public void setConsName(String consName) {
		this.consName = consName;
	}

	public String getOrgNo() {
		return orgNo;
	}

	public void setOrgNo(String orgNo) {
		this.orgNo = orgNo;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getSortCol() {
		return sortCol;
	}

	public void setSortCol(String sortCol) {
		this.sortCol = sortCol;
	}
}