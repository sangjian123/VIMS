package com.icss.ebu.ami.activiti.service;

import org.activiti.engine.repository.ProcessDefinition;

import com.icss.ebu.ami.commons.pagePlugin.Page;

/**
 * 创建工作流service，丰富act包中缺少的func
 * @author lucheng
 *
 */
public interface ActivitiService
{
    
    /**
     * 流程管理查询列表
     * @param page
     * @return
     */
    public Page <ProcessDefinition> processManageList (Page <ProcessDefinition> page);
    
}
