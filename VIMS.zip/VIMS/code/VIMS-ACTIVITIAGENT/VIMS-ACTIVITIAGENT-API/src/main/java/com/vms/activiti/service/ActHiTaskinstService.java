package com.icss.ebu.ami.activiti.service;

import java.util.List;
import java.util.Map;

import com.icss.ebu.ami.activiti.bean.model.ActHiTaskinst;
import com.icss.ebu.ami.commons.pagePlugin.Page;

/**
 * Service
 *
 * @author liuchang	
 */
public interface ActHiTaskinstService
{
    
    /**
     * 查询历史任务实例表
     * act_hi_taskinst
     * 	liuchang
     */
    Page <ActHiTaskinst> findgActHiTaskinstByPage (Page <ActHiTaskinst> page);
    
    /**
     * 查询 历史任务实例表
     * act_hi_taskinst
     * 	liuchang
     */
    Page <ActHiTaskinst> findTaskinstByPage (Page <ActHiTaskinst> page);
    
    /**
     * 所有流程名称
     * ACT_RE_PROCDEF
     * 	liuchang
     */
    List <ActHiTaskinst> quaryPnameByPage ();
    
    /**
     * 根据流程名称 id 查询节点名称
     * 
     * 	liuchang
     */
    List <ActHiTaskinst> quaryName (ActHiTaskinst actHiTaskinst);
    
    Page <ActHiTaskinst> findgActHiTaskinstTop5ByPage (Page <ActHiTaskinst> page);
    
    Integer findTaskCount (Map <String, Object> map);
    
    Integer findTaskCountAll (Map <String, Object> map);
    
    /**
     * 查询代办任务
     * ActHiTaskinst
     * tfl
     */
    Page <ActHiTaskinst> findWaitHandleByPage (Page <ActHiTaskinst> page);
    
    /**
     * 查询网格代办任务
     * ActHiTaskinst
     * tfl
     */
    Page <ActHiTaskinst> findGridHandleByPage (Page <ActHiTaskinst> page);
    
    /**
     * app端查询代办
     * @param actHiTaskinst
     * @return
     */
    List <ActHiTaskinst> findgActHiTaskinstForApp (ActHiTaskinst actHiTaskinst);
}
