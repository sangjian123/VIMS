package com.icss.ebu.ami.activiti.bean.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ActHiTaskinst implements Serializable
{
    /**
     * liuchang
     * ACT_RU_TASK
     * --运行时任务节点表
     */
    private static final long serialVersionUID = 1L;
    
    private String id;
    
    private String rev;//乐观锁
    
    private String delegation;//委托类型
    
    private String suspensionState;//是否挂起 1代表激活 2代表挂起
    
    private Date createTime;//创建时间
    
    private String pname;//流程名称
    
    private String detai;//流程详情
    
    private String userData;//用户详情
    
    private String applyState;//申请状态
    
    private String bDate;//申请开始时间（查询申请时间的时间段 查询条件）
    
    private String eDate;//申请结束时间
    
    private String custId;//
    
    private String consId;//
    
    private String appNo;//申请编号
    
    private String businessKey;//业务主键
    
    private String psOrgNo;//单位
    
    private String orgName;//单位名
    
    private String consNo;//户号
    
    private String consName;//户名
    
    private String consSortCode;//用户分类
    
    private String appTypeCode;//申请类别
    
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date handleTime;//申请时间
    
    private String infoArcDate;//归档时间
    
    private String startUserId;//起草人
    
    private String userId;//当前处理人
    
    private String procDefId;//流程定义ID
    
    private String taskDefKey;//节点定义ID
    
    private String procInstId;//流程实例ID
    
    private String executionId;//执行实例ID
    
    private String parentTaskId;//父节点实例ID
    
    private String name;//节点名称
    
    private String description;//描述
    
    private String owner;//实际签收人 任务的拥有者
    
    private String assignee;//签收人或被委托
    
    private String groupId; //分配角色
    
    private Date startTime;//开始时间
    
    private Date claimTime;//提醒时间
    
    private Date endTime;//结束时间
    
    private BigDecimal duration;//耗时
    
    private String deleteReason;//删除原因
    
    private BigDecimal priority;//优先级别
    
    private Date dueDate;//过期时间
    
    private String formKey;//节点定义的formkey
    
    private String category;
    
    private String tenantId;
    
    private String taskId;
    
    private String appId;
    
    private String customUrl;
    
    private String taskName;
    
    private String reason;
    
    private String barCode;
    
    private String loginName;
    
    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getReason ()
    {
        return reason;
    }
    
    public void setReason (String reason)
    {
        this.reason = reason;
    }
    
    public String getId ()
    {
        return id;
    }
    
    public void setId (String id)
    {
        this.id = id;
    }
    
    public String getProcDefId ()
    {
        return procDefId;
    }
    
    public void setProcDefId (String procDefId)
    {
        this.procDefId = procDefId;
    }
    
    public String getTaskDefKey ()
    {
        return taskDefKey;
    }
    
    public void setTaskDefKey (String taskDefKey)
    {
        this.taskDefKey = taskDefKey;
    }
    
    public String getProcInstId ()
    {
        return procInstId;
    }
    
    public void setProcInstId (String procInstId)
    {
        this.procInstId = procInstId;
    }
    
    public String getExecutionId ()
    {
        return executionId;
    }
    
    public void setExecutionId (String executionId)
    {
        this.executionId = executionId;
    }
    
    public String getParentTaskId ()
    {
        return parentTaskId;
    }
    
    public void setParentTaskId (String parentTaskId)
    {
        this.parentTaskId = parentTaskId;
    }
    
    public String getName ()
    {
        return name;
    }
    
    public void setName (String name)
    {
        this.name = name;
    }
    
    public String getDescription ()
    {
        return description;
    }
    
    public void setDescription (String description)
    {
        this.description = description;
    }
    
    public String getOwner ()
    {
        return owner;
    }
    
    public void setOwner (String owner)
    {
        this.owner = owner;
    }
    
    public String getAssignee ()
    {
        return assignee;
    }
    
    public void setAssignee (String assignee)
    {
        this.assignee = assignee;
    }
    
    public Date getStartTime ()
    {
        if (startTime == null)
        {
            return null;
        }
        return (Date) startTime.clone ();
    }
    
    public void setStartTime (Date startTime)
    {
        if (startTime == null)
        {
            this.startTime = null;
        }
        else
        {
            this.startTime = (Date) startTime.clone ();
        }
    }
    
    public Date getClaimTime ()
    {
        if (claimTime == null)
        {
            return null;
        }
        return (Date) claimTime.clone ();
    }
    
    public void setClaimTime (Date claimTime)
    {
        if (claimTime == null)
        {
            this.claimTime = null;
        }
        else
        {
            this.claimTime = (Date) claimTime.clone ();
        }
    }
    
    public Date getEndTime ()
    {
        if (endTime == null)
        {
            return null;
        }
        return (Date) endTime.clone ();
    }
    
    public void setEndTime (Date endTime)
    {
        if (endTime == null)
        {
            this.endTime = null;
        }
        else
        {
            this.endTime = (Date) endTime.clone ();
        }
    }
    
    public BigDecimal getDuration ()
    {
        return duration;
    }
    
    public void setDuration (BigDecimal duration)
    {
        this.duration = duration;
    }
    
    public String getDeleteReason ()
    {
        return deleteReason;
    }
    
    public void setDeleteReason (String deleteReason)
    {
        this.deleteReason = deleteReason;
    }
    
    public BigDecimal getPriority ()
    {
        return priority;
    }
    
    public void setPriority (BigDecimal priority)
    {
        this.priority = priority;
    }
    
    public Date getDueDate ()
    {
        if (dueDate == null)
        {
            return null;
        }
        return (Date) dueDate.clone ();
    }
    
    public void setDueDate (Date dueDate)
    {
        if (dueDate == null)
        {
            this.dueDate = null;
        }
        else
        {
            this.dueDate = (Date) dueDate.clone ();
        }
    }
    
    public String getFormKey ()
    {
        return formKey;
    }
    
    public void setFormKey (String formKey)
    {
        this.formKey = formKey;
    }
    
    public String getCategory ()
    {
        return category;
    }
    
    public void setCategory (String category)
    {
        this.category = category;
    }
    
    public String getTenantId ()
    {
        return tenantId;
    }
    
    public void setTenantId (String tenantId)
    {
        this.tenantId = tenantId;
    }
    
    public String getRev ()
    {
        return rev;
    }
    
    public void setRev (String rev)
    {
        this.rev = rev;
    }
    
    public String getDelegation ()
    {
        return delegation;
    }
    
    public void setDelegation (String delegation)
    {
        this.delegation = delegation;
    }
    
    public String getSuspensionState ()
    {
        return suspensionState;
    }
    
    public void setSuspensionState (String suspensionState)
    {
        this.suspensionState = suspensionState;
    }
    
    public Date getCreateTime ()
    {
        if (createTime == null)
        {
            return null;
        }
        return (Date) createTime.clone ();
    }
    
    public void setCreateTime (Date createTime)
    {
        if (createTime == null)
        {
            this.createTime = null;
        }
        else
        {
            this.createTime = (Date) createTime.clone ();
        }
    }
    
    public String getPname ()
    {
        return pname;
    }
    
    public void setPname (String pname)
    {
        this.pname = pname;
    }
    
    public String getBusinessKey ()
    {
        return businessKey;
    }
    
    public void setBusinessKey (String businessKey)
    {
        this.businessKey = businessKey;
    }
    
    public String getPsOrgNo ()
    {
        return psOrgNo;
    }
    
    public void setPsOrgNo (String psOrgNo)
    {
        this.psOrgNo = psOrgNo;
    }
    
    public String getOrgName ()
    {
        return orgName;
    }
    
    public void setOrgName (String orgName)
    {
        this.orgName = orgName;
    }
    
    public String getConsNo ()
    {
        return consNo;
    }
    
    public void setConsNo (String consNo)
    {
        this.consNo = consNo;
    }
    
    public String getConsName ()
    {
        return consName;
    }
    
    public void setConsName (String consName)
    {
        this.consName = consName;
    }
    
    public String getConsSortCode ()
    {
        return consSortCode;
    }
    
    public void setConsSortCode (String consSortCode)
    {
        this.consSortCode = consSortCode;
    }
    
    public String getAppTypeCode ()
    {
        return appTypeCode;
    }
    
    public void setAppTypeCode (String appTypeCode)
    {
        this.appTypeCode = appTypeCode;
    }
    
    public Date getHandleTime ()
    {
        return handleTime;
    }
    
    public void setHandleTime (Date handleTime)
    {
        this.handleTime = handleTime;
    }
    
    public String getInfoArcDate ()
    {
        return infoArcDate;
    }
    
    public void setInfoArcDate (String infoArcDate)
    {
        this.infoArcDate = infoArcDate;
    }
    
    public String getAppNo ()
    {
        return appNo;
    }
    
    public void setAppNo (String appNo)
    {
        this.appNo = appNo;
    }
    
    public String getStartUserId ()
    {
        return startUserId;
    }
    
    public void setStartUserId (String startUserId)
    {
        this.startUserId = startUserId;
    }
    
    public String getUserId ()
    {
        return userId;
    }
    
    public void setUserId (String userId)
    {
        this.userId = userId;
    }
    
    public String getCustId ()
    {
        return custId;
    }
    
    public void setCustId (String custId)
    {
        this.custId = custId;
    }
    
    public String getConsId ()
    {
        return consId;
    }
    
    public void setConsId (String consId)
    {
        this.consId = consId;
    }
    
    public String getDetai ()
    {
        return detai;
    }
    
    public void setDetai (String detai)
    {
        this.detai = detai;
    }
    
    public String getbDate ()
    {
        return bDate;
    }
    
    public void setbDate (String bDate)
    {
        this.bDate = bDate;
    }
    
    public String geteDate ()
    {
        return eDate;
    }
    
    public void seteDate (String eDate)
    {
        this.eDate = eDate;
    }
    
    public String getUserData ()
    {
        return userData;
    }
    
    public void setUserData (String userData)
    {
        this.userData = userData;
    }
    
    public String getApplyState ()
    {
        return applyState;
    }
    
    public void setApplyState (String applyState)
    {
        this.applyState = applyState;
    }
    
    /**
     * @return the tastId
     */
    public String getTaskId ()
    {
        return taskId;
    }
    
    /**
     * @param tastId the tastId to set
     */
    public void setTaskId (String tastId)
    {
        this.taskId = tastId;
    }
    
    /**
     * @return the appId
     */
    public String getAppId ()
    {
        return appId;
    }
    
    /**
     * @param appId the appId to set
     */
    public void setAppId (String appId)
    {
        this.appId = appId;
    }
    
    /**
     * @return the customUrl
     */
    public String getCustomUrl ()
    {
        return customUrl;
    }
    
    /**
     * @param customUrl the customUrl to set
     */
    public void setCustomUrl (String customUrl)
    {
        this.customUrl = customUrl;
    }
    
    /**
     * @return the taskName
     */
    public String getTaskName ()
    {
        return taskName;
    }
    
    /**
     * @param taskName the taskName to set
     */
    public void setTaskName (String taskName)
    {
        this.taskName = taskName;
    }
    
    public String getGroupId ()
    {
        return groupId;
    }
    
    public void setGroupId (String groupId)
    {
        this.groupId = groupId;
    }
    
}