;
(function($, app) {
	"use strict";
	
	app.controller("VehiclePositionCtrl", function($scope, $http,$map,$document,$timeout) {
		$scope.accountList=[{key:"查看所有车辆",value:0},{key:"仅显示在线车辆",value:1},{key:"仅显示离线车辆",value:2}];
		$scope.equip_status=0;
		$scope.queryVehiclePosition=function(){
			$http({
            	method: 'POST',
            	url: basePath + '/vehicle/queryVehicleWtihDept',
            	params: {"equip_status":$scope.equip_status,"cardnumbers":$scope.cardnumbers}
			})
			.success(function(data) {
				alert(1);
			});
		}
		
		$map.load().then(function(){
			var map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
			map.clearOverlays();
			// 获取点坐标集
			var points = [  
			              new BMap.Point(121.533615,31.277752),  // 始点
			              new BMap.Point(121.536615,31.274752),  
			              new BMap.Point(121.535615,31.276752),  
			              new BMap.Point(121.537615,31.278752),  
			              new BMap.Point(121.5356439,31.2810635) // 终点 
			            ];  
			
			var viewPort = map.getViewport(points);
			map.centerAndZoom(viewPort.center, viewPort.zoom);
			map.enableScrollWheelZoom();
			map.addControl(new BMap.NavigationControl());
			map.addControl(new BMap.ScaleControl());
			map.addControl(new BMap.OverviewMapControl());
			map.addControl(new BMap.MapTypeControl());
			//	map.setCurrentCity("北京"); // 仅当设置城市信息时，MapTypeControl 的切换功能才能可用
		    for (var i = points.length - 1; i > 0; i--){  
		        var angle = $.getAngle(points[i], points[i-1]); // 获取连接方向
		        drawMarker(points[i], angle,map);
		    } 
		});
		
	    function drawMarker(point, angle,map) {  
	        var iconImg = new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34));  
	        var marker = new BMap.Marker(point, { icon : iconImg });
	        var label = new BMap.Label('苏A88888', {offset: new BMap.Size(-15, -30)}); //创建marker点的标记
			marker.setLabel(label);
			marker.setRotation(angle);
	        map.addOverlay(marker);  
	        marker.addEventListener("click", function(){
				drawInfoWindow(marker);
			 });
	    }  
		
		function drawInfoWindow(marker){
			var opts={
					height:100,
					width:250
			}
			var infoWindow = new BMap.InfoWindow("World",opts); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
		}
	})
})(jQuery, app)