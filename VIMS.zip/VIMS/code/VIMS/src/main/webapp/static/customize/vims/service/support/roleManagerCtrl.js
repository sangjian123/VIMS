;
(function($, app) {
	"use strict";
	
	app.controller("RoleManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/role/query";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'id', field:'id', visible:false },
                	{ title:'名称', field:'name'},
                	{ title:'描述', field:'description', sortable:true },
                	{ title:'状态', field:'status', }
            	]
		$scope.addRole=function(){
			$modal.open({
	          	templateUrl:basePath + "/role/roleInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	controller:function($scope,$modalInstance){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); };
	          		
	          	// 新增
	              $scope.addOrEditRole = function() {
	                    $http.post(basePath + "/role/editRole", $scope.role || {}).success(function(result) {
	                      if (result.success) {
	                        $messager.success("提示", "操作成功");
	                        $modalInstance.dismiss('cancel'); 
	                        $("#roleList").bootstrapTable('refresh');
	                      }else{
	                        $messager.error("提示", result.msg);
	                      }
	                    });
	                  };
	          	}
	          });
		}
	})
})(jQuery, app)