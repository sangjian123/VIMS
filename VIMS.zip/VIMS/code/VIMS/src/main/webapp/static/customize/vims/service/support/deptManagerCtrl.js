;
(function($, app) {
	"use strict";
	
	app.controller("DeptManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/organization/datagrid";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'id', field:'id', visible:false },
                	{ title:'部门名称', field:'name'},
                	{ title:'部门地址', field:'address' },
                	{ title:'创建日期', field:'createTime', sortable:true },
                	{ title:'备注', field:'description', align:'center' }
            	]
		$scope.addDept=function(){
			$modal.open({
	          	templateUrl:basePath + "/organization/deptInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	controller:function($scope,$modalInstance){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
	          		$scope.saveDept=function(){ 
	          		  
	          		  $http.post(basePath + "/organization/add", $scope.organization || {}).success(function(result) {
	                  if (result.success) {
	                    $messager.success("提示", "操作成功");
	                    $modalInstance.dismiss('cancel'); 
	                  }else{
	                    $messager.error("提示", result.msg);
	                  }
	                });
	          		  
	          		}
	          	}
	          });
		}
	})
})(jQuery, app)