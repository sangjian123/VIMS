;
(function($, app) {
	"use strict";
	
	app.controller("BasicInfoCtrl", function($scope, $http) {
	})
})(jQuery, app)