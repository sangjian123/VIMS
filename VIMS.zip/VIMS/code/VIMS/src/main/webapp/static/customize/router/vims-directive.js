(function($){
	"use strict";
	
	var app = angular.module("main.webapp", ['vims.webapp']);
	
	app.config(["$httpProvider", function ($httpProvider) {   
        $httpProvider.interceptors.push('vimsInterceptor');  
    }]);
	
	app.factory('vimsInterceptor', function ($rootScope,$q,$injector) {return { 
		request: function (config) { 
			return config;
		}, 
		response: function (response) {
			return response; 
			}};
		});  
	
	app
	.run(function($templateCache) {
		 var simpleSelectHtm = [
								'<div class="select-input">',
								'<span class="glyphicon glyphicon-chevron-down" ng-click="chevronSelect($event,show=!show)"></span>',
								'<input type="text" class="form-control" ng-model="selectText" placeholder="请选择" readonly="readonly" ng-click="$event.stopPropagation();show=!show;" ng-blur="show=false">',
								'<div  ng-if="show">',
									'<ul>',
										'<li  ng-mousedown="selectOne($event)" ng-if="!vNoselect">请选择</li>',
										'<li  ng-repeat="item in vList track by $index" ng-mousedown="selectOne($event,item)">{{item[vKey]}}</li>',
									'</ul>',
								'</div>',
								'</div>'
		                     ].join("");
		 
	        $templateCache.put('simpleSelect.htm',simpleSelectHtm);
	})
	.directive('vimsTable', function($timeout,$compile) {
        return {
        	restrict: 'E',
            scope:{
            	vimsUrl:'=vimsUrl',
            	vimsColumns:'=vimsColumns',
            	vimsOptions:'@vimsOptions',
            },
            template: '<table class="table table-hover"></table>',
            replace: true,
            link:function(scope,element,attr)
            {
            	var options = {
                    	url:scope.vimsUrl,
                    	striped: true, //是否显示行间隔色
                    	pagination:true,//是否分页
                    	queryParams:[],
                    	sidePagination:'server',
                    	showRefresh:true,//刷新按钮
                    	showColumns:true,
                    	clickToSelect: false,//是否启用点击选中行
                    	columns:scope.vimsColumns
                    };
            	var option = scope.vimsOptions ? (new Function('return ' + '{' + scope.vimsOptions + '}'))() : {};
            	$.extend(options,option);
            	$(element).bootstrapTable(options);
            }
        };
    })
    .directive('vimsSelect', function($templateCache,$parse) {
   	 return {
  		     restrict: 'E',
  			 replace: true,
  			 transclude: true,
  		     template: $templateCache.get("simpleSelect.htm"),
  		     scope: {
  				vKey:'@',
  				vValue:'@',
  				vModel:'=',
  				vFire:'&',
  				vList:'=',
  				vNoselect:'@' 
  			},
  		    controller:function($scope,$element,$attrs,$filter){
  			$scope.$watchGroup(["vList","vModel"],function(n,o){
  				$scope.selectText=null; 
  				angular.forEach($scope.vList,function(v,i){
  					var sm = angular.isObject($scope.vModel) ? $scope.vModel : String($scope.vModel);
  					if(v === sm || String(v[$scope.vValue]) === sm)
  					$scope.selectText=v[$scope.vKey];// 用于显示input文本
      			});
  				if(!$scope.selectText && $attrs.vModel)
  				{
  					var model = $parse($attrs.vModel);
  					model.assign($scope.$parent,null);
  				}	
  			});
  			
  			$scope.chevronSelect=function($event,s){
  				$event.stopPropagation();
  				if(s)$($event.target).next("input").focus();
  			}
  			// 将ng-click改为ng-mousedown,可改变优先执行mousedown，后执行ng-blur
  			$scope.selectOne = function($event,item)
  			{
  				$scope.selectText=item ? item[$scope.vKey] : '';
  				if($attrs.vModel)
     			{
  					var model = $parse($attrs.vModel);
  					if(angular.isObject($scope.vModel)) {model.assign($scope.$parent,item || {});}
  					else
  					{model.assign($scope.$parent,item ? item[$scope.vValue] : undefined);}	
     			}
  				$scope.vFire();
  			}
  		}
 	 }
  })
  /**
   * 
   * <div class="col-sm-8 p0 multiple-select">
   *	 <vims-multiple-select select-list="selectList" select="select"  value="value"  label="label"></vims-multiple-select>
   * </div>
   * 
   **/
  .directive('vimsMultipleSelect', function($compile) {
        return {
        	restrict: 'E',
            scope:{
            	selectList:'=selectList',
            	select:'=select',
            	value:'@value',
            	label:'@label'
            },
            template: '<select class="selectpicker form-control" multiple data-live-search="true"></select>',
            replace: true,
            link:function(scope,element,attr)
            {
            	scope.$watchCollection("selectList",function(){
            		var options = [];
                	angular.forEach(scope.selectList,function(v,i){
                		options.push('<option  value="'+v[scope.value]+'">'+v[scope.label]+'</option>');
                	});
                	$(element).empty().append(options.join(""));
                	$(element).selectpicker({
            	        'selectedText': 'cat',
            	        'noneSelectedText':'请选择',
            	        'noneResultsText':'没有结果匹配 {0}'
            	    });
                	$(element).selectpicker('refresh');
            	});
            	// 设置值
            	scope.$watch("select",function(){
            		$(element).selectpicker('val', scope.select);
            	});
            	// 选中时设置
            	$(element).on('changed.bs.select', function(e) {
            		var val = $(this).val();
            		scope.$apply(function(){
            			scope.select=val;
            		})
            	});
            }
        };
    })
})(jQuery)