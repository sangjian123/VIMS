package com.vms.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @description：部门
 * @author：zhixuan.wang
 * @date：2015/10/1 14:51
 */
public class Organization implements Serializable
{
    
    public static final String DEFAULT_ID = "01";
    
    private static final long serialVersionUID = 1282186495210887307L;
    
    private Long id;
    
    private String name;
    
    private String address;
    
    private String code;
    
    private String pid;
    
    private Date createdate;
    
    private int childrenNum;
    
    private String description;
    
    public Long getId()
    {
        return id;
    }
    
    public void setId(Long id)
    {
        this.id = id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name == null ? null : name.trim();
    }
    
    public String getAddress()
    {
        return address;
    }
    
    public void setAddress(String address)
    {
        this.address = address == null ? null : address.trim();
    }
    
    public String getPid()
    {
        return pid;
    }
    
    public void setPid(String pid)
    {
        this.pid = pid;
    }
    
    public Date getCreatedate()
    {
        if(createdate == null)
        {
            return null;
        }
        return (Date) createdate.clone();
    }
    
    public void setCreatedate(Date createdate)
    {
        if(createdate == null)
        {
            this.createdate = null;
        }
        else
        {
            this.createdate = (Date) createdate.clone();
        }
    }
    
    public String getCode()
    {
        return code;
    }
    
    public void setCode(String code)
    {
        this.code = code;
    }
    
    @Override
    public String toString()
    {
        return "Organization{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", address='" + address + '\'' + ", pid='" + pid
            + '\'' + ", createdate=" + createdate + '}';
    }
    
    /**
     * @return the childrenNum
     */
    public int getChildrenNum()
    {
        return childrenNum;
    }
    
    /**
     * @param childrenNum the childrenNum to set
     */
    public void setChildrenNum(int childrenNum)
    {
        this.childrenNum = childrenNum;
    }
    
    public String getDescription()
    {
        return description;
    }
    
    public void setDescription(String description)
    {
        this.description = description;
    }
    
}