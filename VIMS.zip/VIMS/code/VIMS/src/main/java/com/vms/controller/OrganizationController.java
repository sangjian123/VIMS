package com.vms.controller;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.constant.CommonConstant;
import com.vms.constant.GeneralConstant;
import com.vms.model.Organization;
import com.vms.model.Page;
import com.vms.model.Result;
import com.vms.model.User;
import com.vms.service.OrganizationService;
import com.vms.service.UserService;
import com.vms.utils.GeneralUtils;
import com.vms.utils.UUIDUtils;

/**
 * @description：部门管理
 * @author：zhixuan.wang
 * @date：2015/10/1 14:51
 */
@Controller
@RequestMapping ("/organization")
public class OrganizationController extends BaseController
{
    
    @Autowired
    private OrganizationService organizationService;
    
    @Autowired
    private UserService userService;
    
    /**
     * 部门管理主页
     *
     * @return
     */
    @RequestMapping (value = "/deptManager", method = RequestMethod.GET)
    public String manager()
    {
        return "support/deptManager";
    }
    
    @RequestMapping ("/datagrid")
    @ResponseBody
    public Object datagrid(HttpServletRequest request)
    {
        Organization organization = new Organization();
        Map<String, Object> map = new HashMap<String, Object>();
        
        Page<Organization> page = new Page<Organization>(organization);
        
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        
        if(StringUtils.isNotBlank(request.getParameter("page")))
        {
            
            page.setPageNo(Integer.parseInt(request.getParameter("page")));
        }
        else
        {
            
            page.setPageNo(1);
        }
        if(StringUtils.isNotBlank(request.getParameter("rows")))
        {
            
            page.setPageSize(Integer.parseInt(request.getParameter("rows")));
        }
        else
        {
            
            page.setPageSize(1000);
        }
        
        page = organizationService.findAllOrganizations(page);
        map.put("rows", page.getResults());
        map.put("total", page.getTotalRecord());
        return map;
        
    }
    
    /**
     * 选择部门
     *
     * @return
     */
    @RequestMapping (value = "/deptChose", method = RequestMethod.GET)
    public String deptChose(HttpServletRequest request)
    {
        String buttonId = request.getParameter("buttonId");
        if(buttonId == null || buttonId == "")
        {
            buttonId = "chooseDept";
        }
        request.setAttribute("buttonId", buttonId);
        return "admin/deptChose";
    }
    
    /**
     * 部门列表
     *
     * @return
     */
    @RequestMapping ("/treeOrgGrid")
    @ResponseBody
    public Object treeOrgGrid(Organization organization)
    {
        return organizationService.queryOrgTreeGrid(organization);
    }
    
    /**
     * 弹框选择部门列表
     *
     * @return
     */
    @RequestMapping ("/treeOrgChoose")
    @ResponseBody
    public Object treeOrgChoose()
    {
        User user = getCurrentUser();
        return organizationService.treeOrgChoose(user);
    }
    
    /**
     * 弹框选择部门列表
     *
     * @return
     */
    @RequestMapping ("/treeOrgChooseColl")
    @ResponseBody
    public Object treeOrgChooseColl()
    {
        User user = getCurrentUser();
        return organizationService.treeOrgChooseColl(user);
    }
    
    /**
     * 弹框选择部门列表（所有单位）
     *
     * @return
     */
    @RequestMapping ("/treeOrgChooseAll")
    @ResponseBody
    public Object treeOrgChooseAll()
    {
        User user = getCurrentUser();
        return organizationService.treeOrgChooseAll(user);
    }
    
    /**
     * 添加部门页
     *
     * @return
     */
    @RequestMapping ("/deptInfo")
    public String addPage(HttpServletRequest request)
    {
        return "support/deptInfo";
    }
    
    /**
     * 添加一级部门页
     *
     * @return
     */
    @RequestMapping ("/addRootPage")
    public String addRootPage(HttpServletRequest request)
    {
        request.setAttribute("orgNo", request.getParameter("orgNo"));
        return "admin/organizationAddRootOrg";
    }
    
    private String generateOrgID(String orgId)
    {
        int id = NumberUtils.toInt(orgId) + 1;
        orgId = (id < 10 ? "0" : "") + (id);
        
        return orgId;
    }
    
    /**
     * 添加部门页
     *
     * @return
     */
    @RequestMapping ("/addDeptPage")
    public String addDeptPage()
    {
        return "admin/deptAdd";
    }
    
    /**
     * 选择部门页
     *
     * @return
     */
    @RequestMapping ("/choseOrg")
    public String choseOrg(HttpServletRequest request)
    {
        String buttonId = request.getParameter("buttonId");
        if(buttonId == null || buttonId == "")
        {
            buttonId = "choseOrgNo";
        }
        request.setAttribute("buttonId", buttonId);
        return "admin/organizationChose";
    }
    
    /**
     * 选择部门页
     *
     * @return
     */
    @RequestMapping ("/choseOrgColl")
    public String choseOrgColl(HttpServletRequest request)
    {
        String buttonId = request.getParameter("buttonId");
        if(buttonId == null || buttonId == "")
        {
            buttonId = "choseOrgNo";
        }
        request.setAttribute("buttonId", buttonId);
        return "admin/organizationChoseColl";
    }
    
    /**
     * 选择部门页(所有部门)
     *
     * @return
     */
    @RequestMapping ("/choseOrgAll")
    public String choseOrgAll(HttpServletRequest request)
    {
        String buttonId = request.getParameter("buttonId");
        if(buttonId == null || buttonId == "")
        {
            buttonId = "choseOrgNo";
        }
        request.setAttribute("buttonId", buttonId);
        return "admin/organizationChoseAll";
    }
    
    /**
     * 添加部门
     *
     * @param organization
     * @return
     */
    @RequestMapping ("/add")
    @ResponseBody
    public Object add(@RequestBody Organization organization)
    {
        
        if(null != organization.getId())
        {
            Organization org = organizationService.findOrganizationById(organization.getId());
            if(org != null)
            {
                return renderError(super.getProperty("code_is_exist"));
            }
            else
            {
                // 名称不能相同
                Organization o = new Organization();
                o.setName(organization.getName());
                List l = organizationService.findOrganization(o);
                if(l.size() > 0)
                {
                    return renderError(super.getProperty("name_is_exist"));
                }
            }
        }
        else
        {
            organization.setCode(UUIDUtils.generate16Str());
        }
        
        try
        {
            int rt = organizationService.addOrganization(organization);
            
            Result result = (Result) renderSuccess(super.getProperty("oper_success"));
            
            return result;
        }
        catch (Exception e)
        {
            logger.error("xxx insert error", e);
            return renderError(super.getProperty("sync_organization_fail"));
        }
    }
    
    /**
     * 添加-部门
     *
     * @param organization
     * @return
     */
    @RequestMapping ("/addDept")
    @ResponseBody
    public Object addDept(Organization organization)
    {
        if(GeneralUtils.isNotNullOrZeroLength(organization.getCode()))
        {
            Organization org = organizationService.findOrganizationByCode(organization.getCode());
            if(org != null)
            {
                return renderError(super.getProperty("code_is_exist"));
            }
            else
            {
                // 名称不能相同
                Organization o = new Organization();
                o.setName(organization.getName());
                List l = organizationService.findOrganization(o);
                if(l.size() > 0)
                {
                    return renderError(super.getProperty("name_is_exist"));
                }
            }
        }
        else
        {
            organization.setCode(UUIDUtils.generate16Str());
        }
        
        int isFail = organizationService.addOrganization(organization);
        if(isFail == 0)
        {
            return renderError(super.getProperty("sync_organization_fail"));
        }
        else
        {
            Result result = (Result) renderSuccess(super.getProperty("oper_success"));
            
            return result;
        }
    }
    
    /**
     * 编辑部门页
     *
     * @param request
     * @param id
     * @return
     */
    @RequestMapping ("/editPage")
    public String editPage(HttpServletRequest request, Long id)
    {
        Organization organization = organizationService.findOrganizationById(id);
        request.setAttribute("organization", organization);
        return "admin/organizationEdit";
    }
    
    /**
     * 编辑部门页
     *
     * @param request
     * @param id
     * @return
     */
    @RequestMapping ("/editDeptPage")
    public String editDeptPage(HttpServletRequest request, Long id)
    {
        Organization organization = organizationService.findOrganizationById(id);
        request.setAttribute("organization", organization);
        return "admin/deptEdit";
    }
    
    /**
     * 编辑部门
     *
     * @param organization
     * @return
     */
    @RequestMapping ("/edit")
    @ResponseBody
    public Object edit(@Valid Organization organization, BindingResult bindResult)
    {
        if(bindResult.hasErrors())
        {
            //获取校验错误项中的第一条错误项
            FieldError error = bindResult.getFieldError();
            //获取javaBean中校验不通过的属性
            String field = error.getField();
            
            //获取页面表单中显示的名称或错误提示
            Map<String, String> validMap = getValidateMap(error.getDefaultMessage());
            //获取页面表单中显示的名称
            String label = getProperty(validMap.get(GeneralConstant.FIELD_NAME));
            //获取该属性的验证错误提示
            String message = getProperty(validMap.get(GeneralConstant.MESSAGE));
            if("name".equals(field))
            {
                //错误提示需要传递参数   (此处是密码的长度范围 6-12位)
                return renderError(label + GeneralConstant.COLON + MessageFormat.format(message, 1, 64));
            }
            else if("address".equals(field))
            {
                //错误提示需要传递参数   (此处是密码的长度范围 6-12位)
                return renderError(label + GeneralConstant.COLON + MessageFormat.format(message, 1, 100));
            }
            else
            {
                //错误提示不需要传递参数
                return renderError(label + GeneralConstant.COLON + message);
            }
        }
        
        try
        {
            Long id = organization.getId();
            
            int rt = organizationService.updateOrganization(organization);
            if(rt == 0)
            {
                return renderError(super.getProperty("sync_organization_fail"));
            }
            return renderSuccess(super.getProperty("oper_success"));
        }
        catch (Exception e)
        {
            return renderError(super.getProperty("sync_organization_fail"));
        }
    }
    
    /**
     * 编辑部门
     *
     * @param organization
     * @return
     */
    @RequestMapping ("/editDept")
    @ResponseBody
    public Object editDept(Organization organization)
    {
        
        int isFail = organizationService.updateOrganization(organization);
        if(isFail == 0)
        {
            return renderError(super.getProperty("sync_organization_fail"));
        }
        else
        {
            
            return renderSuccess(super.getProperty("oper_success"));
        }
    }
    
    /**
     * 删除部门
     *
     * @param id
     * @return
     */
    @RequestMapping ("/delete")
    @ResponseBody
    public Object delete(Long id)
    {
        User user = new User();
        user.setBelongDept(id);
        
        Organization org = organizationService.findOrganizationById(id);
        
        if(0 < userService.countUser(user))
        {
            
            return renderError(super.getProperty("delete_organization_fail_hasuser"));
        }
        
        try
        {
            int rt = organizationService.deleteOrganizationById(id);
            if(rt == 0)
            {
                return renderError(super.getProperty("sync_organization_fail"));
            }
            return renderSuccess(super.getProperty("oper_success"));
        }
        catch (Exception e)
        {
            return renderError(super.getProperty("sync_organization_fail"));
        }
    }
}
