package com.vms.model;

import java.io.Serializable;

public class VehiclePosInfo implements Serializable
{
    
    private static final long serialVersionUID = 6700813629656881143L;
    
	private String cardnumber;
	
	private long longitude;
	
	private long dimension;
	
	private String displayicon;
    
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}

	public String getCardnumber() 
	{
		return cardnumber;
	}

	public void setCardnumber(String cardnumber) 
	{
		this.cardnumber = cardnumber;
	}

	public long getLongitude() 
	{
		return longitude;
	}

	public void setLongitude(long longitude) 
	{
		this.longitude = longitude;
	}

	public long getDimension() 
	{
		return dimension;
	}

	public void setDimension(long dimension) 
	{
		this.dimension = dimension;
	}

	public String getDisplayicon() 
	{
		return displayicon;
	}

	public void setDisplayicon(String displayicon) 
	{
		this.displayicon = displayicon;
	}

	@Override
	public String toString() 
	{
		return "VehicleInfo [cardnumber=" + cardnumber + ", longitude="
				+ longitude + ", dimension=" + dimension + ", displayicon="
				+ displayicon + "]";
	}

}
