;(function($,app){
    "use strict";
    
    app
    .service("$messager",function($templateCache,$modal){
     var template =[
    	'<div class="modal-header">',
			'<button type="button" class="close" ng-click="close()">&times;</button>',
			'<h4 class="modal-title" ng-bind="title"></h4>',
		'</div>',
		'<div class="modal-body full-width" style="display:inline-block;padding:10px;">',
			'<div class="col-sm-2">',
				'<span ng-if="type==0" class="glyphicon glyphicon-ok-sign" style="font-size:32px;color:#1AA260;"></span>',
				'<span ng-if="type==1" class="glyphicon glyphicon-remove-sign" style="font-size:32px;color:#CF2008;"></span>',
				'<span ng-if="type==2" class="glyphicon glyphicon-exclamation-sign" style="font-size:32px;color:#FDC640;"></span>',
				'<span ng-if="type==3" class="glyphicon glyphicon-question-sign" style="font-size:32px;color:#1AA260;"></span>',
			'</div>',
			'<div class="col-sm-10" ng-bind-html="html" style="margin-top:8px;font-size:14px;"></div>',
		'</div>',
		'<div class="modal-footer" style="margin-top:0;padding:8px;">',
			'<button ng-if="type==2 || type==3" type="button" style="width:60px;margin-top:0;padding:5px;" class="btn btn-primary btn-sm" ng-click="close()">取消</button>',
			'<button type="button" style="width:60px;margin-top:0;padding:5px;" class="btn btn-primary btn-sm" ng-click="sure()">确定</button>',
		'</div>'
		].join("");
    	function newModal(type,$modal,title,html,callback){
    		$modal.open({
    	        template: template,
    	        scope: false,
    	        backdrop: 'static',
    	        keyboard: true,
    	        size: "sm",
    	        controller: function($scope, $modalInstance,$sce) {
    	          $scope.title=title;
    	          $scope.type=type;
    	          $scope.html=$sce.trustAsHtml(html);
    	          $scope.close=function() {$modalInstance.dismiss('cancel');}
    	          $scope.sure=function(){$modalInstance.dismiss('cancel');(callback || angular.noop)($scope,$modalInstance);}
    	        }
    	   });
    	}
    		
    	return {
    		success:function(title,content,callback){newModal(0,$modal,title,content,callback);},//成功提示框
    		error:function(title,content){newModal(1,$modal,title,content);},// 失败提示框
    		warning:function(title,content,callback){newModal(2,$modal,title,content,callback);},//警告提示框
    		confirm:function(title,content,callback){newModal(3,$modal,title,content,callback);}//消息确认框
    	}	
    })
    .service('$map', function($window, $document, $q){
    	  var promise;
    	  this.load = function(){
    	      if(promise){ return promise; }
    	      promise = $q(function(resolve, reject){
    	          $window.initMap = function(){ 
    	        	  //加载maplushu.js,成功后，并执行回调函数
    	        	  $.getScript(basePath + "/static/customize/vims/maplushu.js",function(){ 
    	        		  resolve();
    	        	  });
    	        	  return; 
    	         };
    	          var script = document.createElement("script"); 
    	          script.type = "text/javascript";
    	          script.src = "http://api.map.baidu.com/api?v=2.0&ak=ktMifslxsKlszjkciuhGDaVFb4TTHwt6&callback=initMap";
    	          $document[0].body.appendChild(script);
    	      });
    	      return promise;
    	  };
   });
})(jQuery,app)