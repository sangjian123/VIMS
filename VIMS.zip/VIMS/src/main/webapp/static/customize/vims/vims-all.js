;
(function($, app) {
	"use strict";
	
	app.controller("HistoryTrackCtrl", function($scope, $http,$map,$document,$messager,$timeout) {
		$scope.starttime=new Date().format("yyyy-MM-dd 00:00");
		$scope.endtime=new Date().format("yyyy-MM-dd 00:00");
		
		// 初始化查询所有部门下设备
		$scope.queryVehiclePosition=function(){
			if($scope.starttime > $scope.endtime)
			{
				$messager.warning("提示","结束时间不能早于开始时间!");
				return;
			}
			
			$http({
	        	method: 'POST',
	        	url: basePath + '/vehicle/queryVehicleWtihDept',
	        	params: {"equip_status":0,"cardnumbers":$scope.cardnumbers}
			})
			.success(function(data) {
				// 2维数组 转换为2级树行结构
				$scope.deptVehicalList=[];
				angular.forEach(data.obj.list,function(n,i){
					var o = {"name":n[0].deptName,list:n};
					$scope.deptVehicalList.push(o);
				})
			});
		}
		$scope.queryVehiclePosition();
		$scope.param={};
		$scope.queryVehicleHistory=function(index,car){
			if(!$scope.starttime || !$scope.endtime)
			{
				$messager.warning("提示","请选择开始和结束时间！");
				return;
			}	
			
			$scope.param.type=index;//标记选中项
			$http({
            	method: 'POST',
            	url: basePath + '/vehicle/queryVehicleHistory',
            	params: {"starttime":$scope.starttime,"endtime":$scope.endtime,"cardnumbers":car.cardnumber}
			})
			.success(function(data) {
				// 获取点坐标集
				var points = [],target;  
				angular.forEach(data.obj.list,function(v,i){
					target=v;
					var point = new BMap.Point(v.longitude,v.dimension);
					point.speed=v.speed;
					point.ctime=v.ctime;
					point.mileage=v.mileage;
					point.cardnumber=v.cardnumber;
					points.push(point);
				});
				var viewPort = map.getViewport(points);
				map.clearOverlays();
				map.centerAndZoom(viewPort.center, Math.min(viewPort.zoom,15));
				createBtn(map,points,target);
				// 设置起始点和终点
				createStartEndPoint(map,points);
			});
		}
		var map;
		$map.load().then(function(){
				map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
				map.centerAndZoom(new BMap.Point(116.4035,39.915), 10); 
				map.enableScrollWheelZoom();
				map.addControl(new BMap.NavigationControl());
				map.addControl(new BMap.ScaleControl());
				map.addControl(new BMap.OverviewMapControl());
				map.addControl(new BMap.MapTypeControl({
					mapTypes:[
			            BMAP_NORMAL_MAP,
			            BMAP_HYBRID_MAP
			        ]}));	  
				map.setCurrentCity("北京"); 
		});
		
		function createStartEndPoint(map,points){
			if(!points.length)return;
			// 起始点
			var iconImg = new BMap.Icon(basePath + "/static/customize/images/markers.png", new BMap.Size(25, 40),{  
				anchor: new BMap.Size(12, 38),
				imageSize: new BMap.Size(300,300),  
                imageOffset: new BMap.Size(-200, -139)
            });  
	        var marker = new BMap.Marker(points[0], { icon : iconImg });
	        map.addOverlay(marker);
	        // 终点
	        iconImg = new BMap.Icon(basePath + "/static/customize/images/markers.png", new BMap.Size(25, 40),{ 
	        	anchor: new BMap.Size(12, 38),
				imageSize: new BMap.Size(300,300),  
                imageOffset: new BMap.Size(-225, -139)
            });  
	        marker = new BMap.Marker(points[points.length-1], { icon : iconImg });
	        map.addOverlay(marker);
		}
		
		function carInfo(info){
			return ["<div>",
       				"<div style=\'border-bottom:1px solid #ccc\'><label>车牌号码: ",info.cardnumber,"</label></div>",
       				"<div><label>速度: ",info.speed," 公里/小时</label></div>",
       				"<div><label>里程: ",info.mileage," 公里</label></div>",
       				"<div><label>时间: ",info.ctime,"</label></div>",
               "</div>"].join("");
		}
		
		function createBtn(map,arrPois,v){
			if(!v)return;
			
			// 由于数据原因先构造路径，直接从此处将以下行复制出来 start
			var lushu = new BMapLib.LuShu(map,arrPois,{
            defaultContent:function(f){return carInfo(arrPois[f.i ? f.i+1:f.i]);},
            autoView:true,//是否开启自动视野调整，如果开启那么路书在运动过程中会根据视野自动调整
            icon  : new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34)),
            speed: 3000,
            enableRotation:true,//是否设置marker随着道路的走向进行旋转
            onclick:function(marker,index){
            	var a = arrPois[index];
            	v.angle=marker.getRotation();
            	var gc = new BMap.Geocoder();
	        	gc.getLocation(marker.point, function(rs){
	        		   v.address=rs.address;
	        		   drawInfoWindow(marker,v);
	        		});
			},
			stopCallback:function(){
				console.log('执行结束后回调...');
			},
            landmarkPois: [
//               {lng:116.314782,lat:39.913508,html:'加油站',pauseTime:2},
//               {lng:116.315391,lat:39.964429,html:'高速公路收费',pauseTime:3},
//               {lng:116.381476,lat:39.974073,html:'肯德基早餐',pauseTime:2}
            ]});      
            lushu._addMarker();
            // 行车轨迹线
            	var polyline = new BMap.Polyline(arrPois, {strokeColor:"red", strokeWeight:5, strokeOpacity:0.5});  
            	map.addOverlay(polyline);
            // end
			
			// 定义一个控件类,即function
		    function ZoomControl(left,right,title,type,callback,className){
		      // 默认停靠位置和偏移量
		      this.defaultAnchor = BMAP_ANCHOR_TOP_LEFT;
		      this.defaultOffset = new BMap.Size(left,right); // 距离左上角位置
		      this.callback=callback;
		      this.nodeText=title;
		      this.type=type;
		      this.className=className || "";
		    }

		    // 通过JavaScript的prototype属性继承于BMap.Control
		    ZoomControl.prototype = new BMap.Control();
		    // 自定义控件必须实现自己的initialize方法,并且将控件的DOM元素返回
		    // 在本方法中创建个div元素作为控件的容器,并将其添加到地图容器中
		    ZoomControl.prototype.initialize = function(map){
		      var control = this;
		      // 创建一个DOM元素
		      var div = document.createElement("div");
		      // 设置样式
		      div.className="BMapbtn " + control.className;
		      var span = document.createElement("span");
		      span.className='glyphicon glyphicon-'+control.type;
		      // 添加文字说明
		      div.appendChild(span);
		      div.appendChild(document.createTextNode(control.nodeText));
		      // 绑定事件,点击一次放大两级
		      div.onclick = function(e){
		    	  control.callback();
		      }
		      // 添加DOM元素到地图中
		      map.getContainer().appendChild(div);
		      // 将DOM元素返回
		      return div;
		    }
		    // 创建播放控件
		    var playBtn = new ZoomControl(60, 15,'播放/重播','play',function(){
		    	lushu.start();//map.setZoom(map.getZoom() + 2); // 放大2倍
		    },"bblr");
		    
		    // 创建暂停控件
		    var pauseBtn = new ZoomControl(136, 15,'暂停','pause',function(){
		    	lushu.pause();
		    });
		    
		    // 创建慢进控件
		    var slowForwardBtn = new ZoomControl(202, 15,'慢进','backward',function(){
		    	lushu._opts.speed/=2;
		    });
		    
		    // 创建快进控件
		    var fastForwardBtn = new ZoomControl(268, 15,'快进','forward',function(){
		    	lushu._opts.speed*=2;
		    });
		    
		    // 创建打印控件
		    var printBtn = new ZoomControl(334, 15,'打印','print',function(){
		    	$("#allmap").jqprint({importCSS:true});
		    },"bbrr");
		    
		    // 添加到地图当中
		    map.addControl(playBtn);
		    map.addControl(pauseBtn);
		    map.addControl(slowForwardBtn);
		    map.addControl(fastForwardBtn);
		    map.addControl(printBtn);
		}
		
		function drawInfoWindow(marker,v){
			var html = [
			            	'<div id="infowindow1">',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td style="vertical-align:top;">',
			            						'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            							'<tbody>',
			            								'<tr>',
			            									'<td class="tdinfoaddr" style="padding-bottom:8px"><font color="blue">',v.address,'</font></td>',
			            								'</tr>',
			            							'</tbody>',
			            						'</table>',
			            					'</td>',
			            				'</tr>',
			            			'</tbody>',
			            		'</table>',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td class="tdinfoleft" style="height:2px;" colspan="4"><hr class="horizontal-line" size="1"></td>',
			            				'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft" width="90px">北纬:</td><td class="tdinforight">',marker.point.lat,'</td><td class="tdinfoleft" width="40px">东经:</td><td class="tdinforight">',marker.point.lng,'</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">行驶方向:</td><td class="tdinforight">',$.getAngleDirection(v.angle),'</td><td class="tdinfoleft">速度:</td><td class="tdinforight">',v.speed,' 公里/小时</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">点火开关:</td><td class="tdinforight"><font color="red">无</font></td><td class="tdinfoleft">里程:</td><td class="tdinforight">',v.mileage,' 公里</td>',
			            			'</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">外部电源:</td><td class="tdinforight">无</td><td class="tdinfoleft">空调:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">GSM信号:</td><td class="tdinforight">无</td><td class="tdinfoleft">卫星:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">位置报告时间:</td><td class="tdinforight" colspan="3">',v.ctime,'</td>',
			            		    '</tr>',
			            		   '</tbody>',
			            		  '</table>',
			            		 '</div>'
			            ].join("");
			var infoWindow = new BMap.InfoWindow(html); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
			$timeout(function(){ $('.BMap_top').html("<label style='margin-top:4px;'>车牌号码："+ v.cardnumber +"</label>") },50);
		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("HomeCtrl", function($scope, $http,$state) {
		var firstPage = "vimsportal";
		$scope.tabsContents=[
		                     {name:"实时视频",stateName:"vimsportal.liveVideo"},
		                     {name:"录像回放",stateName:"vimsportal.videoPlayback"},
		                     {name:"车辆定位",stateName:"vimsportal.vehiclePosition"},
		                     {name:"历史轨迹",stateName:"vimsportal.historyTrack"},
							 {name:"运行报表",stateName:"vimsportal.runReport.dailyMileageReportForDrivers"}
							//		                     {name:"驻车防盗",stateName:""},
							//		                     {name:"告警消息",stateName:""},
							//		                     {name:"运营报表",stateName:""},
							//		                     {name:"客户服务",stateName:""}
		            ];
		$scope.goState=function(stateName) { $state.go(stateName,{isRouter:true}); }
		$scope.goState(firstPage);// 默认跳转首页
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("LiveVideoCtrl", function($scope, $http) {
		$http({
        	method: 'POST',
        	url: basePath + '/device/query'
		})
		.success(function(data) {
			$scope.tree=toList(data.obj.list);
		});
		
		function toList(list){
			var temp=[];
			angular.forEach(list,function(v,i){
				listForEach(v,temp);
			})
			return temp;
		}
		
		function listForEach(v,temp){
			if(v.children)
			{
				angular.forEach(v.children,function(m,d){
					temp.push({id:m.id,pid:m.pid,name:m.name});
					listForEach(m,temp);
				})
			}	
		}
		
		$scope.liveVideoScan=function($item,$event){
			if($item.children)return;
			// 初始化控件
			var resultList = [];
			var cameraIp=$item.cameraIp,port=$item.port,userName=$item.username,password=$item.password,channelID=$item.channelID;
	        cfg["stUserInfo"]["User"] = userName;         // 用户名
	        cfg["stUserInfo"]["Password"] = password;      // 密码
	        cfg["stPortInfo"]["szDeviceIp"] = cameraIp;   // 相机IP
	        
	        login(cameraIp,port,userName,password);
	        startVideo(channelID);
		}

		// 分屏显示
		$scope.splitScreen=function(screenNum){}
		
		// js 初始化视频码流变量及方法
		var sdk_viewer = null; // 控件（插件）对象
		var isLogin = false;
		var Main = {
		    EventMap : ""
		}
		Main.EventMap = (function(){
	    var closure = {
	        formatExceotionCode: function(u32ExceptionCode){
	            u32ExceptionCode = u32ExceptionCode.split(',');
	            return parseInt(u32ExceptionCode, 10);
	        },
	        formatTaskNo: function(u32Task_No){
	            u32Task_No = u32Task_No.split(',');
	            return parseInt(u32Task_No, 10);
	        }
	    };
	    return {
			/* 告警事件上报 */
			__200:function(strAlarmInfo){
				//alert(strAlarmInfo);
			}
	      };
	    })();
		
		var cfg = {
	          id: "player",                    //加载的activex控件id
	          container: "playerContainer",    //控件/插件的父节点
	          name: "sdk_viewer",              //实例对象的名称，用于设置napi上报事件的入参
	          events: Main.EventMap,           //控件事件map
	          stPortInfo: {
	              szDeviceIp: "",
	              szLocalIp: "",
	          },                                  //端口信息     
	          stUserInfo: {                        //用户登录信息
	              User: "",
	              Password: ""
	          },
	          maxWnd: 64,                       //控件动态创建窗格的个数，不小于最大通道路数,默认64路 (可选) 
	          focusColor: 'ffcc00',             //窗格获得焦点时的边框颜色，注意：参数形如'xxxxxx'，为颜色的16进制，以b g r 顺序，而不是r g b (可选) 
	          unfocusColor: '747d7d',           //窗格未获得焦点时的边框颜色，注意：参数形如'xxxxxx'，为颜色的16进制，以b g r 顺序，而不是r g b (可选) 
	          backgColor: '373737',             //控件背景色，注意：参数形如'xxxxxx'，为颜色的16进制，以b g r 顺序，而不是r g b (可选)
	         // noCreateWnd: 'true'           
	    }
	   
	   //流类型
	   var StreamType =
	   {
	      LIVE: 0,    //实况流
	      PICTRUE: 1, //抓拍流（jpeg）
	      MJPEG: 2,    //照片流
	      IMAGE_TYPE_PLATE: 3, //过车图片流
	      PIC_VIEW: 4 //图片查看
	    };
		
		var PtzCmd ={
			TILTUP:        	     0x0402,       // 向上
			TILTDOWN:            0x0404,       // 向下
			PANRIGHT:            0x0502,       // 向右
			PANLEFT:             0x0504,       // 向左
			LEFTUP:              0x0702,       // 左上
			LEFTDOWN:            0x0704,       // 左下
			RIGHTUP:             0x0802,       // 右上
			RIGHTDOWN:           0x0804,       // 右下
			ALLSTOP:             0x0901       // 全停命令字 
		}
	     var PresetCmd = {
			SET_PRESET:           0,            // 设置预置位
			CLE_PRESET:           1,            // 清除预置位
			GOTO_PRESET:          2             // 转到预置位
		 }
		 
		 var LiveStream = {
			LIVE_STREAM_INDEX_MAIN:    0,   // 主流
			LIVE_STREAM_INDEX_AUX:     1,   // 辅流
			LIVE_STREAM_INDEX_THIRD:   2    // 第三流
		 }
		 
		 var Protocal = {
			TRANSPROTOCAL_RTPTCP:      1,         //TCP
			TRANSPROTOCAL_RTPUDP:      2          // UDP
		 }
		 
		 var MediaFileFormat = {
			MEDIA_FILE_MP4:            0,           // mp4格式的媒体文件
			MEDIA_FILE_TS:             1            // TS格式的媒体文件  TS media file */
		 }
		 
		 var PictureFormat = {
			PICTURE_BMP:               0,                  // 图片格式为bmp格式
			PICTURE_JPG:               1                   // 图片格式为jpg格式
		 }
		 
		 var EventType ={
			ALL:                       0,        // 所有的存储
			MOTIONDETECTION:           4,        // 运动检测事件存储
			DIGITALINPUT:              5,        // 数字输入事件存储 
			VIDEOLOSS:                 7,        // 视频丢失事件存储
			INVALID:                   0xFF      // 无效值
		}  
	    var PlayControl ={
		    NETDEV_PLAY_CTRL_PLAY:             0,           /* 开始播放  Play */
			NETDEV_PLAY_CTRL_PAUSE:            1,           /* 暂停播放  Pause */
			NETDEV_PLAY_CTRL_RESUME:           2,           /* 恢复播放  Resume */
			NETDEV_PLAY_CTRL_GETPLAYTIME:      3,           /* 获取播放进度  Obtain playing time */
			NETDEV_PLAY_CTRL_SETPLAYTIME:      4,           /* 设置播放进度  Configure playing time */
			NETDEV_PLAY_CTRL_GETPLAYSPEED:     5,           /* 获取播放速度  Obtain playing speed */
			NETDEV_PLAY_CTRL_SETPLAYSPEED:     6,           /* 设置播放速度  Configure playing speed */
			NETDEV_PLAY_CTRL_SINGLE_FRAME:     7            /* 设置单帧播放  Configure single frame playing speed */
		}	
		
		sdk_viewer = new Utils.Player(cfg);                                       //初始化控件 
        var retcode = sdk_viewer.execFunction("NetSDKSetPlayWndNum" , 4);         //分屏 
        if(0!=retcode){
        	console.log("实况窗口实例化失败");
        }
        var DeviceHandle = -1;
        var CloudHandle = -1;
	    
		function login(cameraIp,port,userName,password) {
			var SDKRet = sdk_viewer.execFunction("NETDEV_Login", cameraIp, port, userName, password);
			if(-1 == SDKRet)
			{
				console.log("登录失败");
			}
	        else{ 
			    var result = JSON.parse(SDKRet);
			    DeviceHandle = result.UserID;
		        isLogin = true;
		    }
	       
	    }
		
		// 启流
	    function startVideo(channelID) {
		    var dataMap = {
	                      dwChannelID:channelID, 
	                      dwStreamType:LiveStream.LIVE_STREAM_INDEX_MAIN,
						  dwLinkMode:Protocal.TRANSPROTOCAL_RTPTCP,
						  dwFluency:0
	                      }

	        var jsonStr = JSON.stringify(dataMap);
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			
			var retcode = sdk_viewer.execFunction("NETDEV_RealPlay", parseInt(ResourceId), DeviceHandle, jsonStr);
	        if (0 != retcode) {
	        	console.log("播放实况失败。");
	        } 
	    }
	    
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("LoginCtrl", function($scope, $http) {
		$scope.user={};
		// 点击登陆跳转主页
		$scope.login=function(){
			
			$http.post(basePath + "/doLogin", $scope.user || {}).success(function(result) {
        if (result.success) {
          if($scope.user.loginname == 'root')
          {
            window.location.href = basePath + "/support";
            return;
          } 
          window.location.href = basePath + "/home";
        } else {
          $scope.exception.message = result.msg;
          return;
        }
      })

		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app
	.controller("RunReportCtrl", function($scope, $http, $state,$messager) {
		$scope.param={};
		$scope.param.selected=0;
		$scope.leftMenu=[{id:'21',name:"司机每日里程报表",stateName:"vimsportal.runReport.dailyMileageReportForDrivers"}];
		$scope.goState=function(tab) { $state.go(tab.stateName,{isRouter:true,id:tab.id}); }
		var tab = $scope.leftMenu[$scope.param.selected];
		$scope.goState(tab);// 默认跳转第一个菜单
	})
	.controller("DailyMileageReportForDriversCtrl", function($scope, $http, $state,$messager,$stateParams,$q) {
		if ($stateParams.id === '') {return;} // 路由带入参数后，会执行两次controller（一次带有参数，一次没带参数）
		$scope.options={};
		$scope.options.colums=[
                	{ title:'司机名称', field:'userName'},
                	{ title:'日期', field:'time' },
                	{ title:'起始里程', field:'startMile' },
                	{ title:'结束里程', field:'endMile' },
                	{ title:'当日里程', field:'todayMile' }
		];
		
		$scope.starttime=new Date().format("yyyy-MM-dd");
		$scope.endtime=new Date().format("yyyy-MM-dd");
		
		// 查询驾驶员信息列表
		$scope.init=function(){
			$scope.loading=true;
			$http({
	        	method: 'POST',
	        	url: basePath + '/driver/query'
			})
			.success(function(data) {
				$scope.driverInfos=data.obj.list;
				$scope.query();
			});
		}
		
		$scope.query=function(){
			if(!$scope.starttime || !$scope.endtime)
			{
				$messager.warning("提示","请选择开始和结束时间！");
				return;
			}	
			
			if($scope.starttime > $scope.endtime)
			{
				$messager.warning("提示","结束时间不能早于开始时间!");
				return;
			}
			$scope.loading=true;
			$http({
	        	method: 'POST',
	        	url: basePath + '/driver/queryDetailInfo',
	        	params:{driverName:$scope.driver,starttime:$scope.starttime,endtime:$scope.endtime}
			})
			.success(function(res) {
				var r = res.obj.list;
				$("#driverTable").bootstrapTable('load', r);
				$scope.loading=false;
			});
		}
		
		$scope.exportExcel=function(){
			if($scope.starttime > $scope.endtime)
			{
				$messager.warning("提示","结束时间不能早于开始时间!");
				return;
			}
			window.location.href=basePath+"/driver/exportDetailInfo?driverName="+$scope.driver+"&starttime="+$scope.starttime+"&endtime="+$scope.endtime;
		}
		// 初始化页面
		$scope.init();
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("VehiclePositionCtrl", function($scope, $http,$map,$document,$timeout,$interval) {
		
		// 加载地图
		var map;
		$map.load().then(function(){
			$scope.accountList=[{key:"仅显示在线车辆",value:1},{key:"仅显示离线车辆",value:2}];
			$scope.equip_status=0;
			$scope.queryVehiclePosition=function(){
				$scope.selectOptions=[];
				$http({
	            	method: 'POST',
	            	url: basePath + '/vehicle/queryVehicleWtihDept',
	            	params: {"equip_status":$scope.equip_status || 0,"cardnumbers":$scope.cardnumbers}
				})
				.success(function(data) {
					// 2维数组 转换为2级树行结构
					$scope.deptVehicalList=[];
					angular.forEach(data.obj.list,function(n,i){
						var o = {"name":n[0].deptName,list:n,checked:true};
						$scope.deptVehicalList.push(o);
						angular.forEach(n,function(v,d){v.checked=true;$scope.selectOptions.push(v);})
					})
					query();
				});
			}
			
			//  初始化
			$scope.queryVehiclePosition();
			
			$scope.getSelectOptions1=function(){
				$scope.selectOptions=[];
				angular.forEach($scope.deptVehicalList,function(d,m){
					d.indeterminate=false;
					angular.forEach(d.list,function(v,n){
						v.checked=d.checked;
						if(d.checked)$scope.selectOptions.push(v);
					})
				})
				// 调用接口查询地图数据
				query();
			}
			
			$scope.getSelectOptions2=function(){
				$scope.selectOptions=[];
				angular.forEach($scope.deptVehicalList,function(d,m){
					d.checked=true,d.indeterminate=false;
					var index=0,list = d.list;
					angular.forEach(list,function(v,n){
						// 如果都为true，则勾选父节点，否则撤销父节点勾选
						if(v.checked){$scope.selectOptions.push(v);index++;}else{d.checked=false;}
						d.indeterminate=(list.length!=index && 0!=index);
					})
				})
				// 调用接口查询地图数据
				query();
			}
			
			function query(r){
				$http({
	            	method: 'POST',
	            	url: basePath + '/vehicle/query',
	            	params: {"cardnumbers":getCardnumbers()}
				})
				.success(function(data) {
					var points=[];
					map.clearOverlays();
					angular.forEach(data.obj.list,function(v,i){
						points.push(drawMarker(map,v));
					})
					var viewPort = map.getViewport(points);
					if(!r)map.centerAndZoom(viewPort.center, Math.min(viewPort.zoom,15));
				});
			}
			
			map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
			map.clearOverlays();
			map.centerAndZoom(new BMap.Point(116.4035,39.915), 10);
			map.enableScrollWheelZoom();
			map.enableContinuousZoom();
			map.addControl(new BMap.NavigationControl());
			map.addControl(new BMap.ScaleControl());
			map.addControl(new BMap.OverviewMapControl());
			map.addControl(new BMap.MapTypeControl({
				mapTypes:[
		            BMAP_NORMAL_MAP,
		            BMAP_HYBRID_MAP
		        ]}));	  
			map.setCurrentCity("北京"); 
			// 每隔30秒执行一次
			var timer = $interval(function(){
			     query(true);
			},10000);
			$scope.$on('$destroy',function(){$interval.cancel(timer);});//在离开controller时，清楚定时任务
		});
		
		function drawMarker(map,v){
			var point = new BMap.Point(v.longitude,v.dimension);
			var angle = $.getAngle(new BMap.Point(v.prelongitude,v.predimension),point); // 获取连接方向
	        var iconImg = new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34));  
	        var marker = new BMap.Marker(point, { icon : iconImg });
	        var label = new BMap.Label(v.cardnumber, {offset: new BMap.Size(-15, -30)}); //创建marker点的标记
			marker.setLabel(label);
			marker.setRotation(angle);
	        map.addOverlay(marker);  
	        marker.addEventListener("click", function(){
	        	v.angle=angle;
	        	var gc = new BMap.Geocoder();
	        	gc.getLocation(point, function(rs){
	        		   v.address=rs.address;
	        		   drawInfoWindow(marker,v);
	        		});
			 });
	        return point;
		}
		
		// 以逗号分隔的字符串
		function getCardnumbers()
		{
			var temp=[];
			angular.forEach($scope.selectOptions,function(o,i){
				temp.push(o.cardnumber);
			});
			return temp.join(",");
		}
		
		function drawInfoWindow(marker,v){
			var html = [
			            	'<div id="infowindow">',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td class="tdinfopic"><img class="vims-photo" src="', v.displayicon, '" onerror="javascript:this.src=\''+basePath+ '/static/customize/images/no-image.png\'"></td>',
			            					'<td>',
			            						'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            							'<tbody>',
			            								'<tr>',
			            									'<td class="tdinfotitle" style="white-space:nowrap;"><b>',v.cardnumber,'</b>',//(xxx 138****4564)<br><b>设备编号：</b>无</td>
			            								'</tr>',
			            								'<tr>',
			            									'<td class="tdinfoaddr"><font color="blue">',v.address,'</font></td>',
			            								'</tr>',
			            							'</tbody>',
			            						'</table>',
			            					'</td>',
			            				'</tr>',
			            			'</tbody>',
			            		'</table>',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td class="tdinfoleft" style="height:2px;" colspan="4"><hr class="horizontal-line" size="1"></td>',
			            				'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft" width="70px">北纬:</td><td class="tdinforight">',v.dimension,'</td><td class="tdinfoleft" width="40px">东经:</td><td class="tdinforight">',v.longitude,'</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">行驶方向:</td><td class="tdinforight">',$.getAngleDirection(v.angle),'</td><td class="tdinfoleft">速度:</td><td class="tdinforight">',v.speed,' 公里/小时</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">点火开关:</td><td class="tdinforight"><font color="red">无</font></td><td class="tdinfoleft">里程:</td><td class="tdinforight">',v.mileage,' 公里</td>',
			            			'</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">电源状态:</td><td class="tdinforight">无</td><td class="tdinfoleft">空调:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">GSM信号:</td><td class="tdinforight">无</td><td class="tdinfoleft">卫星:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">最新上报:</td><td class="tdinforight" colspan="3">',v.ctime,'</td>',
			            		    '</tr>',
			            		   '</tbody>',
			            		  '</table>',
			            		 '</div>'
			            ].join("");
			var infoWindow = new BMap.InfoWindow(html); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
			$timeout(function(){ $('.BMap_top').html("<label style='margin-top:4px;'>车牌号码: "+ v.cardnumber +"</label>") },50);
		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("VideoPlaybackCtrl", function($scope, $http,$messager) {
		var videoObj;
		
		$http({
        	method: 'POST',
        	url: basePath + '/device/query'
		})
		.success(function(data) {
			$scope.tree=toList(data.obj.list);
		});
		
		function toList(list){
			var temp=[];
			angular.forEach(list,function(v,i){
				listForEach(v,temp);
			})
			return temp;
		}
		
		function listForEach(v,temp){
			if(v.children)
			{
				angular.forEach(v.children,function(m,d){
					temp.push({id:m.id,pid:m.pid,name:m.name});
					listForEach(m,temp);
				})
			}	
		}
		
		$scope.liveVideoScan=function($item,$event){
			$scope.node=$item.children ? null : $item;
		}
		
		$scope.rate=0;//语速默认为1
		$scope.videoBtn=function(type){
			if(!videoObj)return;
			switch(type){
			case 0:
				videoObj.videoPause();
				break;
			case 1:
				videoObj.videoPlay();
				break;
			case 2:
				$scope.rate--;
				$scope.rate = $scope.rate<0? 0 : $scope.rate;
				videoObj.setPlayBackRate($scope.rate);
				break;
			case 3:
				videoObj.videoForward(-10);
				break;
			case 4:
				videoObj.videoForward(10);
				break;
			case 5:
				$scope.rate++;
				$scope.rate=$scope.rate >3 ? 3 : $scope.rate
				videoObj.setPlayBackRate($scope.rate);
				break;
			}
		}
		
		$scope.queryVideo=function(){
			if(!$scope.videoDate)
			{
				$messager.warning("提示","请选择日期！");
				return;
			}	
			if(!$scope.node)
			{
				$messager.warning("提示","请选择设备！");
				return;
			}
			if(!$scope.equip_status)
			{
				$messager.warning("提示","请选择类型！");
				return;
			}	
			// 查询视频码流呈现html
		}
		
		new TimeLines({ele:".video_timeline"});// 初始化24小时刻度线
		$scope.splitScreen=function($event){
			if($($event.target).closest(".selected").length)return;
			$(".video_position").removeAttr("style");
			var videoContainer=angular.element("#videoScreen");
			videoContainer.empty();
			var screenNum = 1;
			for(var i=0;i<screenNum;i++)
			{
			  var video = document.createElement("div");
			  video.id="video"+i;
			  video.className="fl video-border";
			  videoContainer.append(video);
			  videoObj = new Dvideo ({
					ele: video,
					title: '路口0' + (Number($scope.param.selected) + 1),
					src: 'http://oxyi0vk1f.bkt.clouddn.com/evn4.mp4',
					width:100 / Math.sqrt(screenNum) + "%",
					height:100 / Math.sqrt(screenNum) + "%",
					autoplay: true,
					showNext:false,
					showVideoDefinition:false,
					onTimeupdate:function(v){
						var currentP = Number((v.currentT / v.durationT) * 100);
						currentP = currentP > 100 ? 100 : currentP;
						var type = TimeLines.prototype.formartTimeType(v.durationT);
						$($event.target).closest(".selected").find(".video_position").css({left:'calc('+currentP + '% - 10px)'}).find("a").attr("title",TimeLines.prototype.formartTime(v.currentT,type));
					},
					onLoadedMetaData:function(v){
						var timeLines = new TimeLines({ele:".video_timeline",seconds:v.durationT});// 初始化24小时刻度线
						var iX, iY,btn,dragging,_element = timeLines,btn,_currentT;
						var progressRate = $($event.target).closest(".selected");
						progressRate.siblings(".progress_rate").andSelf().find(".video_position").off("mousedown");
						progressRate.find(".video_position").on("mousedown",function(event){
							v.videoPause();
							dragging = true;
							btn = $(this);
							var e = event || window.event
							e.stopPropagation();
			                iX = e.clientX - this.offsetLeft;
			                progressRate.on("mousemove",function (event) {
								var e = event || window.event;
								if(dragging && btn){
									var oX = e.clientX - iX;
									if(oX+10<=0){ oX=-10; }
									else if(oX+10>=($(_element.opt.ele).width()-40)){ oX=$(_element.opt.ele).width()-40-10; }
									btn.css({"left":oX + "px"});
									_currentT = (oX+10)*_element.opt.pxSecondsUnit;
									btn.children("a").attr('title',TimeLines.prototype.formartTime((oX+10)*_element.opt.pxSecondsUnit,TimeLines.prototype.formartTimeType(_element.opt.seconds)));//算时间就要加上-10px
									return false;
								}
							});
							progressRate.on("mouseup mouseleave",function(event){ var e = event || window.event; e.stopPropagation();if(btn){ dragging=false; startVideoContinue(_currentT,v);btn=null;}return false; })
						})
					}
				});
			}	
		}
		
		function startVideoContinue(_currentT,_video){
			var _diff = _currentT - _video.currentT;
    		_video.videoForward(_diff);
    		_video.videoPlay();
		}
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("DeptManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/organization/datagrid";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'id', field:'id', visible:false },
                	{ title:'部门名称', field:'name'},
                	{ title:'部门地址', field:'address' },
                	{ title:'创建日期', field:'createTime', sortable:true },
                	{ title:'备注', field:'description', align:'center' }
            	]
		$scope.operateDept=function(isEdit){
		  debugger
      $scope.organization=null;
      var uri="add";
      if(isEdit)
      {
        var row = $("#deptList").bootstrapTable('getSelections');
        if(row.length==0 || row.length>1)
        {
          $messager.warning("提示","请选择一行，进行修改！");
          return;
        } 
        $scope.organization = row[0];
        uri="edit";
      } 
			$modal.open({
	          	templateUrl:basePath + "/organization/deptInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	resolve : { organization : function() { return $scope.organization; }},
	          	controller:function($scope,$modalInstance,organization){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
	          		$scope.organization=organization;
	          		$scope.saveDept=function(){ 
	          		  debugger
	          		  $http.post(basePath + "/organization/"+uri, $scope.organization || {}).success(function(result) {
	                  if (result.success) {
	                    $messager.success("提示", "操作成功");
	                    $modalInstance.dismiss('cancel'); 
	                    $("#deptList").bootstrapTable('refresh');
	                  }else{
	                    $messager.error("提示", result.msg);
	                  }
	                });
	          		  
	          		}
	          	}
	          });
		}
		$scope.deleteDept=function(){ 
		  var row = $("#deptList").bootstrapTable('getSelections');
      if(row.length==0 || row.length>1)
      {
        $messager.warning("提示","请选择一行！");
        return;
      } 
      $scope.organization = row[0];
      $http.post(basePath + "/organization/delete", $scope.organization || {}).success(function(result) {
        if (result.success) {
          $messager.success("提示", "操作成功");
          $("#deptList").bootstrapTable('refresh');
        }else{
          $messager.error("提示", result.msg);
        }
      });
      
    }
		
	})
})(jQuery, app);
(function($, app) {
  "use strict";
  // 模板管理
  app.controller("userModelCtrl", function($scope, $http, $timeout, $compile,
      $element) {

    // 树
    $scope.demo = {};
    $scope.user = {};

    $.ajax({
      type : "POST",
      url : basePath + '/role/tree',
      dataType : "html",
      contentType : "application/json",
      data : JSON.stringify($scope.user),
      async : true,
      success : function(result) {
        if (result) {
          result = JSON.parse(result);
        }
        if (result.success) {
          $timeout(function() {
            $scope.$apply(function() {
              $scope.demo.tree = eval(result.obj.list);
              var checkedData = $.tree($scope.demo.tree).checked;
              var content = [];
              angular.forEach(checkedData, function(data, index) {
                content.push(data.text);
              });
              $scope.content = content.join(",");
            });
          });

        } else {
          $.messager.alert($.i18n.prop('ami.common.warning'), $.i18n
              .prop('ami.role.waring_message'), 'warning');
        }
      }
    });

    $scope.sure = function() {
      var checkedData = $.tree($scope.demo.tree).checked;
      var content = [];
      var roleId = [];
      angular.forEach(checkedData, function(data, index) {
        content.push(data.text);
        roleId.push(data.id);
      });
      $scope.content = content.join(",");
      $scope.user.roleIds = roleId.join(",");

    }
    
 // 新增
    $scope.addUser = function(row) {
      
          $http.post(basePath + "/user/add", $scope.user || {}).success(function(result) {
            if (result.success) {
              $.model.close(m);
              $.messager.alert($.i18n.prop('ami.common.info'), $.i18n.prop('ami.role.save_success'), 'info');
              $("#userTable").datagrid('reload');
            }else{
              $.messager.alert($.i18n.prop('ami.common.warning'), result.msg, 'warning');
            }
          });
        };


  });

})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("OperatorManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/user/dataGrid";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'ID', field:'id', visible:false },
                	{ title:'用户名', field:'loginname'},
                	{ title:'昵称', field:'nickName', sortable:true },
                	{ title:'所属部门', field:'belongDept', sortable:true },
                	{ title:'电话', field:'phone'},
                	{ title:'角色', field:'roleName'},
                	{ title:'状态', field:'status' , formatter:function(value,row,index){
                    return value==0 ? '正常' : '禁用';
                  } },
                	{ title:'创建日期', field:'createdate', sortable:true },
                	{ title:'更新日期', field:'updatedate', sortable:true }
            	]
		$scope.operationUser=function(isEdit){
		  debugger
		  $scope.user=null;
		  var uri="add";
      if(isEdit)
      {
        var row = $("#operatorList").bootstrapTable('getSelections');
        if(row.length==0 || row.length>1)
        {
          $messager.warning("提示","请选择一行，进行修改！");
          return;
        } 
        $scope.user = row[0];
         uri="edit";
      } 
			$modal.open({
      	templateUrl:basePath + "/user/operatorInfo",
      	scope:false,
      	backdrop:'static',
      	keyboard:true,
      	size:"defalut",
      	resolve : { user : function() { return $scope.user; }},
      	controller:function($scope,$modalInstance,user){
      		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
      		$scope.user=user;
      	// 新增
          $scope.addUser = function() {
            debugger
                $http.post(basePath + "/user/"+uri, $scope.user || {}).success(function(result) {
                  if (result.success) {
                    $messager.success("提示", "操作成功");
                    $modalInstance.dismiss('cancel'); 
                    $("#operatorList").bootstrapTable('refresh');
                  }else{
                    $messager.error("提示", result.msg);
                  }
                });
              }
      	}
	    });
		}
		 $scope.deleteUser = function() {
		   var row = $("#operatorList").bootstrapTable('getSelections');
       if(row.length==0 || row.length>1)
       {
         $messager.warning("提示","请选择一行！");
         return;
       } 
       $scope.user = row[0];
       $http.post(basePath + "/user/delete", $scope.user || {}).success(function(result) {
         if (result.success) {
           $messager.success("提示", "操作成功");
           $("#operatorList").bootstrapTable('refresh');
         }else{
           $messager.error("提示", result.msg);
         }
       });
     };
		
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("RoleManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/role/query";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'id', field:'id', visible:false },
                	{ title:'名称', field:'name'},
                	{ title:'描述', field:'description', sortable:true },
                	{ title:'状态', field:'status', formatter:function(value,row,index){
                             return value==0 ? '正常' : '禁用';
                         } 
                	}
            	]
		$scope.operationRole=function(isEdit){
			$scope.role=null;
			if(isEdit)
      		{
      			var row = $("#roleList").bootstrapTable('getSelections');
      			if(row.length==0 || row.length>1)
      			{
      				$messager.warning("提示","请选择一行，进行修改！");
      				return;
      			}	
      			$scope.role = row[0];
      		}	
			
			$modal.open({
	          	templateUrl:basePath + "/role/roleInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	resolve : { role : function() { return $scope.role; }},
	          	controller:function($scope,$modalInstance,role){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
	          		$scope.role=role;
	          		// 新增
	               $scope.addOrEditRole = function() {
	                    $http.post(basePath + "/role/editRole", $scope.role || {}).success(function(result) {
	                      if (result.success) {
	                        $messager.success("提示", "操作成功");
	                        $modalInstance.dismiss('cancel'); 
	                        $("#roleList").bootstrapTable('refresh');
	                      }else{
	                        $messager.error("提示", result.msg);
	                      }
	                    });
	                  }
	                 
	          	}
	          });
		}
		
		 
    $scope.deleteRole=function(){
      debugger
      var row = $("#roleList").bootstrapTable('getSelections');
      if(row.length==0 || row.length>1)
      {
        $messager.warning("提示","请选择一行！");
        return;
      } 
      $scope.role = row[0];
      $http.post(basePath + "/role/delete", $scope.role || {}).success(function(result) {
        if (result.success) {
          $messager.success("提示", "操作成功");
          $("#roleList").bootstrapTable('refresh');
        }else{
          $messager.error("提示", result.msg);
        }
      });
    }
	})
})(jQuery, app);
(function($, app) {
	"use strict";
	
	app.controller("SupportCtrl", function($scope, $http,$state) {
		var firstPage = "vimssupport";
		
		$scope.menus =[
					                 {
					                  id:'1000',name:'组织与权限',children:[
											                                                   {id:'10001',name:'角色管理',stateName:'vimssupport.roleManager'},
											                                                   {id:'10002',name:'部门管理',stateName:'vimssupport.deptManager'},
											                                                   {id:'10003',name:'操作员管理',stateName:'vimssupport.operManager'},
											                                                   {id:'10004',name:'工作流管理',stateName:'vimssupport.workflowManager'}
											                                                ]
					                 },
					                 {
					                	 id:'1002',name:'设备管理',children:[
									 		                                                   {id:'10021',name:'绑定设备与车辆',stateName:''},
									 		                                                   {id:'10022',name:'设备分组管理',stateName:''},
									 		                                                   {id:'10023',name:'设备参数一键设定',stateName:''}
									 		                                                ]
					                 }
					              ];
		  $scope.tabsContents=[];
		  $scope.param={};
		  $scope.tabs=function(tab)
		  {
			  if($scope.tabsContents.indexOf(tab) <= -1) { $scope.tabsContents.push(tab); }	  
			  $scope.param.active = $scope.tabsContents.indexOf(tab);
			  $scope.goState(tab.stateName);
		  }
		  $scope.closeTab=function(tab,index)
		  {
			  if(index <= $scope.param.active)$scope.param.active--;
			  $scope.tabsContents.remove(tab);
			  var tab = $scope.tabsContents[$scope.param.active];
			  $scope.goState(tab ? tab.stateName : firstPage);
		  }
		  $scope.goState=function(stateName) { $state.go(stateName ? stateName : firstPage,{isRouter:true}); }
		  $scope.goState(firstPage);// 默认跳转首页
	})
})(jQuery, app);(function($,app){
    "use strict";
    
    app
    .service("$messager",function($templateCache,$modal){
     var template =[
    	'<div class="modal-header">',
			'<button type="button" class="close" ng-click="close()">&times;</button>',
			'<h4 class="modal-title" ng-bind="title"></h4>',
		'</div>',
		'<div class="modal-body full-width" style="display:inline-block;padding:10px;">',
			'<div class="col-sm-2">',
				'<span ng-if="type==0" class="glyphicon glyphicon-ok-sign" style="font-size:32px;color:#1AA260;"></span>',
				'<span ng-if="type==1" class="glyphicon glyphicon-remove-sign" style="font-size:32px;color:#CF2008;"></span>',
				'<span ng-if="type==2" class="glyphicon glyphicon-exclamation-sign" style="font-size:32px;color:#FDC640;"></span>',
				'<span ng-if="type==3" class="glyphicon glyphicon-question-sign" style="font-size:32px;color:#1AA260;"></span>',
			'</div>',
			'<div class="col-sm-10" ng-bind-html="html" style="margin-top:8px;font-size:14px;"></div>',
		'</div>',
		'<div class="modal-footer" style="margin-top:0;padding:8px;">',
			'<button ng-if="(type==2 || type==3) && single" type="button" style="width:60px;margin-top:0;padding:5px;" class="btn btn-primary btn-sm" ng-click="close()">取消</button>',
			'<button type="button" style="width:60px;margin-top:0;padding:5px;" class="btn btn-primary btn-sm" ng-click="sure()">确定</button>',
		'</div>'
		].join("");
    	function newModal(type,$modal,title,html,callback){
    		$modal.open({
    	        template: template,
    	        scope: false,
    	        backdrop: 'static',
    	        keyboard: true,
    	        size: "sm",
    	        controller: function($scope, $modalInstance,$sce) {
    	          $scope.title=title;
    	          $scope.type=type;
    	          $scope.single=('undefined' != typeof callback);
    	          $scope.html=$sce.trustAsHtml(html);
    	          $scope.close=function() {$modalInstance.dismiss('cancel');}
    	          $scope.sure=function(){$modalInstance.dismiss('cancel');(callback || angular.noop)($scope,$modalInstance);}
    	        }
    	   });
    	}
    		
    	return {
    		success:function(title,content,callback){newModal(0,$modal,title,content,callback);},//成功提示框
    		error:function(title,content){newModal(1,$modal,title,content);},// 失败提示框
    		warning:function(title,content,callback){newModal(2,$modal,title,content,callback);},//警告提示框
    		confirm:function(title,content,callback){newModal(3,$modal,title,content,callback);}//消息确认框
    	}	
    })
    .service('$map', function($window, $document, $q){
    	  var promise;
    	  this.load = function(){
    	      if(promise){ return promise; }
    	      promise = $q(function(resolve, reject){
    	          $window.initMap = function(){ 
    	        	  //加载maplushu.js,成功后，并执行回调函数
    	        	  $.getScript(basePath + "/static/customize/vims/maplushu.js",function(){ 
    	        		  resolve();
    	        	  });
    	        	  return; 
    	         };
    	          var script = document.createElement("script"); 
    	          script.type = "text/javascript";
    	          script.src = "http://api.map.baidu.com/api?v=2.0&ak=ktMifslxsKlszjkciuhGDaVFb4TTHwt6&callback=initMap";
    	          $document[0].body.appendChild(script);
    	      });
    	      return promise;
    	  };
   });
})(jQuery,app)