;
(function($, app) {
	"use strict";
	
	app.controller("OperatorManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/user/dataGrid";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'ID', field:'id', visible:false },
                	{ title:'用户名', field:'loginname'},
                	{ title:'昵称', field:'nickName', sortable:true },
                	{ title:'所属部门', field:'belongDept', sortable:true },
                	{ title:'电话', field:'phone'},
                	{ title:'角色', field:'roleName'},
                	{ title:'状态', field:'status' , formatter:function(value,row,index){
                    return value==0 ? '正常' : '禁用';
                  } },
                	{ title:'创建日期', field:'createdate', sortable:true },
                	{ title:'更新日期', field:'updatedate', sortable:true }
            	]
		$scope.operationUser=function(isEdit){
		  debugger
		  $scope.user=null;
		  var uri="add";
      if(isEdit)
      {
        var row = $("#operatorList").bootstrapTable('getSelections');
        if(row.length==0 || row.length>1)
        {
          $messager.warning("提示","请选择一行，进行修改！");
          return;
        } 
        $scope.user = row[0];
         uri="edit";
      } 
			$modal.open({
      	templateUrl:basePath + "/user/operatorInfo",
      	scope:false,
      	backdrop:'static',
      	keyboard:true,
      	size:"defalut",
      	resolve : { user : function() { return $scope.user; }},
      	controller:function($scope,$modalInstance,user){
      		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
      		$scope.user=user;
      	// 新增
          $scope.addUser = function() {
            debugger
                $http.post(basePath + "/user/"+uri, $scope.user || {}).success(function(result) {
                  if (result.success) {
                    $messager.success("提示", "操作成功");
                    $modalInstance.dismiss('cancel'); 
                    $("#operatorList").bootstrapTable('refresh');
                  }else{
                    $messager.error("提示", result.msg);
                  }
                });
              }
      	}
	    });
		}
		 $scope.deleteUser = function() {
		   var row = $("#operatorList").bootstrapTable('getSelections');
       if(row.length==0 || row.length>1)
       {
         $messager.warning("提示","请选择一行！");
         return;
       } 
       $scope.user = row[0];
       $http.post(basePath + "/user/delete", $scope.user || {}).success(function(result) {
         if (result.success) {
           $messager.success("提示", "操作成功");
           $("#operatorList").bootstrapTable('refresh');
         }else{
           $messager.error("提示", result.msg);
         }
       });
     };
		
	})
})(jQuery, app)