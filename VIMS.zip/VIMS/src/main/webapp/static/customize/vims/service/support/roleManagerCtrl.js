;
(function($, app) {
	"use strict";
	
	app.controller("RoleManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/role/query";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'id', field:'id', visible:false },
                	{ title:'名称', field:'name'},
                	{ title:'描述', field:'description', sortable:true },
                	{ title:'状态', field:'status', formatter:function(value,row,index){
                             return value==0 ? '正常' : '禁用';
                         } 
                	}
            	]
		$scope.operationRole=function(isEdit){
			$scope.role=null;
			if(isEdit)
      		{
      			var row = $("#roleList").bootstrapTable('getSelections');
      			if(row.length==0 || row.length>1)
      			{
      				$messager.warning("提示","请选择一行，进行修改！");
      				return;
      			}	
      			$scope.role = row[0];
      		}	
			
			$modal.open({
	          	templateUrl:basePath + "/role/roleInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	resolve : { role : function() { return $scope.role; }},
	          	controller:function($scope,$modalInstance,role){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
	          		$scope.role=role;
	          		// 新增
	               $scope.addOrEditRole = function() {
	                    $http.post(basePath + "/role/editRole", $scope.role || {}).success(function(result) {
	                      if (result.success) {
	                        $messager.success("提示", "操作成功");
	                        $modalInstance.dismiss('cancel'); 
	                        $("#roleList").bootstrapTable('refresh');
	                      }else{
	                        $messager.error("提示", result.msg);
	                      }
	                    });
	                  }
	                 
	          	}
	          });
		}
		
		 
    $scope.deleteRole=function(){
      debugger
      var row = $("#roleList").bootstrapTable('getSelections');
      if(row.length==0 || row.length>1)
      {
        $messager.warning("提示","请选择一行！");
        return;
      } 
      $scope.role = row[0];
      $http.post(basePath + "/role/delete", $scope.role || {}).success(function(result) {
        if (result.success) {
          $messager.success("提示", "操作成功");
          $("#roleList").bootstrapTable('refresh');
        }else{
          $messager.error("提示", result.msg);
        }
      });
    }
	})
})(jQuery, app)