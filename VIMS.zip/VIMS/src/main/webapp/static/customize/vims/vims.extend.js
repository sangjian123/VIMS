(function($,window){
  
	// 扩展数组删除指定元素的方法
	Array.prototype.remove = function(val) {
	  var index = this.indexOf(val);
	  if (index > -1) {
	    this.splice(index, 1);
	  }
	};
	
	// 检索下标
	$.findMenuIndex=function(menus,stateName,compareAttr)
	{
		if(!stateName)return -1;
		var menuTabIndex=-1;
		for(var m in menus) { if(stateName===menus[m][compareAttr]) { menuTabIndex = m;break; } }	
		return Number(menuTabIndex);
	}
	
	//获得开始坐标和终点坐标连线，与y轴正半轴之间的夹角
	$.getAngle=function(pointStart,pointEnd){
        var px=pointStart.lat,py=pointStart.lng,mx=pointEnd.lat,my=pointEnd.lng;
    	var x = Math.abs(px-mx);
        var y = Math.abs(py-my);
        var z = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
        var cos = y/z;
        var radina = Math.acos(cos);//用反三角函数求弧度
        var angle = Math.floor(180/(Math.PI/radina));//将弧度转换成角度
        //鼠标在第四象限
        if(mx>px&&my>py){ angle = 180 - angle; }
        //鼠标在y轴负方向上
        if(mx==px&&my>py){ angle = 180; }
        //鼠标在x轴正方向上
        if(mx>px&&my==py){ angle = 90; }
        //鼠标在第三象限
        if(mx<px&&my>py){ angle = 180+angle; }
        //鼠标在x轴负方向
        if(mx<px&&my==py){ angle = 270; }
        //鼠标在第二象限
        if(mx<px&&my<py){ angle = 360 - angle; }
        return angle;
    }
	
	// 初始车头正西方向开始计算
	$.getAngleDirection=function(num)
	{
		var num=parseInt(num)  
	    var N='北';  
	    var E='东';  
	    var S='南';  
	    var W='西';  
	    var dir='';  
	          
	    if(num==0||num==360 || num==-360){  
	        dir='正'+W;  
	    }else if((num<90&&num>0) || (num<-270 && num > -360)){  
	        if(num<45 || num < -315){
	            dir=W + N + '偏' + W;  
	        }else if(num==45 || num==-315){  
	            dir=W + N;  
	        }else if(num>45 || num > -315){  
	            dir=W + N + '偏' + N; 
	        }  
	    }else if(num==90 || num==-270){
	        dir='正' + N;  
	    }else if((num<180&&num>90) || (num < -180 && num > -270)){  
	        if(num<135 || num < -225){  
	            dir=E + N + '偏'+ N;  
	        }else if(num==135 || num==-225){  
	            dir=E + N;  
	        }else if(num>135 || num>-225){  
	            dir=E + N + '偏'+ E;  
	        }  
	    }else if(num==180 || num==-180){  
	        dir='正'+ E;  
	    }else if((num<270&&num>180) || (num>-180 && num<-90)){  
	        if(num<225 || num<-135){  
	            dir=E + S + '偏' + E;
	        }else if(num==225 || num==-135){  
	            dir=E + S;  
	        }else if(num>225 || num>-135){  
	            dir=E + S + '偏' + S;  
	        }  
	    }else if(num==270 || num==-90){  
	        dir='正'+ S;  
	    }else if((num<360&&num>270) || (num<0 && num>-90)){  
	        if(num<315 || num<-45){
	            dir=W+S + '偏'+ S;  
	        }else if(num==315 || num==-45){  
	            dir=W+S;  
	        }else if(num>315 || num>-45){  
	            dir=W+S +'偏'+ W;  
	        }  
	    }  
	      
	    return dir;  
	}
})(jQuery,window)