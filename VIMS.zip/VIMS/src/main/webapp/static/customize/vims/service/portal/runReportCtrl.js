;
(function($, app) {
	"use strict";
	
	app
	.controller("RunReportCtrl", function($scope, $http, $state,$messager) {
		$scope.param={};
		$scope.param.selected=0;
		$scope.leftMenu=[{id:'21',name:"司机每日里程报表",stateName:"vimsportal.runReport.dailyMileageReportForDrivers"}];
		$scope.goState=function(tab) { $state.go(tab.stateName,{isRouter:true,id:tab.id}); }
		var tab = $scope.leftMenu[$scope.param.selected];
		$scope.goState(tab);// 默认跳转第一个菜单
	})
	.controller("DailyMileageReportForDriversCtrl", function($scope, $http, $state,$messager,$stateParams,$q) {
		if ($stateParams.id === '') {return;} // 路由带入参数后，会执行两次controller（一次带有参数，一次没带参数）
		$scope.options={};
		$scope.options.colums=[
                	{ title:'司机名称', field:'userName'},
                	{ title:'日期', field:'time' },
                	{ title:'起始里程', field:'startMile' },
                	{ title:'结束里程', field:'endMile' },
                	{ title:'当日里程', field:'todayMile' }
		];
		
		$scope.starttime=new Date().format("yyyy-MM-dd");
		$scope.endtime=new Date().format("yyyy-MM-dd");
		
		// 查询驾驶员信息列表
		$scope.init=function(){
			$scope.loading=true;
			$http({
	        	method: 'POST',
	        	url: basePath + '/driver/query'
			})
			.success(function(data) {
				$scope.driverInfos=data.obj.list;
				$scope.query();
			});
		}
		
		$scope.query=function(){
			if(!$scope.starttime || !$scope.endtime)
			{
				$messager.warning("提示","请选择开始和结束时间！");
				return;
			}	
			
			if($scope.starttime > $scope.endtime)
			{
				$messager.warning("提示","结束时间不能早于开始时间!");
				return;
			}
			$scope.loading=true;
			$http({
	        	method: 'POST',
	        	url: basePath + '/driver/queryDetailInfo',
	        	params:{driverName:$scope.driver,starttime:$scope.starttime,endtime:$scope.endtime}
			})
			.success(function(res) {
				var r = res.obj.list;
				$("#driverTable").bootstrapTable('load', r);
				$scope.loading=false;
			});
		}
		
		$scope.exportExcel=function(){
			if($scope.starttime > $scope.endtime)
			{
				$messager.warning("提示","结束时间不能早于开始时间!");
				return;
			}
			window.location.href=basePath+"/driver/exportDetailInfo?driverName="+$scope.driver+"&starttime="+$scope.starttime+"&endtime="+$scope.endtime;
		}
		// 初始化页面
		$scope.init();
	})
})(jQuery, app)