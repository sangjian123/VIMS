;(function($, app) {
	"use strict";
	
	app.controller("VideoPlaybackCtrl", function($scope, $http,$messager,$sdkViewer) {
		$http({
        	method: 'POST',
        	url: basePath + '/device/query'
		})
		.success(function(data) {
			$scope.tree=toList(data.obj.list);
		});
		
		function toList(list){
			var temp=[];
			angular.forEach(list,function(v,i){
				listForEach(v,temp);
			})
			return temp;
		}
		
		function listForEach(v,temp){
			if(v.children)
			{
				angular.forEach(v.children,function(m,d){
					temp.push(m);
					listForEach(m,temp);
				})
			}	
		}
		
		$scope.vedioTypeList=[{key:'普通',value:'0'}, {key:'事件',value:'1'}];
		
		$scope.node={};
		$scope.liveVideoScan=function($item,$event){
			if($item.children)return;
			$scope.node=$item;
		}
		
		$scope.queryVideo=function(){
			if(!$scope.starttime || !$scope.endtime)
			{
				$messager.warning("提示","请选择开始时间和结束时间！");
				return;
			}	
			
			if($scope.starttime > $scope.endtime)
			{
				$messager.warning("提示","结束时间不能早于开始时间!");
				return;
			}
			
			if(!$scope.node)
			{
				$messager.warning("提示","请选择设备！");
				return;
			}
			if(!$scope.vedioType)
			{
				$messager.warning("提示","请选择类型！");
				return;
			}	
			
			// 回放调用
			// 设备登陆
			var $item = $scope.node;
			$scope.videoGroup={};
	        if(Cloudlogin($item,$item.url,$item.userName,$item.password) && Devlogin($item,$item.devName,$item.devPassword)) {
	        	if($scope.vedioType==0) { CommnQuery($item,$scope.starttime,$scope.endtime); }	// 普通
	        	else if($scope.vedioType==1) { CommnQuery($item,$scope.starttime,$scope.endtime); }	// 异常
	        }	
		}
		
		/******************** 回放 ***************************/
		function getLocalTime(nS){     
			return new Date(parseInt(nS) * 1000).toLocaleString().substr(0,17)   
								} 
		var EventType ={
				ALL:                       0,        // 所有的存储
				MOTIONDETECTION:           4,        // 运动检测事件存储
				DIGITALINPUT:              5,        // 数字输入事件存储 
				VIDEOLOSS:                 7,        // 视频丢失事件存储
				INVALID:                   0xFF      // 无效值
			}  
		
		var Protocal = {
				TRANSPROTOCAL_RTPTCP:      1,         //TCP
				TRANSPROTOCAL_RTPUDP:      2          // UDP
			 }
		
		var PlayControl ={
			    NETDEV_PLAY_CTRL_PLAY:             0,           /* 开始播放  Play */
				NETDEV_PLAY_CTRL_PAUSE:            1,           /* 暂停播放  Pause */
				NETDEV_PLAY_CTRL_RESUME:           2,           /* 恢复播放  Resume */
				NETDEV_PLAY_CTRL_GETPLAYTIME:      3,           /* 获取播放进度  Obtain playing time */
				NETDEV_PLAY_CTRL_SETPLAYTIME:      4,           /* 设置播放进度  Configure playing time */
				NETDEV_PLAY_CTRL_GETPLAYSPEED:     5,           /* 获取播放速度  Obtain playing speed */
				NETDEV_PLAY_CTRL_SETPLAYSPEED:     6,           /* 设置播放速度  Configure playing speed */
				NETDEV_PLAY_CTRL_SINGLE_FRAME:     7            /* 设置单帧播放  Configure single frame playing speed */
			}	
		
		var VideoParam={
				VIDEOPATH:"C:\\NETDEV_\\DownLoad\\"
		}
		
		var MediaFileFormat = {
				MEDIA_FILE_MP4:            0,           // mp4格式的媒体文件
				MEDIA_FILE_TS:             1            // TS格式的媒体文件  TS media file */
			 }
		
		var $sdk=$sdkViewer.initSdkViewer("videoScreen");
		var sdk_viewer = $sdk.sdk;
		
		$scope.splitScreen=function(splitNum){
			var retcode = sdk_viewer.execFunction("NetSDKSetPlayWndNum" , splitNum);         //分屏 
	        if(0!=retcode){
	        	$messager.error("提示","实况窗口实例化失败");
	        }
		}
		$scope.splitScreen(4);// 分屏
		 // 云登陆
        function Cloudlogin($item,cameraIp,userName,password)
    	{
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloud", cameraIp,userName, password);
    		if(-1 == SDKRet)
    		{
    			$messager.error("提示","云登录失败");
    			return false;
    		}
            else{
            	$item.CloudHandle = SDKRet;
            	return true;
    		}
    	}
        
        // 设备登陆
        function Devlogin($item,cloudDevName,password)
    	{
    		var dataMap = { szDeviceName:cloudDevName, szDevicePassword:password, dwT2UTimeout:0 }
            var jsonStr = JSON.stringify(dataMap);
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloudDev", $item.CloudHandle || -1, jsonStr);
    		if(-1 == SDKRet)
    		{
    			$messager.error("提示","设备登录失败");
    			return false;
    		}
            else{
    		    var result = JSON.parse(SDKRet);
    		    $item.DeviceHandle = result.UserID;	
    		    var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
            	$scope.videoGroup[ResourceId]=$item;
    	        return true;
    		}
    	}
		
		function CommnQuery($item,starttime,endtime){
			var vBeginTime = (new Date(Date.parse(starttime)).getTime())/1000;
			var vEndTime = (new Date(Date.parse(endtime)).getTime())/1000;
			var dataMap = {
						  szFileName:0,
	                      dwChannelID:$scope.node.channelID || 1, 
	                      dwFileType:EventType.ALL,
						  tBeginTime:vBeginTime,
						  tEndTime:vEndTime
	                      }

	        var jsonStr = JSON.stringify(dataMap);
		    var SDKRet = sdk_viewer.execFunction("NETDEV_FindFile",$item.DeviceHandle,jsonStr);
			if(-1 != SDKRet)
			{
				console.log("获取视频回放文件...");
				FindNextFile(SDKRet,vBeginTime,vEndTime);
			}
			else{
				$messager.error("提示","找不到文件");
			}
	    }
		
		function FindNextFile(handle,vBeginTime,vEndTime)
		{
			var SDKRet = sdk_viewer.execFunction("NETDEV_FindNextFile",handle);
			if(-1 == SDKRet)
			{
				$messager.error("提示","找不到文件");
			}
			else
			{
				var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
				var $$video = $scope.videoGroup[ResourceId];
				if(!$$video)return;
				$$video.vBeginTime=vBeginTime;
				$$video.vEndTime=vEndTime;
				$scope.playbackbytime();
			}	
		}
		
		$scope.playbackbytime=function(e){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
			var dataMap = {
						  dwChannelID:$scope.node.channelID || 1, 
						  tBeginTime:$$video.vBeginTime,
						  tEndTime:$$video.vEndTime,
						  dwLinkMode:Protocal.TRANSPROTOCAL_RTPTCP,
						  dwFileType:EventType.ALL,
						  dwDownloadSpeed:3
	                      }
	        var jsonStr = JSON.stringify(dataMap);
		    var retcode = sdk_viewer.execFunction("NETDEV_PlayBack", parseInt(ResourceId), $$video.DeviceHandle,jsonStr);
			if(-1 == retcode)
			{
				$messager.error("提示","回放失败");
			}
	    }
		
		$scope.stopplayback=function(e){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
		    var retcode = sdk_viewer.execFunction("NETDEV_StopPlayback", ResourceId);
			if(0 != retcode)
			{
				$messager.error("提示","停止回放失败");
			}
	    }
		
		$scope.downloadbytime=function(e){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
			var dataMap = {
						  dwChannelID:$$video.channelID || 1, 
						  tBeginTime:$$video.vBeginTime,
						  tEndTime:$$video.vEndTime,
						  dwLinkMode:Protocal.TRANSPROTOCAL_RTPTCP,
						  dwFileType:EventType.ALL,
						  dwDownloadSpeed:3
	                      }
			var jsonStr = JSON.stringify(dataMap);
		    var retcode = sdk_viewer.execFunction("NETDEV_GetFileByTime",$$video.DeviceHandle ,jsonStr , VideoParam.VIDEOPATH + $scope.node.devName + "_" + new Date().getTime(), MediaFileFormat.MEDIA_FILE_MP4);
			if(-1 == retcode)
			{
				$messager.error("提示","下载失败");
			}
			$$video.DownLoadHandle = retcode;
	    }
		
		$scope.stopdownload=function(e){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
		    var retcode = sdk_viewer.execFunction("NETDEV_StopDownload",$$video.DownLoadHandle);
			if(0 != retcode)
			{
				$messager.error("提示","下载保存失败");
				return;
			}
			$messager.warning("提示","下载成功! 文件路径 " + VideoParam.VIDEOPATH);
	    }
		
		$scope.GetProgress=function(e){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
			var dataMap = {
						  pulTime:0,
						  pulSpeed:0
	                      }
			var jsonStr = JSON.stringify(dataMap);
		    var SDKRet = sdk_viewer.execFunction("NETDEV_PlayBackControl",parseInt(ResourceId),PlayControl.NETDEV_PLAY_CTRL_GETPLAYTIME ,jsonStr);
			if(-1 != SDKRet)
			{
				var result = JSON.parse(SDKRet);
			    var PlayTime = result.PlayTime;
			}
			else{
				$messager.error("提示","找不到文件");
			}
	    }
		
		$scope.SetProgress=function(e){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
			var dataMap = {
						  pulTime:0,
						  pulSpeed:20
	                      }
			var jsonStr = JSON.stringify(dataMap);
		    var SDKRet = sdk_viewer.execFunction("NETDEV_PlayBackControl",parseInt(ResourceId),PlayControl.NETDEV_PLAY_CTRL_SETPLAYTIME ,jsonStr);
			if(-1 == SDKRet)
			{
				$messager.error("提示","设置播放速度失败");
			}
	    }
		
		$scope.Resume=function(e){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
			var dataMap = {
						  pulTime:0,
						  pulSpeed:0
	                      }
			var jsonStr = JSON.stringify(dataMap);
		    var SDKRet = sdk_viewer.execFunction("NETDEV_PlayBackControl",parseInt(ResourceId),PlayControl.NETDEV_PLAY_CTRL_RESUME ,jsonStr);
			if(-1 == SDKRet)
			{
				$messager.error("提示","重播失败");
			}
		}
		
		$scope.Pause=function(e){
		    var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var $$video = $scope.videoGroup[ResourceId];
			if(!$$video)return;
			var dataMap = {
						  pulTime:0,
						  pulSpeed:0
	                      }
			var jsonStr = JSON.stringify(dataMap);
		    var retcode = sdk_viewer.execFunction("NETDEV_PlayBackControl",parseInt(ResourceId),PlayControl.NETDEV_PLAY_CTRL_PAUSE ,jsonStr);
			if(-1 == retcode)
			{
				$messager.error("提示","暂停失败");
			}
	    }
		
	})
})(jQuery, app)