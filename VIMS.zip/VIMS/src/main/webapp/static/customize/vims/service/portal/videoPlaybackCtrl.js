;
(function($, app) {
	"use strict";
	
	app.controller("VideoPlaybackCtrl", function($scope, $http,$messager) {
		var videoObj;
		
		$http({
        	method: 'POST',
        	url: basePath + '/device/query'
		})
		.success(function(data) {
			$scope.tree=toList(data.obj.list);
		});
		
		function toList(list){
			var temp=[];
			angular.forEach(list,function(v,i){
				listForEach(v,temp);
			})
			return temp;
		}
		
		function listForEach(v,temp){
			if(v.children)
			{
				angular.forEach(v.children,function(m,d){
					temp.push(m);
					listForEach(m,temp);
				})
			}	
		}
		
		$scope.liveVideoScan=function($item,$event){
			$scope.node=$item.children ? null : $item;
		}
		
		$scope.rate=0;//语速默认为1
		$scope.videoBtn=function(type){
			if(!videoObj)return;
			switch(type){
			case 0:
				videoObj.videoPause();
				break;
			case 1:
				videoObj.videoPlay();
				break;
			case 2:
				$scope.rate--;
				$scope.rate = $scope.rate<0? 0 : $scope.rate;
				videoObj.setPlayBackRate($scope.rate);
				break;
			case 3:
				videoObj.videoForward(-10);
				break;
			case 4:
				videoObj.videoForward(10);
				break;
			case 5:
				$scope.rate++;
				$scope.rate=$scope.rate >3 ? 3 : $scope.rate
				videoObj.setPlayBackRate($scope.rate);
				break;
			}
		}
		
		$scope.queryVideo=function(){
			if(!$scope.videoDate)
			{
				$messager.warning("提示","请选择日期！");
				return;
			}	
			if(!$scope.node)
			{
				$messager.warning("提示","请选择设备！");
				return;
			}
			if(!$scope.equip_status)
			{
				$messager.warning("提示","请选择类型！");
				return;
			}	
			// 查询视频码流呈现html
		}
		
		new TimeLines({ele:".video_timeline"});// 初始化24小时刻度线
		$scope.splitScreen=function($event){
			if($($event.target).closest(".selected").length)return;
			$(".video_position").removeAttr("style");
			var videoContainer=angular.element("#videoScreen");
			videoContainer.empty();
			var screenNum = 1;
			for(var i=0;i<screenNum;i++)
			{
			  var video = document.createElement("div");
			  video.id="video"+i;
			  video.className="fl video-border";
			  videoContainer.append(video);
			  videoObj = new Dvideo ({
					ele: video,
					title: '路口0' + (Number($scope.param.selected) + 1),
					src: 'http://oxyi0vk1f.bkt.clouddn.com/evn4.mp4',
					width:100 / Math.sqrt(screenNum) + "%",
					height:100 / Math.sqrt(screenNum) + "%",
					autoplay: true,
					showNext:false,
					showVideoDefinition:false,
					onTimeupdate:function(v){
						var currentP = Number((v.currentT / v.durationT) * 100);
						currentP = currentP > 100 ? 100 : currentP;
						var type = TimeLines.prototype.formartTimeType(v.durationT);
						$($event.target).closest(".selected").find(".video_position").css({left:'calc('+currentP + '% - 10px)'}).find("a").attr("title",TimeLines.prototype.formartTime(v.currentT,type));
					},
					onLoadedMetaData:function(v){
						var timeLines = new TimeLines({ele:".video_timeline",seconds:v.durationT});// 初始化24小时刻度线
						var iX, iY,btn,dragging,_element = timeLines,btn,_currentT;
						var progressRate = $($event.target).closest(".selected");
						progressRate.siblings(".progress_rate").andSelf().find(".video_position").off("mousedown");
						progressRate.find(".video_position").on("mousedown",function(event){
							v.videoPause();
							dragging = true;
							btn = $(this);
							var e = event || window.event
							e.stopPropagation();
			                iX = e.clientX - this.offsetLeft;
			                progressRate.on("mousemove",function (event) {
								var e = event || window.event;
								if(dragging && btn){
									var oX = e.clientX - iX;
									if(oX+10<=0){ oX=-10; }
									else if(oX+10>=($(_element.opt.ele).width()-40)){ oX=$(_element.opt.ele).width()-40-10; }
									btn.css({"left":oX + "px"});
									_currentT = (oX+10)*_element.opt.pxSecondsUnit;
									btn.children("a").attr('title',TimeLines.prototype.formartTime((oX+10)*_element.opt.pxSecondsUnit,TimeLines.prototype.formartTimeType(_element.opt.seconds)));//算时间就要加上-10px
									return false;
								}
							});
							progressRate.on("mouseup mouseleave",function(event){ var e = event || window.event; e.stopPropagation();if(btn){ dragging=false; startVideoContinue(_currentT,v);btn=null;}return false; })
						})
					}
				});
			}	
		}
		
		function startVideoContinue(_currentT,_video){
			var _diff = _currentT - _video.currentT;
    		_video.videoForward(_diff);
    		_video.videoPlay();
		}
	})
})(jQuery, app)