;(function($, app) {
	"use strict";
	
	app.controller("LiveVideoCtrl", function($scope, $http,$messager,$sdkViewer) {
		$scope.param={};
		$scope.param.selected=4;//默认分4屏显示
		
		$http({
        	method: 'POST',
        	url: basePath + '/device/query'
		})
		.success(function(data) {
			$scope.tree=toList(data.obj.list);
		});
		
		function toList(list){
			var temp=[];
			angular.forEach(list,function(v,i){
				listForEach(v,temp);
			})
			return temp;
		}
		
		function listForEach(v,temp){
			if(v.children)
			{
				angular.forEach(v.children,function(m,d){
					temp.push(m);
					listForEach(m,temp);
				})
			}	
		}
		
		var MediaFileFormat = {
				MEDIA_FILE_MP4:            0,           // mp4格式的媒体文件
				MEDIA_FILE_TS:             1            // TS格式的媒体文件  TS media file */
			 }
			 
		 var PictureFormat = {
			PICTURE_BMP:               0,                  // 图片格式为bmp格式
			PICTURE_JPG:               1                   // 图片格式为jpg格式
		 }
		
		 var LiveStream = {
			LIVE_STREAM_INDEX_MAIN:    0,   // 主流
			LIVE_STREAM_INDEX_AUX:     1,   // 辅流
			LIVE_STREAM_INDEX_THIRD:   2    // 第三流
		 }
		 
		 var Protocal = {
			TRANSPROTOCAL_RTPTCP:      1,         //TCP
			TRANSPROTOCAL_RTPUDP:      2          // UDP
		 }
		 
		var VideoParam={
				PICTRUEPATH:"C:\\NETDEV\\Pic\\",
				VIDEOPATH:"C:\\NETDEV\\Record\\"
		}
		
		var $sdk=$sdkViewer.initSdkViewer("playerContainer");
		var sdk_viewer = $sdk.sdk;
		$scope.node={};
		$scope.liveVideoScan=function($item,$event){
			if($item.children)return;
			// 初始化控件
			$scope.node=$item;
			var channelID=$item.channelID || 1;
			// 初始化设置云端登陆
			// 设备登陆
	        if(Cloudlogin($item.url,$item.userName,$item.password) && Devlogin($item.devName,$item.devPassword)) { startVideo($item,channelID); }	
		}
		
		$scope.splitScreen=function(splitNum){
			var retcode = sdk_viewer.execFunction("NetSDKSetPlayWndNum" , splitNum);         //分屏 
	        if(0!=retcode){
	        	$messager.error("提示","实况窗口实例化失败");
	        }
		}
		$scope.splitScreen($scope.param.selected);
	    
        // 云登陆
        function Cloudlogin(cameraIp,userName,password)
    	{
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloud", cameraIp,userName, password);
    		if(-1 == SDKRet)
    		{
    			$messager.error("提示","云登录失败");
    			return false;
    		}
            else{
            	$sdk.CloudHandle = SDKRet;
            	return true;
    		}
    	}
        
        // 设备登陆
        function Devlogin(cloudDevName,password)
    	{
    		var dataMap = { szDeviceName:cloudDevName, szDevicePassword:password, dwT2UTimeout:0 }
            var jsonStr = JSON.stringify(dataMap);
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloudDev", $sdk.CloudHandle, jsonStr);
    		if(-1 == SDKRet)
    		{
    			$messager.error("提示","设备登录失败");
    			return false;
    		}
            else{
    		    var result = JSON.parse(SDKRet);
    		    $sdk.DeviceHandle = result.UserID;	
    	        return true;
    		}
    	}
		// 启流
	    function startVideo($item,channelID) {
		    var dataMap = {
	                      dwChannelID:channelID, 
	                      dwStreamType:LiveStream.LIVE_STREAM_INDEX_MAIN,
						  dwLinkMode:Protocal.TRANSPROTOCAL_RTPTCP,
						  dwFluency:0
	                      }

	        var jsonStr = JSON.stringify(dataMap);
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			
			var retcode = sdk_viewer.execFunction("NETDEV_RealPlay", parseInt(ResourceId), $sdk.DeviceHandle, jsonStr);
			
	        if (0 != retcode) {
	        	$messager.error("提示","播放实况失败。");
	        }
	        else
	        {
	        	$(".ul-horizontal li.init").removeClass("disabled");
	        	//	 logout();
	        }	
	    }
	    
	    function logout(){
	    	sdk_viewer.execFunction("NETDEV_Logout", $sdk.DeviceHandle);
	    	sdk_viewer.execFunction("NETDEV_Cleanup");
	    	$sdk.DeviceHandle = -1;
	    }
	    
	    // 停流
	    $scope.stopVideo=function(e) {
	    	if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
	        var retcode = sdk_viewer.execFunction("NETDEV_StopRealPlay", parseInt(ResourceId));  //关闭视频流  
	        if (0 != retcode) {
	        	$messager.error("提示","停流失败。");
	        } 
	        else
	        {
	        	logout();
	        }	
	    }
	    
	    // 截屏
		$scope.snatchPic=function(e) {
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var retcode = sdk_viewer.execFunction("NETDEV_CapturePicture", parseInt(ResourceId), VideoParam.PICTRUEPATH + $scope.node.devName + "_" + new Date().getTime(), PictureFormat.PICTURE_JPG);
			if (0 != retcode) {
				$messager.error("提示","截屏失败");
			} 
			else
			{
				$messager.success("提示","截屏图片保存路径: " + VideoParam.PICTRUEPATH);
			}	
		}
		
		//开始本地录像
		$scope.startRecord=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_SaveRealData",parseInt(ResourceId),VideoParam.VIDEOPATH + $scope.node.devName + "_" + new Date().getTime(),MediaFileFormat.MEDIA_FILE_MP4);
		    if(0!=retcode){
		    	$messager.error("提示","执行开始录像失败");
		    }
		    else
		    {
		    	$(e.target).addClass("disabled").next("li").removeClass("disabled");
		    }	
		}
		
		//停止本地录像
		$scope.stopRecord=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_StopSavaRealData", parseInt(ResourceId));
		    if(0!=retcode){
		    	$messager.error("提示","执行停止录像失败");
		    }
		    else
		    {
		    	$(e.target).addClass("disabled").prev("li").removeClass("disabled");
		    	$messager.success("提示","录像文件保存路径: " + VideoParam.VIDEOPATH);
		    }	
		}
		
		//播放音频
		$scope.opensound=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_OpenSound",parseInt(ResourceId));//打开声音 
		    if(0!=retcode){
		    	$messager.error("提示","播放音频失败");
		    }
		    else
		    {
		    	$(e.target).addClass("disabled").next("li").removeClass("disabled");
		    }	
		}
		
		//停止播放音频
		$scope.closesound=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_CloseSound",parseInt(ResourceId));   //停止声音 
		    if(0!=retcode){
		    	$messager.error("提示","停止音频失败");
		    } 
		    else
		    {
		    	$(e.target).addClass("disabled").prev("li").removeClass("disabled");
		    }	
		}
	    
	})
})(jQuery, app)