;(function($, app) {
	"use strict";
	
	app.controller("LiveVideoCtrl", function($scope, $http,$messager,$sdkViewer) {
		$scope.param={};
		$scope.param.selected=4;//默认分4屏显示
		
		$http({
        	method: 'POST',
        	url: basePath + '/device/query'
		})
		.success(function(data) {
			$scope.tree=toList(data.obj.list);
		});
		
		function toList(list){
			var temp=[];
			angular.forEach(list,function(v,i){
				listForEach(v,temp);
			})
			return temp;
		}
		
		function listForEach(v,temp){
			if(v.children)
			{
				angular.forEach(v.children,function(m,d){
					temp.push(m);
					listForEach(m,temp);
				})
			}	
		}
		
		var MediaFileFormat = {
				MEDIA_FILE_MP4:            0,           // mp4格式的媒体文件
				MEDIA_FILE_TS:             1            // TS格式的媒体文件  TS media file */
			 }
			 
		 var PictureFormat = {
			PICTURE_BMP:               0,                  // 图片格式为bmp格式
			PICTURE_JPG:               1                   // 图片格式为jpg格式
		 }
		
		 var LiveStream = {
			LIVE_STREAM_INDEX_MAIN:    0,   // 主流
			LIVE_STREAM_INDEX_AUX:     1,   // 辅流
			LIVE_STREAM_INDEX_THIRD:   2    // 第三流
		 }
		 
		 var Protocal = {
			TRANSPROTOCAL_RTPTCP:      1,         //TCP
			TRANSPROTOCAL_RTPUDP:      2          // UDP
		 }
		 
		var VideoParam={
				PICTRUEPATH:"C:\\NETDEV\\Pic\\",
				VIDEOPATH:"C:\\NETDEV\\Record\\"
		}
		
		var $sdk=$sdkViewer.initSdkViewer("playerContainer");
		var sdk_viewer = $sdk.sdk;
		$scope.node={};
		var videoGroup={};//已播放的视频区集；
		$scope.liveVideoScan=function($item,$event){
			if($item.children)return;
			// 初始化控件
			$scope.node=$item;
			var channelID=$item.channelID || 1;
			// 初始化设置云端登陆
			// 设备登陆
			if($item.$checked)
			{
				stopVideo($item);
			}	
			else
			{
				var _ResourceId = getResourceIdByVideoGroup($item);
				if(undefined==_ResourceId){
					$messager.error("提示","播放实况数大于分屏数，请先关闭部分视频。");
					return;
				}
				if(Cloudlogin($item,$item.url,$item.userName,$item.password) && Devlogin($item,$item.devName,$item.devPassword)) { startVideo($item,channelID,_ResourceId); }
				else{$item.$checked=false;}
			}	
		}
		
		$scope.splitScreen=function(splitNum){
			var retcode = sdk_viewer.execFunction("NetSDKSetPlayWndNum" , splitNum);         //分屏 
	        if(0!=retcode){
	        	$messager.error("提示","实况窗口实例化失败");
	        }
		}
		$scope.splitScreen($scope.param.selected);
	    
        // 云登陆
        function Cloudlogin($item,cameraIp,userName,password)
    	{
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloud", cameraIp,userName, password);
    		if(-1 == SDKRet)
    		{
    			$messager.error("提示","云登录失败");
    			return false;
    		}
            else{
            	$item.CloudHandle = SDKRet;
            	return true;
    		}
    	}
        
        // 设备登陆
        function Devlogin($item,cloudDevName,password)
    	{
    		var dataMap = { szDeviceName:cloudDevName, szDevicePassword:password, dwT2UTimeout:0 }
            var jsonStr = JSON.stringify(dataMap);
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloudDev", $item.CloudHandle, jsonStr);
    		if(-1 == SDKRet)
    		{
    			$messager.error("提示","设备登录失败");
    			return false;
    		}
            else{
    		    var result = JSON.parse(SDKRet);
    		    $item.DeviceHandle = result.UserID;	
    	        return true;
    		}
    	}
        
        // 查找分屏object中有空余的未播放屏
        function getResourceIdByVideoGroup($item){
        	var wnd = sdk_viewer.execFunction("NetSDKGetPlayWndNum");
        	for(var index=0;index < wnd;index++)
        	{
        		// 如果有未播放的屏，设置当前屏下标给$item作为标记
        		if(!videoGroup[index])
        		{
        			$item.videoReSourceId=index;
        			$item.$checked=true;
        			break;
        		}	
        	}	
        	return $item.videoReSourceId;
        }
        
		// 启流
	    function startVideo($item,channelID,ResourceId) {
		    var dataMap = {
	                      dwChannelID:channelID, 
	                      dwStreamType:LiveStream.LIVE_STREAM_INDEX_MAIN,
						  dwLinkMode:Protocal.TRANSPROTOCAL_RTPTCP,
						  dwFluency:0
	                      }

	        var jsonStr = JSON.stringify(dataMap);
			var retcode = sdk_viewer.execFunction("NETDEV_RealPlay", parseInt(ResourceId), $item.DeviceHandle, jsonStr);
	        if (0 != retcode) {
	        	$messager.error("提示","播放实况失败。");
	        	$item.$checked=false;
	        }
	        else
	        {
	        	$(".ul-horizontal li.init").removeClass("disabled");
	        	videoGroup[ResourceId]=$item;
	        }	
	    }
	    
	    // 停流
	    function stopVideo($item) {
			var ResourceId = $item.videoReSourceId;
	        var retcode = sdk_viewer.execFunction("NETDEV_StopRealPlay", parseInt(ResourceId));  //关闭视频流  
	        if (0 != retcode) {
	        	$messager.error("提示","停流失败。");
	        	return;
	        } 
	        $item.$checked=false;
	        videoGroup[ResourceId]=null;
	    }
	    
	    // 截屏
		$scope.snatchPic=function(e) {
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var retcode = sdk_viewer.execFunction("NETDEV_CapturePicture", parseInt(ResourceId), VideoParam.PICTRUEPATH + $scope.node.devName + "_" + new Date().getTime(), PictureFormat.PICTURE_JPG);
			if (0 != retcode) {
				$messager.error("提示","截屏失败");
			} 
			else
			{
				$messager.success("提示","截屏图片保存路径: " + VideoParam.PICTRUEPATH);
			}	
		}
		
		//开始本地录像
		$scope.startRecord=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_SaveRealData",parseInt(ResourceId),VideoParam.VIDEOPATH + $scope.node.devName + "_" + new Date().getTime(),MediaFileFormat.MEDIA_FILE_MP4);
		    if(0!=retcode){
		    	$messager.error("提示","执行开始录像失败");
		    }
		    else
		    {
		    	$(e.target).addClass("disabled").next("li").removeClass("disabled");
		    }	
		}
		
		//停止本地录像
		$scope.stopRecord=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_StopSavaRealData", parseInt(ResourceId));
		    if(0!=retcode){
		    	$messager.error("提示","执行停止录像失败");
		    }
		    else
		    {
		    	$(e.target).addClass("disabled").prev("li").removeClass("disabled");
		    	$messager.success("提示","录像文件保存路径: " + VideoParam.VIDEOPATH);
		    }	
		}
		
		//播放音频
		$scope.opensound=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_OpenSound",parseInt(ResourceId));//打开声音 
		    if(0!=retcode){
		    	$messager.error("提示","播放音频失败");
		    }
		    else
		    {
		    	$(e.target).addClass("disabled").next("li").removeClass("disabled");
		    }	
		}
		
		//停止播放音频
		$scope.closesound=function(e){
			if($(e.target).hasClass("disabled"))return;
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_CloseSound",parseInt(ResourceId));   //停止声音 
		    if(0!=retcode){
		    	$messager.error("提示","停止音频失败");
		    } 
		    else
		    {
		    	$(e.target).addClass("disabled").prev("li").removeClass("disabled");
		    }	
		}
	    
	})
})(jQuery, app)