;var sdk_viewer; // 控件（插件）对象
(function($, app) {
	"use strict";
	var DeviceHandle = -1;
	var CloudHandle = -1;
	app.controller("LiveVideoCtrl", function($scope, $http) {
		sdk_viewer=null;
		$scope.param={};
		$scope.param.selected=4;//默认分4屏显示
		
		$http({
        	method: 'POST',
        	url: basePath + '/device/query'
		})
		.success(function(data) {
			$scope.tree=toList(data.obj.list);
		});
		
		function toList(list){
			var temp=[];
			angular.forEach(list,function(v,i){
				listForEach(v,temp);
			})
			return temp;
		}
		
		function listForEach(v,temp){
			if(v.children)
			{
				angular.forEach(v.children,function(m,d){
					temp.push(m);
					listForEach(m,temp);
				})
			}	
		}
		
		// js 初始化视频码流变量及方法
		var Main = {
		    EventMap : ""
		}
		Main.EventMap = (function(){
	    var closure = {
	        formatExceotionCode: function(u32ExceptionCode){
	            u32ExceptionCode = u32ExceptionCode.split(',');
	            return parseInt(u32ExceptionCode, 10);
	        },
	        formatTaskNo: function(u32Task_No){
	            u32Task_No = u32Task_No.split(',');
	            return parseInt(u32Task_No, 10);
	        }
	    };
	    return {
			/* 告警事件上报 */
			__200:function(strAlarmInfo){
				//alert(strAlarmInfo);
			}
	      };
	    })();
		
		var cfg = {
	          id: "player",                    //加载的activex控件id
	          container: "playerContainer",    //控件/插件的父节点
	          name: "sdk_viewer",              //实例对象的名称，用于设置napi上报事件的入参
	          events: Main.EventMap,           //控件事件map
	          stPortInfo: {
	              szDeviceIp: "",
	              szLocalIp: "",
	          },                                  //端口信息     
	          stUserInfo: {                        //用户登录信息
	              User: "",
	              Password: ""
	          },
	          maxWnd: 64,                       //控件动态创建窗格的个数，不小于最大通道路数,默认64路 (可选) 
	          focusColor: 'ffcc00',             //窗格获得焦点时的边框颜色，注意：参数形如'xxxxxx'，为颜色的16进制，以b g r 顺序，而不是r g b (可选) 
	          unfocusColor: '747d7d',           //窗格未获得焦点时的边框颜色，注意：参数形如'xxxxxx'，为颜色的16进制，以b g r 顺序，而不是r g b (可选) 
	          backgColor: '373737',             //控件背景色，注意：参数形如'xxxxxx'，为颜色的16进制，以b g r 顺序，而不是r g b (可选)
	         // noCreateWnd: 'true'           
	    }
		 
		var MediaFileFormat = {
				MEDIA_FILE_MP4:            0,           // mp4格式的媒体文件
				MEDIA_FILE_TS:             1            // TS格式的媒体文件  TS media file */
			 }
			 
		 var PictureFormat = {
			PICTURE_BMP:               0,                  // 图片格式为bmp格式
			PICTURE_JPG:               1                   // 图片格式为jpg格式
		 }
		
		 var LiveStream = {
			LIVE_STREAM_INDEX_MAIN:    0,   // 主流
			LIVE_STREAM_INDEX_AUX:     1,   // 辅流
			LIVE_STREAM_INDEX_THIRD:   2    // 第三流
		 }
		 
		 var Protocal = {
			TRANSPROTOCAL_RTPTCP:      1,         //TCP
			TRANSPROTOCAL_RTPUDP:      2          // UDP
		 }
		 
		var VideoParam={
				PICTRUEPATH:"C:\\NETDEV\\Pic\\netDev",
				VIDEOPATH:"C:\\NETDEV\\Record\\netDev"
		}
		
		sdk_viewer = new Utils.Player(cfg);                                       //初始化控件 
		
		
		$scope.liveVideoScan=function($item,$event){
			if($item.children)return;
			// 初始化控件
			var channelID=$item.channelID || 1;
			// 初始化设置云端登陆
			// 设备登陆
	        if(Cloudlogin($item.url,$item.userName,$item.password) && Devlogin($item.devName,$item.devPassword)) { startVideo(channelID); }	
		}
		
		$scope.splitScreen=function(splitNum){
			var retcode = sdk_viewer.execFunction("NetSDKSetPlayWndNum" , splitNum);         //分屏 
	        if(0!=retcode){
	        	console.log("实况窗口实例化失败");
	        }
		}
		$scope.splitScreen($scope.param.selected);
	    
        // 云登陆
        function Cloudlogin(cameraIp,userName,password)
    	{
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloud", cameraIp,userName, password);
    		if(-1 == SDKRet)
    		{
    			console.log("云登录失败");
    			return false;
    		}
            else{
            	CloudHandle = SDKRet;
            	return true;
    		}
    	}
		
        // 设备登陆
        function Devlogin(cloudDevName,password)
    	{
    		var dataMap = { szDeviceName:cloudDevName, szDevicePassword:password, dwT2UTimeout:0 }
            var jsonStr = JSON.stringify(dataMap);
    		var SDKRet = sdk_viewer.execFunction("NETDEV_LoginCloudDev", CloudHandle, jsonStr);
    		if(-1 == SDKRet)
    		{
    			console.log("设备登录失败");
    			return false;
    		}
            else{
    		    var result = JSON.parse(SDKRet);
    		    DeviceHandle = result.UserID;	
    	        return true;
    		}
    	}
        
		// 启流
	    function startVideo(channelID) {
		    var dataMap = {
	                      dwChannelID:channelID, 
	                      dwStreamType:LiveStream.LIVE_STREAM_INDEX_MAIN,
						  dwLinkMode:Protocal.TRANSPROTOCAL_RTPTCP,
						  dwFluency:0
	                      }

	        var jsonStr = JSON.stringify(dataMap);
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			
			var retcode = sdk_viewer.execFunction("NETDEV_RealPlay", parseInt(ResourceId), DeviceHandle, jsonStr);
	        if (0 != retcode) {
	        	console.log("播放实况失败。");
	        } 
	    }
	    
	    // 停流
	    $scope.stopVideo=function() {
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
	        var retcode = sdk_viewer.execFunction("NETDEV_StopRealPlay", parseInt(ResourceId));  //关闭视频流  
	        if (0 != retcode) {
	        	console.log("停流失败。");
	        } 
	    }
	    
	    // 截屏
		$scope.snatchPic=function() {
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
			var retcode = sdk_viewer.execFunction("NETDEV_CapturePicture", parseInt(ResourceId), VideoParam.PICTRUEPATH, PictureFormat.PICTURE_JPG);
			if (0 != retcode) {
				console.log("截屏失败");
			} 
		}
		
		//开始本地录像
		$scope.startRecord=function(){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_SaveRealData",parseInt(ResourceId),VideoParam.VIDEOPATH,MediaFileFormat.MEDIA_FILE_MP4);
		    if(0!=retcode){
		    	console.log("执行开始录像失败");
		    }
		}
		
		//停止本地录像
		$scope.stopRecord=function(){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_StopSavaRealData", parseInt(ResourceId));
		    if(0!=retcode){
		    	console.log("执行停止录像失败");
		    }
		}
		
		//播放音频
		$scope.opensound=function(){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_OpenSound",parseInt(ResourceId));//打开声音 
		    if(0!=retcode){
		    	console.log("播放音频失败");
		    }
		}
		
		//停止播放音频
		$scope.closesound=function(){
			var ResourceId = sdk_viewer.execFunction("NetSDKGetFocusWnd");
		    var retcode = sdk_viewer.execFunction("NETDEV_CloseSound",parseInt(ResourceId));   //停止声音 
		    if(0!=retcode){
		    	console.log("停止音频失败");
		    }
		}
	    
	})
})(jQuery, app)