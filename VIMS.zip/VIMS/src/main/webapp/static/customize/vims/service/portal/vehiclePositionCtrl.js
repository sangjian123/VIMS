;
(function($, app) {
	"use strict";
	
	app.controller("VehiclePositionCtrl", function($scope, $http,$map,$document,$timeout,$interval) {
		
		// 加载地图
		var map;
		$map.load().then(function(){
			$scope.accountList=[{key:"仅显示在线车辆",value:1},{key:"仅显示离线车辆",value:2}];
			$scope.equip_status=0;
			$scope.queryVehiclePosition=function(){
				$scope.selectOptions=[];
				$http({
	            	method: 'POST',
	            	url: basePath + '/vehicle/queryVehicleWtihDept',
	            	params: {"equip_status":$scope.equip_status || 0,"cardnumbers":$scope.cardnumbers}
				})
				.success(function(data) {
					// 2维数组 转换为2级树行结构
					$scope.deptVehicalList=[];
					angular.forEach(data.obj.list,function(n,i){
						var o = {"name":n[0].deptName,list:n,checked:true};
						$scope.deptVehicalList.push(o);
						angular.forEach(n,function(v,d){v.checked=true;$scope.selectOptions.push(v);})
					})
					query();
				});
			}
			
			//  初始化
			$scope.queryVehiclePosition();
			
			$scope.getSelectOptions1=function(){
				$scope.selectOptions=[];
				angular.forEach($scope.deptVehicalList,function(d,m){
					d.indeterminate=false;
					angular.forEach(d.list,function(v,n){
						v.checked=d.checked;
						if(d.checked)$scope.selectOptions.push(v);
					})
				})
				// 调用接口查询地图数据
				query();
			}
			
			$scope.getSelectOptions2=function(){
				$scope.selectOptions=[];
				angular.forEach($scope.deptVehicalList,function(d,m){
					d.checked=true,d.indeterminate=false;
					var index=0,list = d.list;
					angular.forEach(list,function(v,n){
						// 如果都为true，则勾选父节点，否则撤销父节点勾选
						if(v.checked){$scope.selectOptions.push(v);index++;}else{d.checked=false;}
						d.indeterminate=(list.length!=index && 0!=index);
					})
				})
				// 调用接口查询地图数据
				query();
			}
			
			function query(r){
				$http({
	            	method: 'POST',
	            	url: basePath + '/vehicle/query',
	            	params: {"cardnumbers":getCardnumbers()}
				})
				.success(function(data) {
					var points=[];
					map.clearOverlays();
					angular.forEach(data.obj.list,function(v,i){
						points.push(drawMarker(map,v));
					})
					var viewPort = map.getViewport(points);
					if(!r)map.centerAndZoom(viewPort.center, Math.min(viewPort.zoom,15));
				});
			}
			
			map = new BMap.Map("allmap",{enableMapClick: false});//在百度地图容器中创建一个地图
			map.clearOverlays();
			map.centerAndZoom(new BMap.Point(116.4035,39.915), 10);
			map.enableScrollWheelZoom();
			map.enableContinuousZoom();
			map.addControl(new BMap.NavigationControl());
			map.addControl(new BMap.ScaleControl());
			map.addControl(new BMap.OverviewMapControl());
			map.addControl(new BMap.MapTypeControl({
				mapTypes:[
		            BMAP_NORMAL_MAP,
		            BMAP_HYBRID_MAP
		        ]}));	  
			map.setCurrentCity("北京"); 
			// 每隔30秒执行一次
			var timer = $interval(function(){
			     query(true);
			},10000);
			$scope.$on('$destroy',function(){$interval.cancel(timer);});//在离开controller时，清楚定时任务
		});
		
		function drawMarker(map,v){
			var point = new BMap.Point(v.longitude,v.dimension);
			var angle = $.getAngle(new BMap.Point(v.prelongitude,v.predimension),point); // 获取连接方向
	        var iconImg = new BMap.Icon(basePath + "/static/customize/images/car.png", new BMap.Size(34, 34));  
	        var marker = new BMap.Marker(point, { icon : iconImg });
	        var label = new BMap.Label(v.cardnumber, {offset: new BMap.Size(-15, -30)}); //创建marker点的标记
			marker.setLabel(label);
			marker.setRotation(angle);
	        map.addOverlay(marker);  
	        marker.addEventListener("click", function(){
	        	v.angle=angle;
	        	var gc = new BMap.Geocoder();
	        	gc.getLocation(point, function(rs){
	        		   v.address=rs.address;
	        		   drawInfoWindow(marker,v);
	        		});
			 });
	        return point;
		}
		
		// 以逗号分隔的字符串
		function getCardnumbers()
		{
			var temp=[];
			angular.forEach($scope.selectOptions,function(o,i){
				temp.push(o.cardnumber);
			});
			return temp.join(",");
		}
		
		function drawInfoWindow(marker,v){
			var html = [
			            	'<div id="infowindow">',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td class="tdinfopic"><img class="vims-photo" src="', v.displayicon, '" onerror="javascript:this.src=\''+basePath+ '/static/customize/images/no-image.png\'"></td>',
			            					'<td>',
			            						'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            							'<tbody>',
			            								'<tr>',
			            									'<td class="tdinfotitle" style="white-space:nowrap;"><b>',v.cardnumber,'</b>',//(xxx 138****4564)<br><b>设备编号：</b>无</td>
			            								'</tr>',
			            								'<tr>',
			            									'<td class="tdinfoaddr"><font color="blue">',v.address,'</font></td>',
			            								'</tr>',
			            							'</tbody>',
			            						'</table>',
			            					'</td>',
			            				'</tr>',
			            			'</tbody>',
			            		'</table>',
			            		'<table border="0" cellpadding="0" cellspacing="0" width="100%">',
			            			'<tbody>',
			            				'<tr>',
			            					'<td class="tdinfoleft" style="height:2px;" colspan="4"><hr class="horizontal-line" size="1"></td>',
			            				'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft" width="70px">北纬:</td><td class="tdinforight">',v.dimension,'</td><td class="tdinfoleft" width="40px">东经:</td><td class="tdinforight">',v.longitude,'</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">行驶方向:</td><td class="tdinforight">',$.getAngleDirection(v.angle),'</td><td class="tdinfoleft">速度:</td><td class="tdinforight">',v.speed,' 公里/小时</td>',
			            			'</tr>',
			            			'<tr>',
			            				'<td class="tdinfoleft">点火开关:</td><td class="tdinforight"><font color="red">无</font></td><td class="tdinfoleft">里程:</td><td class="tdinforight">',v.mileage,' 公里</td>',
			            			'</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">电源状态:</td><td class="tdinforight">无</td><td class="tdinfoleft">空调:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">GSM信号:</td><td class="tdinforight">无</td><td class="tdinfoleft">卫星:</td><td class="tdinforight">无</td>',
			            		    '</tr>',
			            		    '<tr>',
			            		    	'<td class="tdinfoleft">最新上报:</td><td class="tdinforight" colspan="3">',v.ctime,'</td>',
			            		    '</tr>',
			            		   '</tbody>',
			            		  '</table>',
			            		 '</div>'
			            ].join("");
			var infoWindow = new BMap.InfoWindow(html); // 创建信息窗口对象
			infoWindow.enableAutoPan();// 允许被遮挡时自动平移,相反方法：disableAutoPan()
			marker.openInfoWindow(infoWindow); // 打开信息窗口 
			$timeout(function(){ $('.BMap_top').html("<label style='margin-top:4px;'>车牌号码: "+ v.cardnumber +"</label>") },50);
		}
	})
})(jQuery, app)