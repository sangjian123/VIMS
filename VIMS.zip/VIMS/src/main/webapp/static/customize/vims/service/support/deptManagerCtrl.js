;
(function($, app) {
	"use strict";
	
	app.controller("DeptManagerCtrl", function($scope, $http,$state,$modal,$messager) {
		$scope.options={};
		$scope.options.url=basePath + "/organization/datagrid";
		$scope.options.colums=[
                   	{ title:'全选', field:'select', checkbox:true, width:25, align:'center', valign:'middle' },
                   	{ title:'id', field:'id', visible:false },
                	{ title:'部门名称', field:'name'},
                	{ title:'部门地址', field:'address' },
                	{ title:'创建日期', field:'createTime', sortable:true },
                	{ title:'备注', field:'description', align:'center' }
            	]
		$scope.operateDept=function(isEdit){
		  debugger
      $scope.organization=null;
      var uri="add";
      if(isEdit)
      {
        var row = $("#deptList").bootstrapTable('getSelections');
        if(row.length==0 || row.length>1)
        {
          $messager.warning("提示","请选择一行，进行修改！");
          return;
        } 
        $scope.organization = row[0];
        uri="edit";
      } 
			$modal.open({
	          	templateUrl:basePath + "/organization/deptInfo",
	          	scope:false,
	          	backdrop:'static',
	          	keyboard:true,
	          	size:"defalut",
	          	resolve : { organization : function() { return $scope.organization; }},
	          	controller:function($scope,$modalInstance,organization){
	          		$scope.close=function(){ $modalInstance.dismiss('cancel'); }
	          		$scope.organization=organization;
	          		$scope.saveDept=function(){ 
	          		  debugger
	          		  $http.post(basePath + "/organization/"+uri, $scope.organization || {}).success(function(result) {
	                  if (result.success) {
	                    $messager.success("提示", "操作成功");
	                    $modalInstance.dismiss('cancel'); 
	                    $("#deptList").bootstrapTable('refresh');
	                  }else{
	                    $messager.error("提示", result.msg);
	                  }
	                });
	          		  
	          		}
	          	}
	          });
		}
		$scope.deleteDept=function(){ 
		  var row = $("#deptList").bootstrapTable('getSelections');
      if(row.length==0 || row.length>1)
      {
        $messager.warning("提示","请选择一行！");
        return;
      } 
      $scope.organization = row[0];
      $http.post(basePath + "/organization/delete", $scope.organization || {}).success(function(result) {
        if (result.success) {
          $messager.success("提示", "操作成功");
          $("#deptList").bootstrapTable('refresh');
        }else{
          $messager.error("提示", result.msg);
        }
      });
      
    }
		
	})
})(jQuery, app)