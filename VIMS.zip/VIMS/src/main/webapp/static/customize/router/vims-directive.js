(function($){
	"use strict";
	
	var app = angular.module("main.webapp", ['vims.webapp']);
	
	app.config(["$httpProvider", function ($httpProvider) {   
        $httpProvider.interceptors.push('vimsInterceptor');  
    }]);
	
	app.factory('vimsInterceptor', function ($rootScope,$q,$injector) {return { 
		request: function (config) { 
			return config;
		}, 
		response: function (response) {
			return response; 
			}};
		});  
	
	app
	.run(function($templateCache) {
		var treeHtm = [
		                '<script id="treeRecursion" type="text/ng-template">',
		                '<span ng-dblclick="warpDblclickCallback(\'itemDblclick\',item,$event)" ng-class="{\'true\':\'selected\'}[item.$checked]"  ng-click="warpCallback(\'itemClick\', item, $event)" context-menu="item" class="item-tree {{item.disabled ? \'item-disabled\':\'\'}}" id="drag-tree-{{item[valueField]}}" ng-drag="drag(item)">',
		                '<i class="	glyphicon glyphicon-facetime-video" ng-if="isLeaf(item)"></i>',
		                '<i ng-click="expendItem(item,$event)" ng-if="!isLeaf(item)" ng-class="{\'true\':\'glyphicon glyphicon-plus\',\'false\':\'glyphicon glyphicon-minus\'}[!item.$$isExpend]"></i>',
		                '<input type="checkbox" class="checkbox" ng-if="itemCheckbox" ng-checked="item.checked"></input>',
		                '<span class="checkicon glyphicon glyphicon-ok {{item.$$state}} " ng-if="itemCheckbox" ng-click="checkItem(item,$event);sure(item,\'itemChecked\')"></span>',
		                '<i ng-if="item.editable &&  itemEdit && !item.$$showEdit" class="glyphicon glyphicon-pencil item-edit" ng-click="edit(item,$event)" ng-init="item.$$showEdit=false"></i>',
		                '<i ng-if="item.editable && itemEdit && item.$$showEdit" class="glyphicon glyphicon-ok item-save" ng-click="edit(item,$event,\'itemSave\')"></i>',
		                '<dd ng-if="!item.$$showEdit" ng-bind="item[textField]"></dd>',
		                '<input focus type="text" class="form-control" ng-if="item.$$showEdit" ng-model="item[textField]">',
		                '</span><a href=""></a>',
		                '<ul ng-if="!isLeaf(item)" ng-show="item.$$isExpend">',
		                '<li ng-repeat="item in item.children track by $index" ng-class="{\'true\':\'parent_li\',\'false\':\'child_li\'}[!isLeaf(item)]" ng-include="\'treeRecursion\'">',
		                '</li>',
		                '</ul>',
		                '</script>'].join("");
		 var simpleSelectHtm = [
								'<div class="select-input">',
								'<span class="glyphicon glyphicon-chevron-down" ng-click="chevronSelect($event,show=!show)"></span>',
								'<input type="text" class="form-control" ng-model="selectText" placeholder="{{vNotext ? vNotext : \'请选择\'}}" readonly="readonly" ng-click="$event.stopPropagation();show=!show;" ng-blur="show=false">',
								'<div  ng-if="show">',
									'<ul>',
										'<li  ng-mousedown="selectOne($event)" ng-if="!vNoselect">{{vNotext ? vNotext : \'请选择\'}}</li>',
										'<li  ng-repeat="item in vList track by $index" ng-mousedown="selectOne($event,item)">{{item[vKey]}}</li>',
									'</ul>',
								'</div>',
								'</div>'
		                     ].join("");
		 
	        $templateCache.put('simpleSelect.htm',simpleSelectHtm);
	        $templateCache.put('tree.htm',treeHtm);
	})
	.directive('vimsLoading', function($compile) {
        return {
        	restrict: 'E',
            scope:true,
            template: '<div class="vims-loading"><div></div></div>',
            replace: true,
            link:function($scope,$element,$attr)
            {
            	$scope.$watch("loading",function(n,o){
            		if(n){$($element).fadeIn('fast');}else{$($element).fadeOut('fast');}
            	})
            }
        };
    })
	.directive('vimsTable', function($timeout,$compile) {
        return {
        	restrict: 'E',
            scope:{
            	vimsUrl:'=vimsUrl',
            	vimsColumns:'=vimsColumns',
            	vimsOptions:'@vimsOptions',
            },
            template: '<table class="table table-hover"></table>',
            replace: true,
            link:function(scope,element,attr)
            {
            	var options = {
                    	url:scope.vimsUrl,
                    	striped: true, //是否显示行间隔色
                    	cache:false,
                    	pagination:true,//是否分页
                    	sidePagination:'server',
                    	showRefresh:true,//刷新按钮
                    	showColumns:true,
                    	pageNumber: 1, //初始化加载第一页  
                    	pageSize:10,//单页记录数  
                        pageList:[10, 15, 20, 50],//可选择单页记录数
                    	clickToSelect: false,//是否启用点击选中行
                    	columns:scope.vimsColumns
                    };
            	var option = scope.vimsOptions ? (new Function('return ' + '{' + scope.vimsOptions + '}'))() : {};
            	$.extend(options,option);
            	$(element).bootstrapTable(options);
            }
        };
    })
    .directive('vimsDatetime', function($templateCache,$parse) {
   	 return {
  		     restrict: 'E',
  			 replace: true,
  			 transclude: true,
  		     template: '<div class="input-append date form_datetime">'
  		    				+ '<input size="16" class="form-control" type="text" value="" readonly placeholder="{{vPlaceholder}}">'
  		    				+ '<span class="add-on" ng-click="datetimepicker(show=!show)"><i class="icon-calendar"></i></span>'
  		    				+ '</div>',
  		     scope: {
  				vFormat:'@',
  				vPlaceholder:'@',
  				vModel:'=',
  				vTimepicker:'=',
  				vOnshow:'&',
  				vContainer:'@'
  			},
  		    controller:function($scope,$element,$attrs,$filter){
  			var format;
  			if("yyyy-MM-dd"===$scope.vFormat) { format = 'Y-m-d'; }
  			else if("yyyy-MM-dd hh:mm"===$scope.vFormat) { format='Y-m-d H:i'; }	
  			
  			$($element).find("input").datetimepicker({
  				container:$("#" + $scope.vContainer).length ? $("#" + $scope.vContainer)[0] : $element,
  				format:format,
  				step:30,
  				value:$scope.vModel,
  				timepicker:$scope.vTimepicker || false,
  				onChangeDateTime:function(ct){
  					if(!ct)return;
  					var model = $parse($attrs.vModel);
  					model.assign($scope.$parent,ct.format($scope.vFormat));
  					$($element).find("input").val(ct.format($scope.vFormat));
  				},
  				onShow:function(){
  					$("body").addClass("datetime-picker-open");
  				},
  				onClose:function(){
  					$("body").removeClass("datetime-picker-open");
  				}
  			});
  			
  			$scope.datetimepicker=function(show){
  				$($element).find("input").trigger(show ? "mousedown" : "mouseup").focus();
  			}
  		}
 	 }
   })
    .directive('vimsSelect', function($templateCache,$parse) {
   	 return {
  		     restrict: 'E',
  			 replace: true,
  			 transclude: true,
  		     template: $templateCache.get("simpleSelect.htm"),
  		     scope: {
  				vKey:'@',
  				vValue:'@',
  				vModel:'=',
  				vFire:'&',
  				vList:'=',
  				vNoselect:'@',
  				vNotext:'@'
  			},
  		    controller:function($scope,$element,$attrs,$filter){
  			$scope.$watchGroup(["vList","vModel"],function(n,o){
  				$scope.selectText=null; 
  				angular.forEach($scope.vList,function(v,i){
  					var sm = angular.isObject($scope.vModel) ? $scope.vModel : String($scope.vModel);
  					if(v === sm || String(v[$scope.vValue]) === sm)
  					$scope.selectText=v[$scope.vKey];// 用于显示input文本
      			});
  				if(!$scope.selectText && $attrs.vModel)
  				{
  					var model = $parse($attrs.vModel);
  					model.assign($scope.$parent,null);
  				}	
  			});
  			
  			$scope.chevronSelect=function($event,s){
  				$event.stopPropagation();
  				if(s)$($event.target).next("input").focus();
  			}
  			// 将ng-click改为ng-mousedown,可改变优先执行mousedown，后执行ng-blur
  			$scope.selectOne = function($event,item)
  			{
  				$scope.selectText=item ? item[$scope.vKey] : '';
  				if($attrs.vModel)
     			{
  					var model = $parse($attrs.vModel);
  					if(angular.isObject($scope.vModel)) {model.assign($scope.$parent,item || {});}
  					else
  					{model.assign($scope.$parent,item ? item[$scope.vValue] : undefined);}	
     			}
  				$scope.vFire();
  			}
  		}
 	 }
  })
  /**
   * 
   * <div class="col-sm-8 p0 multiple-select">
   *	 <vims-multiple-select select-list="selectList" select="select"  value="value"  label="label"></vims-multiple-select>
   * </div>
   * 
   **/
  .directive('vimsMultipleSelect', function($compile) {
        return {
        	restrict: 'E',
            scope:{
            	selectList:'=selectList',
            	select:'=select',
            	value:'@value',
            	label:'@label'
            },
            template: '<select class="selectpicker form-control" multiple data-live-search="true"></select>',
            replace: true,
            link:function(scope,element,attr)
            {
            	scope.$watchCollection("selectList",function(){
            		var options = [];
                	angular.forEach(scope.selectList,function(v,i){
                		options.push('<option  value="'+v[scope.value]+'">'+v[scope.label]+'</option>');
                	});
                	$(element).empty().append(options.join(""));
                	$(element).selectpicker({
            	        'selectedText': 'cat',
            	        'noneSelectedText':'请选择',
            	        'noneResultsText':'没有结果匹配 {0}'
            	    });
                	$(element).selectpicker('refresh');
            	});
            	// 设置值
            	scope.$watch("select",function(){
            		$(element).selectpicker('val', scope.select);
            	});
            	// 选中时设置
            	$(element).on('changed.bs.select', function(e) {
            		var val = $(this).val();
            		scope.$apply(function(){
            			scope.select=val;
            		})
            	});
            }
        };
    })
    .directive('vimsTree', function($templateCache) {
    	var template = [
    	                			'<div class="tree">',
							 		'<div class="item-search" ng-show="searchShow && treeData.length">',
							 			'<input type="text" class="form-control" ng-model="searchFilter" placeholder="请输入搜索关键字"/>',
							 			'<span class="glyphicon glyphicon-search tool-icon"></span>',
							 		'</div>',
										'<ul style="padding:0;">',
										'<li ng-class="{\'true\':\'parent_li\',\'false\':\'child_li\'}[!isLeaf(item)]" ng-repeat="item in tree track by $index" ng-include="\'treeRecursion\'" ></li>',
										'<li ng-if="!tree.length">没有相关记录<li>',
										'</ul>',
										$templateCache.get("tree.htm"),
										'</div>'
									].join("");
    	
    	return {
    		     restrict: 'E',
    			 replace: true,
    		     template: template,
    		     scope: {
    		       treeData: '=',
    		       textField: '@',
    			   valueField:'@',
    			   parentId:'@',
    			   searchFilter:'=',
    			   itemEdit:'=',
    			   itemSave:'&',
    			   itemDrag:'&',
    			   itemCheckbox:'=',
    			   itemTool:'@',
    			   itemDblclick:'&',
    			   itemClick:'&',
    			   itemChecked:'&'
    		     },
    		     controller:function($scope,$element,$attrs,$filter){
    				if($scope.itemTool)
    				{
    					var $$controller = $($element).closest("div[ng-controller]");
    					var $$itemTool = $($element).next("#" + $scope.itemTool);
    					$$itemTool.appendTo($$controller);
    				}	
    			
    				$scope.searchShow = !!$attrs.searchFilter;// 如果页面没有配置searchFilter属性，则不显示检索框
    				$scope.expendItem=function(item,$event){$event.stopPropagation();if($($event.target).is("input"))return; item.$$isExpend=!item.$$isExpend};
    				$scope.isLeaf = function(item){ return !item.children || !item.children.length;};
    				$scope.warpCallback = function(callback, item, $event){
    					// 外部调用方法。
    					($scope[callback] || angular.noop)({ $item:item, $event:$event});
    				};
    				
    				$scope.warpDblclickCallback = function(callback, item, $event){
    					$event.stopPropagation();
    					// 外部调用方法。
    					($scope[callback] || angular.noop)({ $item:item, $event:$event });
    				};
    				
    				$scope.drag = function(item)
    				{
    					if(item.draggable)
    					{
    						// 外部调用方法。
        					($scope.itemDrag || angular.noop)({ $item:item});
    					}	
    				}
    				
    				$scope.sure = function(item,callback){
     					($scope[callback] || angular.noop)({ $item:item});
     				}
    				
    				// 树节点复选框
    				$scope.checkItem = function(item,$event){
    					$event.stopPropagation();
    					delete item.$$state;
    					item.checked=!item.checked;
    					// 如果存在子节点，勾选input时，将子节点同步与当前节点的状态
    					$scope.check(item);
    					// 判断父节点进行全部选中，否则去除勾选状态
    					$scope.parentCheck(item);
    				}
    				
    				$scope.check=function(item)
    				{
    					if(item.children)
    					{
    						angular.forEach(item.children,function(v,i){
    							v.checked = item.checked;
    							delete item.$$state;
    							$scope.check(v);
    						})
    					}	
    				}
    				
    				$scope.parentCheck=function(item)
    				{
    					var $$parent;
    					angular.forEach($scope.treeData,function(tree,index){
    						if(!$$parent && item[$scope.parentId] === tree[$scope.valueField])
    						{
    							$$parent = tree;
    						}
    					});
    					// 找到父节点后，对父节点进行状态判断
    					if($$parent && $$parent.children)
    					{
    						var checkedlength = $scope.checked($$parent.children).checked.length;
    						var $$allchecked = $$parent.children.length == checkedlength;//全选中
    						if($$allchecked){
    							for(var i = 0;i<$$parent.children.length&&$$allchecked;i++){
    								if($$parent.children[i].$$state){
    									$$allchecked = false;
    								}
    							}
    						}
    						delete $$parent.$$state;
    						if($$allchecked)
    						{
    							$$parent.checked = true;
    							if(item.$$state){$$parent.$$state = item.$$state;}
    						}
    						else if(0 != checkedlength)
    						{
    							$$parent.checked = true;
    							$$parent.$$state ='indeterminate';//半选中
    						}
    						else
    						{
    							$$parent.checked = false;
    						}	
    						$scope.parentCheck($$parent);
    					}	
    				}
    				
    				// 分类选中和未选中状态的item
    				$scope.checked=function(treeData){
    					var checked =[],unchecked=[];
    					angular.forEach(treeData,function(tree,index){
    						if(tree.checked){checked.push(tree);}
    						else{unchecked.push(tree);}
    					});
    					return {checked:checked,unchecked:unchecked};
    				}
    				
    				$scope.edit = function(item,$event,callback)
    				{
    					$event.stopPropagation();
    					item.$$showEdit = !item.$$showEdit;
    					$scope.focus = item.$$showEdit;
    					($scope[callback] || angular.noop)({ $item:item, $event:$event });
    				}
    				
    				//javascript  树形结构
    				function generateTree(a){angular.forEach(a,function(d){delete d.children});var b={};angular.forEach(a,function(d){b[d[$scope.valueField]]=d});var c=[];angular.forEach(a,function(e){var d=b[e[$scope.parentId]];if(d){(d.children||(d.children=[])).push(e)}else{c.push(e)}});return c};
			
    				$scope.$watch("treeData",function(newValue,oldValue){
    					if(undefined != newValue)
    					{
    						if(!$scope.filter) { $scope.tree = generateTree(newValue); }// 生成树结构
    						var lineData = [];
    						angular.forEach($scope.tree,function(v,index){$scope.tree2LineData(lineData,v)});
    						angular.forEach(lineData,function(item,index){if(item.checked){$scope.parentCheck(item);}	});
    					}
    				},true);
    				
    				//监控输入框的变化，如果输入框字段发生变化，然后就执行最开始设计的函数setDepartListShow和setDepartListHide
                    $scope.$watch('searchFilter',function(newValue,oldValue){
                    	$scope.filter=false;
                        if(undefined != newValue && newValue!=oldValue)
                        {
                        	$scope.tree = generateTree($scope.searchTree($scope.treeData,newValue));
                            if(newValue!=""){ $scope.filter=true;$scope.setTreeShow($scope.tree) }
                            else{ $scope.setTreeHide($scope.tree);}
                        }
                    });
    				
                    $scope.tree2LineData = function(lineData,tree)
                    {
                    	lineData.push(tree);
                    	if(tree.children && tree.children.length!=0)
                    	{
                    		angular.forEach(tree.children,function(v,index){
                    			$scope.tree2LineData(lineData,v)
                    		});
                    	}	
                    }
                    
                    // 检索树
                    $scope.searchTree = function(data,search)
                    {
                    	if(!search)return data;
                    	var $$key = this.textField;
                    	var $$parentId = this.parentId;
                    	var filterTree = [];
                    	angular.forEach(data,function(item){ if(angular.lowercase(item[$$key]).indexOf(angular.lowercase(search)) >=0  && !$scope.exist(filterTree,item)) {filterTree.push(item); $scope.overTree(filterTree,data,item[$$parentId])}});
                    	// 数组去重算法
                    	return filterTree;
                    }

                    $scope.overTree=function(filterTree,data,parentId)
                    {
                    	var $$parentId = this.parentId;
                    	var $$value = this.valueField;
                    	angular.forEach(data,function(item){if(item[$$value] === parentId && !$scope.exist(filterTree,item)) { filterTree.push(item); $scope.overTree(filterTree,data,item[$$parentId]);return false;}})
                    	
                    }
                    
                    // 判断数组中是否存在
                    $scope.exist = function(trees,item)
                    {
                    	var $$value = this.valueField;
                    	var $idList = $.map(trees,function(n){return n[$$value]});
                    	return $.inArray(item[$$value],$idList) >= 0;
                    }
                    
    				//这段代码意思是如果要搜索树形，先展开树形所有节点
    				$scope.setTreeShow=function(node){
    				        for(var i=0;i<node.length;i++){
    				        	var children = node[i].children;
    				            if(children && children.length!=0){
    				                node[i].$$isExpend=true;
    				                $scope.setTreeShow(children);
    				            }
    				        }
    				    }
    				//这段代码意思是如果要搜索树形，然后隐藏跟搜索框不匹配的节点，这样2步就达到了 只展示出了跟搜索字段相匹配的结果
				    $scope.setTreeHide=function(node){
				        for(var i=0;i<node.length;i++){
				        	var children = node[i].children;
				            if(children && children.length!=0){
				                node[i].$$isExpend=false;
				                $scope.setTreeHide(children);
				            }
				        }
				    }
    			}};
    });
})(jQuery)