var app = angular.module("vims.webapp", ["ui.bootstrap","ui.router"]);
;(function($, app) {
	  "use strict";

	  app.config(function ($stateProvider,$locationProvider,$urlRouterProvider) {
		  var configs = [];
		  // 主页
		  configs.push({
			  stateName:"vimsportal",
			  stateConfig:{
				     url: '/list',
			    	 views: {
			    		  "content@":{
			    		 	    template: '',
			    		 	    controller:function($scope,$state){
			    		 	    	$state.go("vimsportal.home",{isRouter:true});
			    		 	    }
			    		 	}
			            }
			     }
		  });
		  
		  // 首页
		  configs.push({
			  stateName:"vimsportal.home",
			  stateConfig:{
				     url: '/0',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    		 	    template: '<h1 class="masked position-relative-center-h1">欢迎来到VIMS系统运营</h1>'
			    		 	}
			            }
			     }
		  });
		  
		  // 实时视频
		  configs.push({
			  stateName:"vimsportal.liveVideo",
			  stateConfig:{
				     url: '/1',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    		 	    templateUrl: basePath + "/liveVideo",
			    		 	    controller:"LiveVideoCtrl"
			    		 	}
			            }
			     }
		  });
		  
		  // 录像回放
		  configs.push({
			  stateName:"vimsportal.videoPlayback",
			  stateConfig:{
				     url: '/2',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    		 	    templateUrl: basePath + "/videoPlayback",
			    		 	    controller:"VideoPlaybackCtrl"
			    		 	}
			            }
			     }
		  });
		
		  // 车辆定位
		  configs.push({
			  stateName:"vimsportal.vehiclePosition",
			  stateConfig:{
				     url: '/3',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    		 	    templateUrl: basePath + "/vehiclePosition",
			    		 	    controller:"VehiclePositionCtrl"
			    		 	}
			            }
			     }
		  });
		  
		// 车辆定位
		  configs.push({
			  stateName:"vimsportal.historyTrack",
			  stateConfig:{
				     url: '/4',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    		 	    templateUrl: basePath + "/historyTrack",
			    		 	    controller:"HistoryTrackCtrl"
			    		 	}
			            }
			     }
		  });
		  
		  // 运行报表
		  configs.push({
			  stateName:"vimsportal.runReport",
			  stateConfig:{
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    		 	    templateUrl: basePath + "/runReport",
			    		 	    controller:"RunReportCtrl"
			    		 	}
			            }
			     }
		  });
		  
		 // 运行报表-司机每日里程明细报表
		  configs.push({
			  stateName:"vimsportal.runReport.dailyMileageReportForDrivers",
			  stateConfig:{
				     url: '/5/:id',
				     params:{isRouter:null},
			    	 views: {
			    		  "runReportContent@vimsportal.runReport":{
			    		 	    templateUrl: basePath + "/dailyMileageReportForDrivers",
			    		 	    controller:"DailyMileageReportForDriversCtrl"
			    		 	}
			            }
			     }
		  });
		  
		  // 系统支撑==================================================================
		  
		  // 主页
		  configs.push({
			  stateName:"vimssupport",
			  stateConfig:{
				     url: '/backstage',
			    	 views: {
			    		  "content@":{
			    		 	    template: '',
			    		 	    controller:function($scope,$state){
			    		 	    	$state.go("vimssupport.home",{isRouter:true});
			    		 	    }
			    		 	}
			            }
			     }
		  });
		  
		  // 首页
		  configs.push({
			  stateName:"vimssupport.home",
			  stateConfig:{
				     url: '/0',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    		 	    template: '<h1 class="masked position-relative-center-h1">欢迎来到VIMS系统运营支撑</h1>'
			    		 	}
			            }
			     }
		  });
		  
		 // 角色管理
		  configs.push({
			  stateName:"vimssupport.roleManager",
			  stateConfig:{
				     url: '/1',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    			  templateUrl: basePath + "/role/roleManager",
			    			  controller:"RoleManagerCtrl"
			    		 	}
			            }
			     }
		  });
		  
		 // 部门管理
		  configs.push({
			  stateName:"vimssupport.deptManager",
			  stateConfig:{
				     url: '/2',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    			  templateUrl: basePath + "/organization/deptManager",
			    			  controller:"DeptManagerCtrl"
			    		 	}
			            }
			     }
		  });
		  // 操作员管理
		  configs.push({
			  stateName:"vimssupport.operManager",
			  stateConfig:{
				     url: '/3',
				     params:{isRouter:null},
			    	 views: {
			    		  "content@":{
			    			  templateUrl: basePath + "/user/operManager",
			    			  controller:"OperatorManagerCtrl"
			    		 	}
			            }
			     }
		  });
		  
	  angular.forEach(configs,function(v,i){
		  $stateProvider.state(v.stateName,v.stateConfig);
	  })
	});
	  
	  app.run(['$rootScope', '$state', '$timeout', function($rootScope, $state, $timeout) {
	  $rootScope.$on('$stateChangeStart', function(event, toState, toStateParams) {
		  if(toStateParams.hasOwnProperty("isRouter") && !toStateParams.isRouter)event.preventDefault();
	  });
  }]);  
	})(jQuery, app)
