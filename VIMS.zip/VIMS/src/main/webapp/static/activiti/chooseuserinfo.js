function JumpNextProcess(title, url, height, width, top,stationName,path,status,select,close){
		var ids = "";
		var url = url + "?mrSectNo="+ids+"&buttonId="+"choseUserJumt";
		if(!select) select = "Select";
		if(!close) close = "Close";
		parent.$.modalDialog({
            title : title,
            width : 860,
            height : 540,
            href : url,
            buttons : [ {
            	id : "choseUserJumt",
                text : select,
                handler : function() {
                    var f = parent.$.modalDialog.handler.find('#dataGridChose').datagrid('getSelected');
                    var name = f.id;
                    var appid = $('#appId').val();
                    var taskId = $('#taskId').val();
                    var tprocinstId = $('#tprocinstId').val();
                    $.ajax({
						cache : false,
						async : false,
						type : "POST",
						url :path+"/processJump/processJumpWorkflow?name="+name+"&appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId+"&stationName="+stationName+"&status="+status,
						success : function(data) {
						var result = eval('(' + data + ')');
						if (result.startMessage == 1) {  debugger;
							parent.$.success($("#flowsuccess").val());
							parent.$.modalDialog.handler.dialog('close');
							setTimeout(function(){
								$(".messager-body").window('close');
								if (window.parent.location.href.toLowerCase().indexOf('workflowindex') != -1) {
									window.parent.location.href=path+"/oa/leave/list/task";
								} else {
									window.location.href=path+"/oa/leave/list/task";
								}
	                   		},1000);

							
						} else {
							parent.$.error('Process Delivery Failed!');
							parent.$.modalDialog.handler.dialog('close');
						}
					},
					error : function(request) {
						parent.$.error('System error!');
						parent.$.modalDialog.handler.dialog('close');
					}
				});
                }
            },{
            	text : close,
                handler : function() {
                	parent.$.modalDialog.handler.dialog('close');
                }
            } ]
        });
	}

function assginNextUser(title,url,taskId,appid,tprocinstId){
	var ids = "";
	var url = url + "?buttonId=choseUserButtonId&mrSectNo="+ids;
	parent.$.modalDialog({
        title : title,
        width : 860,
        height : 540,
        href : url,
        buttons : [ {
        	id : 'choseUserButtonId',
            text : 'Select',
            handler : function() {
                var f = parent.$.modalDialog.handler.find('#dataGridChose').datagrid('getSelected');
                var name = f.id;
                $.ajax({
					cache : false,
					async : false,
					type : "POST",
					url :path+"/oa/leave/task/assign?name="+name+"&appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId,
					success : function(data) {
					var result = eval('(' + data + ')');
					if (result.startMessage == 1) {
						parent.$.success('Operation success！');
						parent.$.modalDialog.handler.dialog('close');
					} else {
						parent.$.error('Operation failed！');
						parent.$.modalDialog.handler.dialog('close');
					}
				},
				error : function(request) {
					parent.$.error('System error！');
					parent.$.modalDialog.handler.dialog('close');
				}
			});
            }
        },{
        	text : 'Close',
            handler : function() {
            	parent.$.modalDialog.handler.dialog('close');
            }
        } ]
    });
}
/**
 * rcvFeeFlag : 控制是否走业务收费环节
 */
function gridJumpNextProcess(deptId, appid, taskId, tprocinstId, switchFlag,path,status,rcvFeeFlag){
	progressLoad();
	url = path+"/processJump/gridJumpflow?deptId="+deptId+"&appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId+"&switchFlag="+switchFlag+"&status="+status;
	if(rcvFeeFlag != undefined && rcvFeeFlag != '' && rcvFeeFlag != null)
		url += "&rcvFeeFlag="+rcvFeeFlag;
    $.ajax({
		cache : false,
		async : false,
		type : "POST",
		url : url,
		success : function(data) { debugger;
			progressClose();
			var result = eval('(' + data + ')');
			if (result.startMessage == 1) {
				/*parent.$.success('Process Delivery Succeeded!',function(){
					$(".messager-body").window('close');
					redirect(path);
				});*/
				parent.$.messager.alert({
			        title: amiPortal.localeMsg.msgTitle,
			        msg: $("#flowsuccess").val(),
			        icon: 'success',
			        fn: function(){
						$(".messager-body").window('close');
						redirect(path);
					},
					onClose:function(){
						$(".messager-body").window('close');
						redirect(path);
					}
			    });
			} else {
				parent.$.error('Process Delivery Failed!');
				parent.$.modalDialog.handler.dialog('close');
			}
			parent.$.modalDialog.handler.dialog('close');
		},
		error : function(request) {
			progressClose();
			parent.$.error('System error！');
			parent.$.modalDialog.handler.dialog('close');
		}
	});
}

function redirect(path) {
	if (window.parent.location.href.toLowerCase().indexOf('workflowindex') != -1) {
		parent.parent.addOrUpdateTab(todoListTitle,"/oa/leave/list/gridTask");
	} else {
		var tab = parent.$('#index_tabs').tabs('getSelected');
		var index = parent.$('#index_tabs').tabs('getTabIndex',tab);
		parent.addOrUpdateTab(todoListTitle,"/oa/leave/list/gridTask");
		parent.$('#index_tabs').tabs('close', index);
		//<spring:message code="resource_id_13030700"/>
	}
}

function JumpBackProcess2(title, url, height, width, top,path,status,select,close){
	var ids = "";
	var url = url + "?mrSectNo="+ids;
	if(!select) select = "Select";
	if(!close) close = "Close";
	parent.$.modalDialog({
        title : title,
        width : 860,
        height : 540,
        href : url,
        buttons : [ {
            text : select,
            handler : function() {
                var f = parent.$.modalDialog.handler.find('#dataGridChose').datagrid('getSelected');
                var name = f.id;
                var appid = $('#appId').val();
                var taskId = $('#taskId').val();
                var tprocinstId = $('#tprocinstId').val();
                $.ajax({
					cache : false,
					async : false,
					type : "POST",
					url :path+"/processJump/processJumpWorkflow?name="+name+"&appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId+"&status="+status,
					success : function(data) {
					var result = eval('(' + data + ')');
					if (result.startMessage == 1) {
						parent.$.success('Process Rollback Succeeded!');
						parent.$.modalDialog.handler.dialog('close');
						setTimeout(function(){
							$(".messager-body").window('close');
							if (window.parent.location.href.toLowerCase().indexOf('workflowindex') != -1) {
								window.parent.location.href=path+"/oa/leave/list/task";
							} else {
								window.location.href=path+"/oa/leave/list/task";
							}
                   		},1000);

						
					} else {
						parent.$.error('Process Rollback Failed!');
						parent.$.modalDialog.handler.dialog('close');
					}
				},
				error : function(request) {
					parent.$.error('System error!');
					parent.$.modalDialog.handler.dialog('close');
				}
			});
            }
        },{
        	text : close,
            handler : function() {
            	parent.$.modalDialog.handler.dialog('close');
            }
        } ]
    });
}



function JumpBackProcess(path, status){
	progressLoad();
	if (!status) {
		status = false;
	}
	var appid = $('#appId').val();
	var taskId = $('#taskId').val();
	var tprocinstId = $('#tprocinstId').val();
	$.ajax({
		cache : false,
		async : false,
		type : "POST",
		url :path+"/processJump/processJumpWorkflow?appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId+"&status=" + status,
		success : function(data) {
			progressClose();
			var result = eval('(' + data + ')');
			if (result.startMessage == 1) {
				/*parent.$.success('Process Rollback Succeeded!',function(){
					$(".messager-body").window('close');
					redirect(path);
				});*/
				parent.$.messager.alert({
			        title: amiPortal.localeMsg.msgTitle,
			        msg: 'Process Rollback Succeeded!',
			        icon: 'success',
			        fn: function(){
						$(".messager-body").window('close');
						redirect(path);
					},
					onClose:function(){
						$(".messager-body").window('close');
						redirect(path);
					}
			    });
			} else {
				parent.$.error('Process Rollback Failed!');
			}
		},
		error : function(request) {
			progressClose();
			parent.$.error('System error!');
		}
	});
}


function JumpEndProcess2(path){
	var appid = $('#appId').val();
    var taskId = $('#taskId').val();
    var tprocinstId = $('#tprocinstId').val();
	doJumpEndProcess2(path,appid,taskId,tprocinstId);
}

function doJumpEndProcess2(path,appid,taskId,tprocinstId){
	$.ajax({
		cache : false,
		async : false,
		type : "POST",
		url :path+"/processJump/stealProcessEndflow?appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId,
		success : function(data) {
			var result = eval('(' + data + ')');
			if (result.startMessage == 1) {
				parent.$.success('Process Stop Succeeded!');
				setTimeout(function(){
					$(".messager-body").window('close');
					if (window.parent.location.href.toLowerCase().indexOf('workflowindex') != -1) {
						window.parent.location.href=path+"/oa/leave/list/task";
					} else {
						window.location.href=path+"/oa/leave/list/task";
					}
				},1000);
			} else {
				parent.$.error('Process Finish Failed!');
			}
		},
		error : function(request) {
			parent.$.error('System error!');
		}
	});
}

function JumpEndProcess(path){
	var appid = $('#appId').val();
    var taskId = $('#taskId').val();
    var tprocinstId = $('#tprocinstId').val();
	doJumpEndProcess(path,appid,taskId,tprocinstId);
}

function doJumpEndProcess(path,appid,taskId,tprocinstId){
	$.ajax({
		cache : false,
		async : false,
		type : "POST",
		url :path+"/processJump/processEndflow?appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId,
		success : function(data) {
			var result = eval('(' + data + ')');
			if (result.startMessage == 1) {
				parent.$.success('Process Stop Succeeded!');
				setTimeout(function(){
					$(".messager-body").window('close');
					if (window.parent.location.href.toLowerCase().indexOf('workflowindex') != -1) {
						window.parent.location.href=path+"/oa/leave/list/task";
					} else {
						window.location.href=path+"/oa/leave/list/task";
					}
				},1000);
			} else {
				parent.$.error('Process Finish Failed!');
			}
		},
		error : function(request) {
			parent.$.error('System error!');
		}
	});
}


function JumpNextProcessForCrm(title, url, height, width, top,stationName,path,status,select,close){
	var ids = "";
	var url = url + "?mrSectNo="+ids;
	if(!select) select = "Select";
	if(!close) close = "Close";
	parent.$.modalDialog({
        title : title,
        width : 860,
        height : 540,
        href : url,
        buttons : [ {
            text : select,
            handler : function() {
                var f = parent.$.modalDialog.handler.find('#dataGridChose').datagrid('getSelected');
                var name = f.id;
                var appid = $('#appId').val();
                var taskId = $('#taskId').val();
                var tprocinstId = $('#tprocinstId').val();
                $.ajax({
					cache : false,
					async : false,
					type : "POST",
					url :path+"/processJump/processJumpWorkflow?name="+name+"&appid="+appid+"&taskId="+taskId+"&tprocinstId="+tprocinstId+"&stationName="+stationName+"&status="+status,
					success : function(data) {
					var result = eval('(' + data + ')');
					if (result.startMessage == 1) {
						parent.$.success($("#flowsuccess").val());
						parent.$.modalDialog.handler.dialog('close');
						//parent.window('close');
						setTimeout(function(){
							$(".messager-body").window('close');
							if (window.parent.location.href.toLowerCase().indexOf('workflowindex') != -1) {
								window.parent.location.href=path+"/oa/leave/list/task";
							} else {
								window.location.href=path+"/oa/leave/list/task";
							}
                   		},1000);

						
					} else {
						parent.$.error('Process Delivery Failed!');
						parent.$.modalDialog.handler.dialog('close');
					}
				},
				error : function(request) {
					parent.$.error('System error!');
					parent.$.modalDialog.handler.dialog('close');
				}
			});
            }
        },{
        	text : close,
            handler : function() {
            	parent.$.modalDialog.handler.dialog('close');
            }
        } ]
    });
}
