function graphTrace(options) {
    var _defaults = {
        srcEle: this,
        pid: $(this).attr('pid'),
	    pdid: $(this).attr('pdid'),
	    appno: $(this).attr('appno')
    };
    var opts = $.extend(true, _defaults, options);

    // 获取图片资源
    var imageUrl = ctx + "/workflow/resource/process-instance?timestamp=" + (new Date()).valueOf()+"&pid=" + opts.pid + "&type=image";
    $.getJSON(ctx + '/workflow/process/traceNew?timestamp=' + (new Date()).valueOf()+'&pid=' + opts.pid+'&appno='+opts.appno, function(infos) {

        var positionHtml = "";
        var taskHtml = "";
        var taskStr="";

        // 生成图片
        var varsArray = new Array();
        $.each(infos.activityInfos, function(i, v) {
            var $positionDiv = $('<div/>', {
                'class': 'activity-attr'
            }).css({
                position: 'absolute',
                left: (v.x - 1),
                top: (v.y + 40),
                width: (v.width - 2),
                height: (v.height - 2),
                backgroundColor: 'black',
                opacity: 0,
                zIndex: $.fn.qtip.zindex - 1
            });

            // 节点边框
            var $border = $('<div/>', {
                'class': 'activity-attr-border'
            }).css({
                position: 'absolute',
                left: (v.x - 1),
                top: (v.y + 40),
                width: (v.width - 4),
                height: (v.height - 3),
                zIndex: $.fn.qtip.zindex - 2
            });

            if (v.currentActiviti) {
                $border.addClass('ui-corner-all-12').css({
                    border: '3px solid red'
                });
            }
            positionHtml += $positionDiv.outerHTML() + $border.outerHTML();
            varsArray[varsArray.length] = v.vars;
        });

        //增加任务处理信息列表
        var $taskDiv= $('<div/>', {
            'class': 'activity-task-attr',
            html:function(){
            	taskStr+="<table class='need-border'>";
            	$.each(infos.actTasks, function(varKey, varValue) {
                    if (varValue.vars && varValue.vars.taskStatus != "unHandled") {
                    	if(!varValue.vars.EndTime || null==varValue.vars.EndTime || ""==varValue.vars.EndTime ||"null"==varValue.vars.EndTime){
                    		var oper = varValue.vars.Operator;
                    		if(null==oper || ""==oper){
                    			oper="Not sign";
                    		}
                    		var dept = varValue.vars.Department;
                    		if(null==dept || ""==dept){
                    			dept="No dept";
                    		}
                    		taskStr += "<tr><td ><div class='processNode current'></div></td>" +
                    				"<td>【" +varValue.vars.nodeName +"】Dept:"+ dept+" Operator: "+ oper + ", Start Time: " +varValue.vars.StartTime+ ", Current Time: " + varValue.vars.CurrentTime + "<td/></tr>";
                    	}else{
                    		var oper = varValue.vars.Operator;
                    		if(null==oper || ""==oper){
                    			oper="";
                    		}
                    		var dept = varValue.vars.Department;
                    		if(null==dept || ""==dept){
                    			dept="";
                    		}
                    		taskStr += "<tr><td><div class='processNode'></div></td>" +
                    				"<td>【" +varValue.vars.nodeName +"】Dept:"+ dept+" Operator: "+ oper + ", Start Time: " +varValue.vars.StartTime+ ", End Time: " + varValue.vars.EndTime + "<td/></tr>";
                    		
                    		taskStr += "<tr><td align='center'>|<td/><td><td/></tr>";
                    	}
                    }
                });
            	taskStr+="</table>";
            	return taskStr;
            }
        }).css({
        	align:'center',
        	top:'40px'
        });;
        
        taskHtml += $taskDiv.outerHTML();
        
        if ($('#workflowTraceDialog').length == 0) {
            $('<div/>', {
                id: 'workflowTraceDialog',
                title: 'View Flowchart',
                html: "<div>" +
                "<div fit='true' id='processImageBorder'  style='float:left; width:50%; '>" +
                "<img id='imageUrl' src='" + imageUrl + "' style='position:absolute; left:0px; top:40px;' />"+
                "<div id='positionHtml'>" +
                positionHtml +
                "</div>" +
                "</div>" +
                "</div>"+
                "<div id='taskInstDiv' style='float:right; width:50%; left:0px; top:40px;'>"+
                taskHtml +
                "</div>"
            }).appendTo('body');
        } else {
            $('#workflowTraceDialog #processImageBorder img').attr('src', imageUrl);
            $('#workflowTraceDialog #processImageBorder #positionHtml').html(positionHtml);
            $('#workflowTraceDialog #taskInstDiv').html(taskHtml);
        }
        
        // 设置每个节点的data
        $('#workflowTraceDialog .activity-attr').each(function(i, v) {
            $(this).data('vars', varsArray[i]);
        });
        
        
        // 打开对话框
        $('#workflowTraceDialog').dialog({
            modal: true,
            resizable: false,
            dragable: false,
            width: document.documentElement.clientWidth * 0.95,
            height: document.documentElement.clientHeight * 0.95
        });
        
        // 此处用于显示每个节点的信息，如果不需要可以删除
        /*$('#workflowTraceDialog .activity-attr').qtip({
            content: function() {
            	debugger
                var vars = $(this).data('vars');
                var tipContent = "<table class='need-border'>";
                $.each(vars, function(varKey, varValue) {
                    if (varValue) {
                        tipContent += "<tr><td class='label'>" + varKey + ":</td><td>" + varValue + "<td/></tr>";
                    }
                });
                tipContent += "</table>";
                return tipContent;
            },
            show: 'mouseover',
            hide: 'mouseout',
            position: {
                at: 'bottom left',
                adjust: {
                    x: 3
                }
            }
        });*/
        
        $("#workflowTraceDialog").removeClass("panel-body").removeClass("window-body");
        $("#workflowTraceDialog").parent().css({"overflow-y":"auto","background-color":"#fafafa"});
        $("#workflowTraceDialog").parent().children('.panel-header').children('.panel-tool').css({right:'20px'});
    });
}
