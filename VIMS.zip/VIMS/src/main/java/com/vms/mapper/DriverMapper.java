package com.vms.mapper;

import java.util.List;
import java.util.Map;

import com.vms.model.DriverDetailInfo;
import com.vms.model.DriverInfo;



public interface DriverMapper 
{
    /**
     * 查询驾驶员信息
     *
     * @param id
     * @return
     */
    List<DriverInfo> queryDriverInfo(Map<String, Object> param);
    
    List<DriverDetailInfo> queryDriverDetailInfo(Map<String, Object> param); 
    
    
}
    