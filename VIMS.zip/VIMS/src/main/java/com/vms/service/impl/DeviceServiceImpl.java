package com.vms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vms.mapper.DeviceMapper;
import com.vms.model.DeviceTree;
import com.vms.service.DeviceService;

@Service
public class DeviceServiceImpl implements DeviceService
{
    private static final Logger logger = LoggerFactory.getLogger(RoleServiceImpl.class);
    
    @Autowired
    private DeviceMapper deviceMapper;

	@Override
	public List<DeviceTree> queryDeviceInfo() 
	{
		
		logger.debug("Begin query device infomation");
		
		List<DeviceTree> deviceTree = null;

		deviceTree = deviceMapper.queryDeviceTree();

		return generate(deviceTree);
	}
	
	
	public static List<DeviceTree> generate(List<DeviceTree>deviceTree)
	{
		List<DeviceTree> rootTrees = new ArrayList<DeviceTree>();
		for (DeviceTree tree : deviceTree) 
		{
			if(tree.getPid() == -1)
			{
				rootTrees.add(tree);
			}
			
			for (DeviceTree t : deviceTree) 
			{
				if(t.getPid() == tree.getId())
				{
					if(tree.getChildren() == null)
					{
						List<DeviceTree> myChildrens = new ArrayList<DeviceTree>();
						myChildrens.add(t);
						tree.setChildren(myChildrens);
					}
					else
					{
						tree.getChildren().add(t);
					}
				}
			}
		}
		
		return rootTrees;

	}
	
	
//	public static List<DeviceTree> buildByRecursive(List<DeviceTree> treeNodes) 
//	{
//		List<DeviceTree> trees = new ArrayList<DeviceTree>();
//		
//		for (DeviceTree treeNode : treeNodes) {
//			if ("-1".equals(treeNode.getPid())) {
//				trees.add(treeNode);
//			}
//			else
//			{
//				trees.add(findChildren(treeNode, treeNodes));
//			}
//		}
//		return trees;
//	}
//	
//	
//	public static DeviceTree findChildren(DeviceTree treeNode,List<DeviceTree> treeNodes) 
//	{
//		for (DeviceTree it : treeNodes) 
//		{
//			if (treeNode.getId().equals(it.getPid())) 
//			{
//				if (treeNode.getChildren() == null) {
//					
//					List<DeviceTree> myChildrens = new ArrayList<DeviceTree>();
//					myChildrens.add(it);
//					treeNode.setChildren(myChildrens);
//				}
//				else
//				{
//					treeNode.getChildren().add(it);
//				}
//				
//			}
//			else
//			{
//				//treeNode.getChildren().add(findChildren(it, treeNodes));
//			}
//		}
//		return treeNode;
//	}

}
