package com.vms.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vms.mapper.VehicleMapper;
import com.vms.model.VehiclePosInfo;
import com.vms.model.VehicleWtihDept;
import com.vms.service.VehicleService;

@Service
public class VehicleServiceImpl implements VehicleService 
{
	//private static final Logger LOGGER = LoggerFactory.getLogger(VehicleServiceImpl.class);

	@Autowired
	private VehicleMapper vehicleMapper;

	@Override
	public List<VehiclePosInfo> QueryVehiclePosInfo(String cardNumberList) 
	{

		Map<String, Object> param = new HashMap<String, Object>();

		param.put("CARDNUMBERLIST", cardNumberList);

		return vehicleMapper.queryVehicleInfoByCardNumberList(param);
	}
	
	@Override
	public List<VehicleWtihDept> QueryVehicleWtihDeptInfo(String status,String cardNumber)
	{
		Map<String, Object> param = new HashMap<String, Object>();

		param.put("STATUS", status);
		
		param.put("CARDNUMBER", cardNumber);

		return vehicleMapper.queryVehicleWtihDeptInfo(param);
	}

	@Override
	public List<VehiclePosInfo> QueryVehicleHisPosInfo(String startTime,String endTime, String cardNumber) 
	{
		Map<String, Object> param = new HashMap<String, Object>();

		param.put("CARDNUMBER", cardNumber);
		param.put("STARTTIME", startTime);
		param.put("ENDTIME", endTime);

		return vehicleMapper.queryVehicleHisInfoByCardNumber(param);
	}

	@Override
	public int updateVehicleInfo(String deviceID,String flag,String dimension,String dimension_flag,String longitude,String longitude_flag,String currentTime) 
	{
		Map<String, Object> param = new HashMap<String, Object>();

		param.put("CARDNUMBER", deviceID);
		param.put("CTIME", currentTime);
		param.put("LONGITUDE", longitude);
		param.put("DIMENSION", dimension);
		param.put("DIMENSION_FLAG", dimension_flag);
		param.put("LONGITUDE_FLAG", longitude_flag);
		param.put("FLAG", flag);

		return vehicleMapper.updateVehicleInfo(param);
	}
}
