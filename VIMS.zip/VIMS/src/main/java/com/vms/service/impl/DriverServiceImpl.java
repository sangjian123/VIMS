package com.vms.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vms.mapper.DriverMapper;
import com.vms.model.DriverDetailInfo;
import com.vms.model.DriverInfo;
import com.vms.service.DriverService;

@Service
public class DriverServiceImpl implements DriverService 
{
	@Autowired
	private DriverMapper driverMapper;
	
	@Override
	public List<DriverInfo> queryDriverInfo(String name) 
	{

		Map<String, Object> param = new HashMap<String, Object>();

		param.put("DRIVERNAME", name);

		return driverMapper.queryDriverInfo(param);
	}
	
	@Override
	public List<DriverDetailInfo> queryDetailInfo(String driverName,String startTime,String endTime) 
	{

		Map<String, Object> param = new HashMap<String, Object>();

		param.put("DRIVERNAME", driverName);
		
		param.put("STARTTIME", startTime);
		
		param.put("ENDTIME", endTime);

		return driverMapper.queryDriverDetailInfo(param);
	}
	
}
	