package com.vms.service;

import java.util.List;

import com.vms.model.VehiclePosInfo;
import com.vms.model.VehicleWtihDept;

public interface VehicleService 
{
    /**
     * 查询设备信息
     *
     * @param cardNumberList 设备之间用逗号隔开
     */
	List<VehiclePosInfo> QueryVehiclePosInfo(String cardNumberList);
	
	
    /**
     * 查询设备及部门信息
     *
     * @param Status
     * @param cardNumberList 设备之间用逗号隔开
     */
	List<VehicleWtihDept> QueryVehicleWtihDeptInfo(String status, String cardNumbers);
	
	
	
    /**
     * 查询设备历史信息
     *
     * @param cardNumberList 设备之间用逗号隔开
     */
	List<VehiclePosInfo> QueryVehicleHisPosInfo(String startTime,String endTime,String cardNumber);
	
	
    /**
     * 更新设备历史信息
     *
     * @param cardNumberList 设备之间用逗号隔开
     */
	int updateVehicleInfo(String deviceID,String flag,String dimension,String dimension_flag,String longitude,String longitude_flag,String currentTime);

}
