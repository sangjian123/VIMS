package com.vms.service;

import java.util.List;

import com.vms.model.DriverDetailInfo;
import com.vms.model.DriverInfo;

public interface DriverService 
{
	/**
     * 
     * @return DriverInfo
     */
	List<DriverInfo> queryDriverInfo(String name);
	
	
	List<DriverDetailInfo> queryDetailInfo(String driverName,String startTime,String endTime);
}
