package com.vms.model;

public class VehicleWtihDept 
{
    private static final long serialVersionUID = 6700813629656881143L;
	
	public static long getSerialversionuid() 
	{
		return serialVersionUID;
	}

	private String cardnumber;
	
	private String deptName;

	public String getCardnumber() 
	{
		return cardnumber;
	}

	public void setCardnumber(String cardnumber) 
	{
		this.cardnumber = cardnumber;
	}

	public String getDeptName() 
	{
		return deptName;
	}

	public void setDeptName(String deptName) 
	{
		this.deptName = deptName;
	}

	@Override
	public String toString() 
	{
		return "VehicleWtihDept [cardnumber=" + cardnumber + ", deptName="
				+ deptName + "]";
	}

}
