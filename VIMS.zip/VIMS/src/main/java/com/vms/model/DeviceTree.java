package com.vms.model;

import java.util.List;

public class DeviceTree 
{
	
	private static final long serialVersionUID = 980682543891282923L;
	
    private Long id;
    
    private Long pid;
    
    private String name;
    
    private Long isLeaf;
    
    private String desc;
    
    private String url;
    
    private String userName;
    
    private String password;
    
    private String devName;
    
    private String devPassword;
    
    private String channelID;
    
    private List <DeviceTree> children;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getIsLeaf() {
		return isLeaf;
	}

	public void setIsLeaf(Long isLeaf) {
		this.isLeaf = isLeaf;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDevName() {
		return devName;
	}

	public void setDevName(String devName) {
		this.devName = devName;
	}

	public String getDevPassword() {
		return devPassword;
	}

	public void setDevPassword(String devPassword) {
		this.devPassword = devPassword;
	}

	public List<DeviceTree> getChildren() {
		return children;
	}

	public void setChildren(List<DeviceTree> children) {
		this.children = children;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getChannelID() {
		return channelID;
	}

	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}

	@Override
	public String toString() {
		return "DeviceTree [id=" + id + ", pid=" + pid + ", name=" + name
				+ ", isLeaf=" + isLeaf + ", desc=" + desc + ", url=" + url
				+ ", userName=" + userName + ", password=" + password
				+ ", devName=" + devName + ", devPassword=" + devPassword
				+ ", channelID=" + channelID + ", children=" + children + "]";
	}
}
