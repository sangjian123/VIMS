package com.vms.model;

public class DriverDetailInfo 
{
     private String userName;
     
     private String time;
     
     private String startMile;
     
     private String endMile;
     
     private String todayMile;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getStartMile() {
		return startMile;
	}

	public void setStartMile(String startMile) {
		this.startMile = startMile;
	}

	public String getEndMile() {
		return endMile;
	}

	public void setEndMile(String endMile) {
		this.endMile = endMile;
	}

	public String getTodayMile() {
		return todayMile;
	}

	public void setTodayMile(String todayMile) {
		this.todayMile = todayMile;
	}

	@Override
	public String toString() {
		return "DriverDetailInfo [userName=" + userName + ", time=" + time
				+ ", startMile=" + startMile + ", endMile=" + endMile
				+ ", todayMile=" + todayMile + "]";
	}
}
