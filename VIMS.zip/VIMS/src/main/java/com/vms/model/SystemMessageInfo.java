/*
 * <p>Title: 运管系统</p>
 * <p>Description: 运管系统</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: 江苏方天电力技术有限公司</p>
 */
package com.vms.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * SystemMessageInfo  系统消息
 * @author codegen
 * @version 1.0
 */
public class SystemMessageInfo implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Long id;
    
    private String msgTitle;
    
    private String msgText;
    
    private String procDefId;
    
    private String taskId;
    
    private String taskDefKey;
    
    private String processInstId;
    
    private String customUrl;
    
    private String appId;
    
    private String userId;
    
    private String taskName;
    
    private String status;
    
    private Timestamp createTime;
    
    public Long getId ()
    {
        return id;
    }
    
    public void setId (Long id)
    {
        this.id = id;
    }
    
    public String getMsgTitle ()
    {
        return msgTitle;
    }
    
    public void setMsgTitle (String msgTitle)
    {
        this.msgTitle = msgTitle;
    }
    
    public String getMsgText ()
    {
        return msgText;
    }
    
    public void setMsgText (String msgText)
    {
        this.msgText = msgText;
    }
    
    public String getProcDefId ()
    {
        return procDefId;
    }
    
    public void setProcDefId (String procDefId)
    {
        this.procDefId = procDefId;
    }
    
    public String getTaskId ()
    {
        return taskId;
    }
    
    public void setTaskId (String taskId)
    {
        this.taskId = taskId;
    }
    
    public String getTaskDefKey ()
    {
        return taskDefKey;
    }
    
    public void setTaskDefKey (String taskDefKey)
    {
        this.taskDefKey = taskDefKey;
    }
    
    public String getProcessInstId ()
    {
        return processInstId;
    }
    
    public void setProcessInstId (String processInstId)
    {
        this.processInstId = processInstId;
    }
    
    public String getCustomUrl ()
    {
        return customUrl;
    }
    
    public void setCustomUrl (String customUrl)
    {
        this.customUrl = customUrl;
    }
    
    public String getAppId ()
    {
        return appId;
    }
    
    public void setAppId (String appId)
    {
        this.appId = appId;
    }
    
    public String getUserId ()
    {
        return userId;
    }
    
    public void setUserId (String userId)
    {
        this.userId = userId;
    }
    
    public String getTaskName ()
    {
        return taskName;
    }
    
    public void setTaskName (String taskName)
    {
        this.taskName = taskName;
    }
    
    /**
     * @return
     */
    public Timestamp getCreateTime ()
    {
        if (createTime == null)
        {
            return null;
        }
        return (Timestamp) createTime.clone ();
    }
    
    /**
     * @param createTime
     *            the createTime to set
     */
    public void setCreateTime (Timestamp createTime)
    {
        if (createTime == null)
        {
            this.createTime = null;
        }
        else
        {
            this.createTime = (Timestamp) createTime.clone ();
        }
    }
    
    public String getStatus ()
    {
        return status;
    }
    
    public void setStatus (String status)
    {
        this.status = status;
    }
    
}
