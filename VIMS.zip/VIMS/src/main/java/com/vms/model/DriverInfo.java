package com.vms.model;

public class DriverInfo 
{
	private String driverName;

	public String getDriverName() 
	{
		return driverName;
	}

	public void setDriverName(String driverName) 
	{
		this.driverName = driverName;
	}

	@Override
	public String toString() 
	{
		return "DriverInfo [driverName=" + driverName + "]";
	}

}
