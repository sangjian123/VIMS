package com.vms.model;

import java.io.Serializable;

/**
 * @description：用户角色关联
 * @author：zhixuan.wang
 * @date：2015/10/1 14:51
 */
public class UserRole implements Serializable {

    private static final long serialVersionUID = -8332992884983317378L;

    private Long id;

    private String userId;

    private Long roleId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    @Override
    public String toString() {
        return "UserRole{" +
                "id=" + id +
                ", userId=" + userId +
                ", roleId=" + roleId +
                '}';
    }
}