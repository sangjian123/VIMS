package com.vms.constant;

public interface ConstantCode
{
    /**
     * 成功状态码
     */
    int SUCCESS_CODE = 1;
    
    /**
     * 成功描述
     */
    String SUCCESS_MSG = "success";
    
    /**
     * 失败状态码
     */
    int FAIL_CODE = 0;
    
    /**
     * 失败描述
     */
    String FAIL_MSG = "fail";
    
    /**
     * 资产存在状态
     */
    int ASSETNO_CODE = 88;
    
    int METER_EIMSI = 36;
    
    /**
     * 条码存在状态
     */
    int BARCODE_CODE = 77;
    
    /**
     * 数据同步失败
     */
    int DATA_CODE = 55;
    
    /**
     *  写入数据库失败
     */
    int DB_CODE = 66;
    
    /**
     * GPRS电表
     */
    String METERTYPE_CODE = "40";
    
    /**
     * 设备在储位中数量超容
     */
    int OUT_FAIL_CODE = 100;
    
    /**
     * 台区关联用户
     */
    int USER_CODE = 101;
    
    /**
     * 资产编号为空
     */
    int ASSET_NO_ISEMPTY = 102;
    
    /**
     * 资产编号重复
     */
    int ASSET_NO_ISREPEAT = 103;
    
    /**
     * 条形码为空
     */
    int BAR_CODE_ISEMPTY = 104;
    
    /**
     * 条形码重复
     */
    int BAR_CODE_ISREPEAT = 105;
    
    /**
     *  启动流程未成功
     */
    int START_APP_WORK = 1010;
    
    /**
     * 资产编号格式不正确
     */
    int ASSET_NO_FORMAT = 106;
    
    /**
     * 条形码格式不正确
     */
    int BAR_CODE_FORMAT = 107;
    
    /**
     * 建档最大数量
     */
    int FILING_MAX_NUM = 109;
    
    String STRING_00 = "00";
    
    String STRING_01 = "01";
    
    String STRING_02 = "02";
    
    String STRING_03 = "03";
    
    String STRING_04 = "04";
    
    String STRING_05 = "05";
    
    String STRING_06 = "06";
    
    String STRING_0 = "0";
    
    String STRING_1 = "1";
    
    String STRING_2 = "2";
    
    String STRING_3 = "3";
    
    String STRING_4 = "4";
    
    /**
     * AMI电表标识
     */
    String AMI_TYPE_CODE = "01";
    
    /**
     * 非AMI电表标识
     */
    String NON_AMI_TYPE_CODE = "02";
    
    /**
     * 建档数据同步 开
     */
    String DATA_SYNCHR = "1";
    
    /**
     * 数据同步成功
     */
    String DATA_SYNCHR_SUCCESS = "0";
    
    /**
     * 数据同步失败
     */
    String DATA_SYNCHR_FAIL = "1";
    
    /**
     * 封印状态 : 在用
     */
    String DSEAL_USED = "03";
    
    /**
     * 封印状态 : 待销
     */
    String DSEAL_DESTORY = "04";
    
    /**
     * 设备类型: 电能表
     */
    String DEVICE_TYPE_METER = "01";
    
    /**
     * 设备类型: 接线端子
     */
    String DEVICE_TYPE_JIEXIANDUANZI = "02";
    
    /**
     * 
     */
    String SEAL_LOCFLAG_ONE = "1";
    
    /**
     * 
     */
    String SEAL_LOCFLAG_TWO = "2";
    
    /**
     * 电表状态：待校验 003
     */
    String METER_STATUS_DAIJIAOYAN = "003";
    
    /**
     * 电表状态：待入库 004
     */
    String METER_STATUS_DAIRUKU = "004";
    
    /**
     * 电表状态：待出库 005
     */
    String METER_STATUS_DAICHUKU = "005";
    
    /**
     * 电表状态：合格在库 006
     */
    String METER_STATUS_HEGEZAIKU = "006";
    
    /**
     * 电表状态：待报废 009
     */
    String METER_STATUS_DAIBAOFEI = "009";
    
    /**
     * 电表状态：丢失 010
     */
    String METER_STATUS_DIUSHI = "010";
    
    /**
     * 电表状态：领出待装 011
     */
    String METER_STATUS_LINGCHUDAIZHUANG = "011";
    
    /**
     * 电表状态：运行 012
     */
    String METER_STATUS_YUNXING = "012";
    
    /**
     * 电表状态：已报废 014
     */
    String METER_STATUS_YIBAOFEI = "014";
    
    /**
     * 电表状态：预配待领 016
     */
    String METER_STATUS_YUPEIDAILING = "016";
    
    /**
     * 不存在UMS
     */
    String UMS_NOTEXIST = "1";
    
    /**
     * 存在UMS
     */
    String UMS_EXIST = "0";
    
    /**
     * 判断是否存在UMS
     */
    String UMS_EXIST_KEY = "Interface_HAS_UMS";
    
    /**
     * 电网对象类型：变压器
     */
    String GRIDTYPE_GTRANS = "gtrans";
    
    /**
     * 电网对象类型：台区
     */
    String GRIDTYPE_TG = "tg";
    
    /**
     * 电网对象类型：线路
     */
    String GRIDTYPE_LINE = "line";
    
    /**
     * 电网对象类型：联络线
     */
    String GRIDTYPE_TLINE = "tline";
    
    /**
     * 电网对象类型：母线
     */
    String GRIDTYPE_MLINE = "mline";
    
    /**
     * 电网对象类型：主变
     */
    String GRIDTYPE_MTRAN = "mtran";
    
    /**
     * 电网对象类型：变电站
     */
    String GRIDTYPE_SUBS = "subs";
    
    /**
     * MDM电网树前缀key-供电单位
     */
    String MDM_TREE_ORG_PREKEY = "MDM_TREE_ORGANIZATION";
    
    /**
     * MDM电网树前缀key-变电站
     */
    String MDM_TREE_SUBS_PREKEY = "MDM_TREE_SUBS";
    
    /**
     * MDM电网树前缀key-主变
     */
    String MDM_TREE_MTRAN_PREKEY = "MDM_TREE_MTRAN";
    
    /**
     * MDM电网树前缀key-母线
     */
    String MDM_TREE_MLINE_PREKEY = "MDM_TREE_MLINE";
    
    /**
     * MDM电网树前缀key-联络线
     */
    String MDM_TREE_TLINE_PREKEY = "MDM_TREE_TLINE";
    
    /**
     * MDM电网树前缀key-线路
     */
    String MDM_TREE_LINE_PREKEY = "MDM_TREE_LINE";
    
    /**
     * MDM电网树前缀key-台区
     */
    String MDM_TREE_TG_PREKEY = "MDM_TREE_TG";
    
    /**
     * MDM电网树前缀key-变压器
     */
    String MDM_TREE_GTRANS_PREKEY = "MDM_TREE_GTRANS";
    
    /**
     *  电能表建档
     */
    String METER_FILING = "301";
    
    String DLC_FILING = "341";
    
    String CCTRAN_FILING = "311";
    
    String CVTRAN_FILING = "321";
    
    String COMTRAN_FILING = "331";
    
    String DLC_DISTARD_PROCESS = "313";
    
    String ASSET_MISS_PROCESS = "314";
    
    String ASSET_DISTRIBUTION_PROCESS = "315";
    
    String METER_CHECK_PROCESS = "401";
    
    String IT_CHECK_PROCESS = "501";
    
    String IN_WH_FILING = "20";
    
    String IN_WH_CHECK = "26";
    
    String IN_WH_DISTRIBUTION = "08";
    
    String IN_WH_DISTRIBUTION_BACK = "07";
    
    String OUT_WH_CHECK = "27";
    
    String OUT_WH_DISTRIBUTION = "10";
    
    String OUT_WH_DISTARD = "17";
    
    String ASSET_MISS = "25";
    
    String OUT_WH_INSTALL = "21";
    
    /**
     * 入参为空状态码
     */
    int PARAM_NULL_CODE = 10001;
    
    /**
     * 入参为空描述
     */
    String PARAM_NULL_MSG = "Param is null!";
    
    /**
     * orgNo为空状态码
     */
    int ORGNO_NULL_CODE = 10002;
    
    /**
     * orgNo为空描述
     */
    String ORGNO_NULL_MSG = "OrgNo is null!";
    
    /**
     * 前置机不存在状态码
     */
    int FRONT_NULL_CODE = 10003;
    
    /**
     * 前置机不存在描述
     */
    String FRONT_NULL_MSG = "FrontMachine not exist!";
    
    /**
     * 批量操作orgNo不同状态码
     */
    int ORGNO_DIFF_CODE = 10004;
    
    /**
     * 批量操作orgNo不同状描述
     */
    String ORGNO_DIFF_MSG = "This batch of data contains different orgNo!";
    
    /**
     * 未知错误
     */
    int UNKONOW_CODE = 10005;
    
    /**
     * 未知错误
     */
    String UNKONOW_MSG = "Unkonow message!";
}
