package com.vms.constant;

public class CommonConstants
{
    public static final String STRING_00 = "00";
    
    /**
     * 成功状态码
     */
    public static final int SUCCESS_CODE = 1;
}
