package com.vms.activiti.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vms.activiti.entity.act.ProcessType;
import com.vms.activiti.mapper.ProcessTypeMapper;
import com.vms.activiti.service.ProcessTypeService;

@Service
@Transactional
public class ProcessTypeServiceImpl implements ProcessTypeService
{
    @Autowired
    private ProcessTypeMapper processTypeMapper;
    
    @Override
    public ProcessType queryProcessTypeById(String id)
    {
        return processTypeMapper.queryProcessTypeById(id);
    }
    
    @Override
    public String analyseEditContent(ProcessType oldProcessType, ProcessType newProcessType)
    {
        // TODO Auto-generated method stub
        return null;
    }
    
    @Override
    public ProcessType queryProcessTypeByName(String processName)
    {
        return processTypeMapper.queryProcessTypeByName(processName);
    }
    
    @Override
    public int editProcessType(ProcessType processType)
    {
        return processTypeMapper.editProcessType(processType);
    }
    
    @Override
    public int insertProcessType(ProcessType processType)
    {
        return processTypeMapper.insertProcessType(processType);
    }
    
    @Override
    public List<ProcessType> queryAllProcessType()
    {
        return processTypeMapper.queryAllProcessType();
    }
    
}
