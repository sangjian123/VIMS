package com.vms.activiti.mapper;

import java.util.List;
import java.util.Map;

import com.vms.activiti.entity.act.ProcessDefinition;
import com.vms.activiti.entity.act.ProcessInstance;
import com.vms.activiti.model.ApplicationInfo;
import com.vms.activiti.model.WorkFlow;
import com.vms.model.Page;

public interface activitiFlowMapper
{
    
    /**
     * 修改用户
     *
     * @param user
     * @return
     */
    int updateIdBySapp(Long id, Long appid);
    
    WorkFlow queryFlowUser(String processInstance);
    
    ApplicationInfo queryAppidByBusinessKey(String businessKey);
    
    int updateAssigneeById(String id, String name);
    
    List<String> queryFlowKey();
    
    ApplicationInfo queryAppidByBusinessKeyQe(WorkFlow workFlowQe);
    
    WorkFlow queryFlowUserQe(WorkFlow workFlowQe);
    
    List<WorkFlow> queryProcessNameByPage();
    
    List<WorkFlow> queryStepName(WorkFlow workFlow);
    
    List<ProcessDefinition> processManageList(Page<ProcessDefinition> page);
    
    List<ProcessInstance> processInstanceList(Page<ProcessInstance> page);
    
    /**
     * 修改任务状态
     *
     * @param appId
     * @param status
     * @return
     */
    int updateTaskStatus(Long appId, String status);
    
    /**
     * 查询申请信息
     * @param appId
     * @return
     */
    ApplicationInfo queryAppInfoByAppId(Long appId);
    
    /**
     * 查看是否收取业务费
     * @param appId
     * @return
     */
    String queryBusiFeeStatus(Long appId);
    
    /**
     * 查看是否收取保证金
     * @param appId
     * @return
     */
    List<Map<String, Object>> queryDepositStatus(Long appId);
    
    /**
     * 查询是否装表
     * @param appId
     * @return
     */
    String queryMeterInstallStatus(Long appId);
    
    /**
     * 查询是否拆除电表
     * @param appId
     * @return
     */
    String queryMeterRemoveStatus(Long appId);
    
    /**
     * 查询是否生成账单
     * @param appId
     * @return
     */
    String queryBillStatus(Long appId);
    
    void delSApp(String appId);
}