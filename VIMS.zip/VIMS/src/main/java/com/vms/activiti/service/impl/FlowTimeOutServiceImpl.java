package com.vms.activiti.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.vms.activiti.model.ActHiTaskinst;
import com.vms.activiti.model.ProcActTime;
import com.vms.activiti.model.RunActTime;
import com.vms.activiti.model.WorkCalendar;
import com.vms.activiti.service.FlowTimeOutService;
import com.vms.constant.Config;
import com.vms.constant.ConstantCode;
import com.vms.constant.GeneralConstant;
import com.vms.utils.DateUtils;
import com.vms.utils.UUIDUtils;

/**
 * 检验工单超时服务类
 * @author tfl
 */
@Service
public class FlowTimeOutServiceImpl implements FlowTimeOutService
{
    
    @Override
    public String checkActTimeOutStatus(List<WorkCalendar> dayList, ProcActTime actTime, ActHiTaskinst act, long dayNum,
        long spaceNum, RunActTime runActTime)
    {
        long endTime;
        if(null == actTime)
        {
            //            endTime = act.getHandleTime ().getTime () + dayNum * Config.DAY_TIME;
            Date endDay = findEndDay(dayList, act.getHandleTime(), dayNum);
            if(endDay == null)
            {
                endTime = System.currentTimeMillis() + dayNum * Config.DAY_TIME;
            }
            else
            {
                endTime =
                    DateUtils.string2Date(
                        DateUtils.formatDate(endDay) + DateUtils.formatDateTime(act.getHandleTime()).substring(10, 19),
                        GeneralConstant.DATETIME_14_COMMON).getTime();
            }
        }
        else if(ConstantCode.STRING_02.equals(actTime.getTimeType()))
        {
            endTime =
                act.getHandleTime().getTime() + (actTime.getDayNum() == null ? dayNum : actTime.getDayNum()) * Config.DAY_TIME;
        }
        else
        {
            long dayInt = actTime.getDayNum() == null ? dayNum : actTime.getDayNum();
            Date endDay = findEndDay(dayList, act.getHandleTime(), dayInt);
            if(endDay == null)
            {
                endTime = System.currentTimeMillis() + dayInt * Config.DAY_TIME;
            }
            else
            {
                endTime =
                    DateUtils.string2Date(
                        DateUtils.formatDate(endDay) + DateUtils.formatDateTime(act.getHandleTime()).substring(10, 19),
                        GeneralConstant.DATETIME_14_COMMON).getTime();
            }
        }
        runActTime.setLastCompTime(new Timestamp(endTime));
        //正常日
        if(endTime <= System.currentTimeMillis())
        {
            return ConstantCode.STRING_03;
        }
        else if(endTime <= (System.currentTimeMillis() + spaceNum * Config.DAY_TIME))
        {
            return ConstantCode.STRING_02;
        }
        return ConstantCode.STRING_01;
    }
    
    @Override
    public Date findEndDay(List<WorkCalendar> dayList, Date startTime, long dayNum)
    {
        Date rev = null;
        try
        {
            int size = dayList.size();
            WorkCalendar cal;
            long index = 0;
            long startVlue = DateUtils.string2Date(DateUtils.formatDate(startTime)).getTime();
            for(int i = 0; i < size; i++)
            {
                cal = dayList.get(i);
                
                if(cal.getWorkYmd().getTime() > startVlue && ConstantCode.STRING_01.equals(cal.getIsWork()))
                {
                    index++;
                    if(index == dayNum)
                    {
                        rev = cal.getWorkYmd();
                        break;
                    }
                }
            }
        }
        catch (Exception e)
        {
            rev = null;
        }
        return rev;
    }
    
    @Override
    public ProcActTime findActTime(List<ProcActTime> actTimeList, ActHiTaskinst act)
    {
        if(CollectionUtils.isNotEmpty(actTimeList))
        {
            for(ProcActTime at : actTimeList)
            {
                if(at.getProcName().equals(act.getPname()) && at.getTaskName().equals(act.getTaskName()))
                {
                    return at;
                }
            }
        }
        return null;
    }
    
    @Override
    public void copyProperties(ActHiTaskinst act, RunActTime msg)
    {
        msg.setProcDefId(act.getProcDefId());
        msg.setProcessInstId(act.getProcInstId());
        msg.setUserId(act.getUserId());
        msg.setTaskId(act.getTaskId());
        msg.setUpdateTime(new Timestamp(System.currentTimeMillis()));
        msg.setId(UUIDUtils.generate16Long());
    }
    
    @Override
    public List<RunActTime> filterAndGetUpList(List<RunActTime> existList, List<RunActTime> msgList, String status)
    {
        List<RunActTime> upList = new ArrayList<RunActTime>();
        if(CollectionUtils.isNotEmpty(existList))
        {
            Map<String, RunActTime> existMap = new HashMap<String, RunActTime>();
            Timestamp time = new Timestamp(System.currentTimeMillis());
            for(RunActTime r : existList)
            {
                r.setStatus(status);
                r.setUpdateTime(time);
                existMap.put(r.getTaskId(), r);
            }
            Iterator<RunActTime> iter = msgList.iterator();
            RunActTime temp;
            while(iter.hasNext())
            {
                temp = iter.next();
                if(existMap.containsKey(temp.getTaskId()))
                {
                    if(checkUpdate(existMap, temp))
                    {
                        upList.add(temp);
                    }
                    iter.remove();
                }
            }
        }
        return upList;
    }
    
    @Override
    public void filterExistList(List<RunActTime> existList, List<RunActTime> upList)
    {
        if(CollectionUtils.isNotEmpty(upList))
        {
            Set<String> existIdSet = new HashSet<String>();
            for(RunActTime r : upList)
            {
                existIdSet.add(r.getTaskId());
            }
            Iterator<RunActTime> iter = existList.iterator();
            RunActTime temp;
            while(iter.hasNext())
            {
                temp = iter.next();
                if(existIdSet.contains(temp.getTaskId()))
                {
                    iter.remove();
                }
            }
            
            existIdSet.clear();
        }
    }
    
    @Override
    public boolean checkUpdate(Map<String, RunActTime> existMap, RunActTime temp)
    {
        boolean revFlag = false;
        RunActTime old = existMap.get(temp.getTaskId());
        if(!old.getTaskStatus().equals(temp.getTaskStatus())
            || Math.abs(old.getLastCompTime().getTime() - temp.getLastCompTime().getTime()) > 10000)
        {
            revFlag = true;
        }
        return revFlag;
    }
}
