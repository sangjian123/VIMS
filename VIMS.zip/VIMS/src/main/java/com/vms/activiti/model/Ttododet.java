package com.vms.activiti.model;

import java.io.Serializable;

public class Ttododet implements Serializable
{
    /**
     *   代办事项明细ＩＤ 
     */
    private String id;
    
    /**
     * 代办事项ID 
     */
    private String todoId;
    
    /**
     * 设备ID 
     */
    private String equipId;
    
    private String ids;
    
    /**
     *  设备类别
     */
    private String equipType;
    
    /**
     * 人员编号
     */
    private String employeeNo;
    
    private String employeeName;
    
    /**
     * DOSTATUS 代办事项状态
     */
    private String doStatus;
    
    /**
     *  环节名称 
     */
    private String status;
    
    /**
     *  设备状态
     */
    private String doFlag;
    
    private String orgNo;
    
    private String createDate;
    
    private String reason;
    
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getTodoId()
    {
        return todoId;
    }
    
    public void setTodoId(String todoId)
    {
        this.todoId = todoId;
    }
    
    public String getEquipId()
    {
        return equipId;
    }
    
    public void setEquipId(String equipId)
    {
        this.equipId = equipId;
    }
    
    public String getEquipType()
    {
        return equipType;
    }
    
    public void setEquipType(String equipType)
    {
        this.equipType = equipType;
    }
    
    public String getEmployeeNo()
    {
        return employeeNo;
    }
    
    public void setEmployeeNo(String employeeNo)
    {
        this.employeeNo = employeeNo;
    }
    
    public String getEmployeeName()
    {
        return employeeName;
    }
    
    public void setEmployeeName(String employeeName)
    {
        this.employeeName = employeeName;
    }
    
    public String getDoStatus()
    {
        return doStatus;
    }
    
    public void setDoStatus(String doStatus)
    {
        this.doStatus = doStatus;
    }
    
    public String getStatus()
    {
        return status;
    }
    
    public void setStatus(String status)
    {
        this.status = status;
    }
    
    public String getDoFlag()
    {
        return doFlag;
    }
    
    public void setDoFlag(String doFlag)
    {
        this.doFlag = doFlag;
    }
    
    public String getIds()
    {
        return ids;
    }
    
    public void setIds(String ids)
    {
        this.ids = ids;
    }
    
    public String getOrgNo()
    {
        return orgNo;
    }
    
    public void setOrgNo(String orgNo)
    {
        this.orgNo = orgNo;
    }
    
    public String getCreateDate()
    {
        return createDate;
    }
    
    public void setCreateDate(String createDate)
    {
        this.createDate = createDate;
    }
    
    public String getReason()
    {
        return reason;
    }
    
    public void setReason(String reason)
    {
        this.reason = reason;
    }
    
}
