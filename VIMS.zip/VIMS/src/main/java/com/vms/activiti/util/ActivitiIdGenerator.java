package com.vms.activiti.util;

import org.activiti.engine.impl.cfg.IdGenerator;

import com.vms.utils.UUIDUtils;

public class ActivitiIdGenerator implements IdGenerator
{
    
    @Override
    public String getNextId()
    {
        return UUIDUtils.generate19Str();
    }
}
