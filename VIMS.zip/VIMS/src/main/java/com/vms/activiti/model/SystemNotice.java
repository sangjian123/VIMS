/*
 * <p>Title: 运管系统</p>
 * <p>Description: 运管系统</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: 江苏方天电力技术有限公司</p>
 */
package com.vms.activiti.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * SystemNotice  系统公告
 * @author codegen
 * @version 1.0
 */
public class SystemNotice implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Long id;
    
    private String msgTitle;
    
    private String msgText;
    
    private String msgAlive;
    
    private String msgPublish;
    
    private String msgPublishName;
    
    private String msgPublishOrg;
    
    private String msgType;
    
    private String msgTypeFmt;
    
    private Timestamp createTime;
    
    @JsonFormat (pattern = "yyyy-MM-dd HH:mm:ss")
    private Date publishTime;
    
    private Date expireTime;
    
    private String docuName;
    
    private String fileName;
    
    private Date createTimeStart;
    
    private Date createTimeEnd;
    
    private Date publishTimeStart;
    
    private Date publishTimeEnd;
    
    private String orgNos;
    
    public Long getId()
    {
        return id;
    }
    
    public void setId(Long id)
    {
        this.id = id;
    }
    
    public String getMsgTitle()
    {
        return msgTitle;
    }
    
    public void setMsgTitle(String msgTitle)
    {
        this.msgTitle = msgTitle;
    }
    
    public String getMsgText()
    {
        return msgText;
    }
    
    public void setMsgText(String msgText)
    {
        this.msgText = msgText;
    }
    
    public String getMsgAlive()
    {
        return msgAlive;
    }
    
    public void setMsgAlive(String msgAlive)
    {
        this.msgAlive = msgAlive;
    }
    
    public String getMsgPublish()
    {
        return msgPublish;
    }
    
    public void setMsgPublish(String msgPublish)
    {
        this.msgPublish = msgPublish;
    }
    
    /**
     * @return
     */
    public Timestamp getCreateTime()
    {
        if(createTime == null)
        {
            return null;
        }
        return (Timestamp) createTime.clone();
    }
    
    /**
     * @param createTime
     *            the createTime to set
     */
    public void setCreateTime(Timestamp createTime)
    {
        if(createTime == null)
        {
            this.createTime = null;
        }
        else
        {
            this.createTime = (Timestamp) createTime.clone();
        }
    }
    
    public String getMsgPublishOrg()
    {
        return msgPublishOrg;
    }
    
    public void setMsgPublishOrg(String msgPublishOrg)
    {
        this.msgPublishOrg = msgPublishOrg;
    }
    
    public String getMsgType()
    {
        return msgType;
    }
    
    public void setMsgType(String msgType)
    {
        this.msgType = msgType;
    }
    
    public Date getExpireTime()
    {
        return expireTime;
    }
    
    public void setExpireTime(Date expireTime)
    {
        this.expireTime = expireTime;
    }
    
    public Date getCreateTimeStart()
    {
        return createTimeStart;
    }
    
    public void setCreateTimeStart(Date createTimeStart)
    {
        this.createTimeStart = createTimeStart;
    }
    
    public Date getCreateTimeEnd()
    {
        return createTimeEnd;
    }
    
    public void setCreateTimeEnd(Date createTimeEnd)
    {
        this.createTimeEnd = createTimeEnd;
    }
    
    public Date getPublishTimeStart()
    {
        return publishTimeStart;
    }
    
    public void setPublishTimeStart(Date publishTimeStart)
    {
        this.publishTimeStart = publishTimeStart;
    }
    
    public Date getPublishTimeEnd()
    {
        return publishTimeEnd;
    }
    
    public void setPublishTimeEnd(Date publishTimeEnd)
    {
        this.publishTimeEnd = publishTimeEnd;
    }
    
    public String getOrgNos()
    {
        return orgNos;
    }
    
    public void setOrgNos(String orgNos)
    {
        this.orgNos = orgNos;
    }
    
    public String getMsgPublishName()
    {
        return msgPublishName;
    }
    
    public void setMsgPublishName(String msgPublishName)
    {
        this.msgPublishName = msgPublishName;
    }
    
    public Date getPublishTime()
    {
        return publishTime;
    }
    
    public void setPublishTime(Date publishTime)
    {
        this.publishTime = publishTime;
    }
    
    public String getDocuName()
    {
        return docuName;
    }
    
    public void setDocuName(String docuName)
    {
        this.docuName = docuName;
    }
    
    public String getFileName()
    {
        return fileName;
    }
    
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    
    public String getMsgTypeFmt()
    {
        return msgTypeFmt;
    }
    
    public void setMsgTypeFmt(String msgTypeFmt)
    {
        this.msgTypeFmt = msgTypeFmt;
    }
}
