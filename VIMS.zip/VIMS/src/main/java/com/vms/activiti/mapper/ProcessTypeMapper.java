package com.vms.activiti.mapper;

import java.util.List;

import com.vms.activiti.entity.act.ProcessType;
import com.vms.model.Page;

public interface ProcessTypeMapper
{
    /**
     * 获取流程类型
     * 
     * @param page
     * @return
     */
    List<ProcessType> queryProcessTypeByPage(Page<ProcessType> page);
    
    /**
     * 新增流程类型
     * 
     * @param processType
     * @return
     */
    int insertProcessType(ProcessType processType);
    
    /**
     * 修改流程类型
     * 
     * @param processType
     * @return
     */
    int editProcessType(ProcessType processType);
    
    ProcessType queryProcessTypeById(String id);
    
    ProcessType queryProcessTypeByName(String processName);
    
    /**
     * 获取所有流程类型
     * 
     * @return
     */
    List<ProcessType> queryAllProcessType();
    
}
