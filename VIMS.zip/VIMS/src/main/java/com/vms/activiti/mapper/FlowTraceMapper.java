package com.vms.activiti.mapper;

import java.util.Map;

public interface FlowTraceMapper
{
    
    /**
     * 查询运行中流程的Id标识
     *
     * @param businessKey
     * @return
     */
    Map<String, String> queryRunFlowIds(String businessKey);
    
    /**
     * 查询历史流程的Id标识
     *
     * @param businessKey
     * @return
     */
    Map<String, String> queryHiFlowIds(String businessKey);
}