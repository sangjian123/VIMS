package com.vms.activiti.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.dubbo.config.annotation.Service;
import com.vms.activiti.mapper.ActHiTaskinstMapper;
import com.vms.activiti.mapper.HomeMapper;
import com.vms.activiti.mapper.ProcActTimeMapper;
import com.vms.activiti.mapper.WorkCalendarMapper;
import com.vms.activiti.model.ActCheckDesc;
import com.vms.activiti.model.ActHiTaskinst;
import com.vms.activiti.model.ProcActTime;
import com.vms.activiti.model.RunActTime;
import com.vms.activiti.model.WorkCalendar;
import com.vms.activiti.service.ActHiTaskinstService;
import com.vms.activiti.service.FlowTimeOutService;
import com.vms.constant.Config;
import com.vms.model.Page;
import com.vms.thread.CheckFlowTimeOutThread;
import com.vms.utils.ConfigHolder;
import com.vms.utils.FlowTypeUtils;
import com.vms.utils.ServiceException;
import com.vms.utils.UUIDUtils;

/*chang
 * @version v1.0
 */
@Service
@Component ("actHiTaskinstService")
public class ActHiTaskinstServiceImpl implements ActHiTaskinstService
{
    protected Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    private FlowTimeOutService flowTimeOutService;
    
    @Autowired
    private ActHiTaskinstMapper actHiTaskinstMapper;
    
    @Autowired
    private ProcActTimeMapper procActTimeMapper;
    
    @Autowired
    private WorkCalendarMapper workCalendarMapper;
    
    @Autowired
    private HomeMapper homeMapper;
    
    private static Map<String, Map<String, String>> pnameMap = new HashMap<>();
    
    static
    {
        //低压居民新装
        Map<String, String> ResidentInstallationStep = new HashMap<>();
        ResidentInstallationStep.put("Site investigation and Install meter", "01");
        ResidentInstallationStep.put("Business Fees", "06");
        ResidentInstallationStep.put("QA audit", "08");
        ResidentInstallationStep.put("Business filing", "09");
        ResidentInstallationStep.put("Archiving", "09");
        
        pnameMap.put("ResidentInstallation", ResidentInstallationStep);
        
        //非居民新装
        Map<String, String> LVNonresidentInstallationStep = new HashMap<>();
        LVNonresidentInstallationStep.put("Site investigation", "01");
        LVNonresidentInstallationStep.put("Business Fees", "06");
        LVNonresidentInstallationStep.put("Install meter and Power on", "02");
        LVNonresidentInstallationStep.put("Business filing", "09");
        LVNonresidentInstallationStep.put("Archiving", "09");
        
        pnameMap.put("LVNon-residentInstallation", LVNonresidentInstallationStep);
        
        //高压新装
        Map<String, String> HVInstallationStep = new HashMap<>();
        HVInstallationStep.put("Site investigation", "01");
        HVInstallationStep.put("Business Fees", "06");
        HVInstallationStep.put("Install meter and Power on", "02");
        HVInstallationStep.put("Business filing", "09");
        HVInstallationStep.put("Archiving", "09");
        
        pnameMap.put("HVInstallation", HVInstallationStep);
        
        //过户
        Map<String, String> AccountTransferStep = new HashMap<>();
        AccountTransferStep.put("Expense clearing", "07");
        AccountTransferStep.put("Business filing", "09");
        AccountTransferStep.put("Archiving", "09");
        
        pnameMap.put("AccountTransfer", AccountTransferStep);
        
        //销户
        Map<String, String> AccountDeactivationStep = new HashMap<>();
        AccountDeactivationStep.put("Expense clearing", "07");
        //旧归档翻译
        AccountDeactivationStep.put("Business filing", "09");
        //新归档翻译
        AccountDeactivationStep.put("Archiving", "09");
        
        pnameMap.put("AccountDeactivation", AccountDeactivationStep);
        
        //容量变更
        Map<String, String> CapacityChangeStep = new HashMap<>();
        CapacityChangeStep.put("Site investigation", "01");
        CapacityChangeStep.put("Business Fees", "06");
        CapacityChangeStep.put("Install/Remove meter", "02");
        CapacityChangeStep.put("Expense clearing", "07");
        CapacityChangeStep.put("Business filing", "09");
        CapacityChangeStep.put("Archiving", "09");
        pnameMap.put("CapacityChange", CapacityChangeStep);
        
        //改类
        Map<String, String> CategoryChangeStep = new HashMap<>();
        CategoryChangeStep.put("Site investigation", "01");
        CategoryChangeStep.put("Install/Remove meter", "02");
        CategoryChangeStep.put("Expense clearing", "07");
        CategoryChangeStep.put("Business filing", "09");
        CategoryChangeStep.put("Archiving", "09");
        pnameMap.put("CategoryChange", CategoryChangeStep);
        
        //故障报修
        Map<String, String> FaultRepairStep = new HashMap<>();
        AccountDeactivationStep.put("Fault Handling", "04");
        //        AccountDeactivationStep.put ("Return Visit", "");
        
        pnameMap.put("Fault Repair", FaultRepairStep);
        
        // APP 新装审核
        Map<String, String> appInstallStep = new HashMap<>();
        appInstallStep.put("Business filing", "08");
        // APP DCU
        pnameMap.put("AppDCUInstall", appInstallStep);
        // APP DCC
        pnameMap.put("AppDCCInstall", appInstallStep);
        // APP 关口表
        pnameMap.put("AppGatewayMeterInstall", appInstallStep);
        // APP 无EPMS新装
        pnameMap.put("AppMeterInstall", appInstallStep);
    }
    
    public Page<ActHiTaskinst> findgActHiTaskinstByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findgActHiTaskinstByPage(page);
            }
            else
            {
                list = actHiTaskinstMapper.findFileByPage(page);
            }
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException(
                "actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception", e);
        }
        
        //工单查询 增加 工单流向部门查询
        ActHiTaskinst ac = null;
        if(null != list && !list.isEmpty())
        {
            for(int i = 0; i < list.size(); i++)
            {
                ac = list.get(i);
                
                if(StringUtils.isNotEmpty(ac.getAssignee()))
                {
                    
                    //1.根据用户名查询部门
                    ac.setDept(actHiTaskinstMapper.getUserDeptByLoginName(ac.getLoginName()));
                }
                else
                {
                    //2.根据 appNo 查询地址  根据地址和tasktype 获取deptid
                    if(StringUtils.isNotEmpty(ac.getPname()))
                    {
                        if(pnameMap.containsKey(ac.getPname()))
                        {
                            Map<String, Object> pMap = new HashMap<>();
                            String taskType = pnameMap.get(ac.getPname()).get(ac.getTaskName());
                            pMap.put("taskType", taskType);
                            pMap.put("appNo", ac.getAppNo());
                            String dept = actHiTaskinstMapper.getUserDeptByTaskTypeAndAppNo(pMap);
                            ac.setDept(dept);
                        }
                        else
                        {
                            ac.setDept("Null");
                        }
                    }
                }
            }
        }
        
        page.setResults(list);
        return page;
    }
    
    public Page<ActHiTaskinst> findWaitHandleByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findWaitHandlesByPage(page);
                if(!CollectionUtils.isEmpty(list))
                {
                    for(ActHiTaskinst act : list)
                    {
                        if(act.getGroupId() != null && "1".equals(act.getRev()))
                        {
                            act.setRev("2");
                        }
                    }
                }
            }
            else
            {
                list = actHiTaskinstMapper.findFileByPage(page);
            }
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException(
                "actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception", e);
        }
        page.setResults(list);
        return page;
    }
    
    public Page<ActHiTaskinst> findGridHandleByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findGridHandleByPage(page);
                if(!CollectionUtils.isEmpty(list))
                {
                    for(ActHiTaskinst act : list)
                    {
                        if(act.getGroupId() != null && "1".equals(act.getRev()))
                        {
                            act.setRev("2");
                        }
                    }
                }
            }
            else
            {
                list = actHiTaskinstMapper.findFileByPage(page);
            }
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException(
                "actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception", e);
        }
        page.setResults(list);
        return page;
    }
    
    public Page<ActHiTaskinst> findgActHiTaskinstTop5ByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(page.getParams().getApplyState().equals("1"))
            {
                //                list = actHiTaskinstMapper.findTop5 (page);
                list = actHiTaskinstMapper.findGridHandleByPage(page);
                
            }
            else
            {
                list = actHiTaskinstMapper.findTop5File(page);
            }
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException(
                "actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception", e);
        }
        page.setResults(list);
        return page;
    }
    
    @Override
    public Page<ActHiTaskinst> findTaskinstByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstMapper.findTaskinstByPage(page);
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage Error:   " + e);
            throw new ServiceException(
                "actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstByPage SQL Exception", e);
        }
        page.setResults(list);
        return page;
    }
    
    @Override
    public List<ActHiTaskinst> quaryPnameByPage()
    {
        List<ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstMapper.quaryPnameByPage();
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | quaryPnameByPage Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | quaryPnameByPage SQL Exception", e);
        }
        return list;
    }
    
    @Override
    public List<ActHiTaskinst> quaryName(ActHiTaskinst actHiTaskinst)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstMapper.quaryFlowVersion(actHiTaskinst);
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | quaryName Error:   " + e);
            throw new ServiceException("actHiTaskinstService | actHiTaskinstServiceImpl | quaryName SQL Exception", e);
        }
        return list;
    }
    
    @Override
    public Integer findTaskCount(Map<String, Object> map)
    {
        return actHiTaskinstMapper.findTaskCount(map);
    }
    
    @Override
    public Integer findTaskCountAll(Map<String, Object> map)
    {
        return actHiTaskinstMapper.findTaskCountAll(map);
    }
    
    public List<ActHiTaskinst> findgActHiTaskinstForApp(ActHiTaskinst actHiTaskinst)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            if(actHiTaskinst.getApplyState().equals("1"))
            {
                list = actHiTaskinstMapper.findgActHiTaskinstForApp(actHiTaskinst);
            }
            else
            {
                list = actHiTaskinstMapper.findFileForApp(actHiTaskinst);
            }
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstForApp Error:   " + e);
            throw new ServiceException(
                "actHiTaskinstService | actHiTaskinstServiceImpl | findgActHiTaskinstForApp SQL Exception", e);
        }
        return list;
    }
    
    public void findCompTimeByList(List<ActHiTaskinst> noTimeList)
    {
        RunActTime runActTime;
        ProcActTime actTime;
        String taskStatus;
        long dayNum = 7;
        try
        {
            dayNum = Long.valueOf(ConfigHolder.getCfg("FLOW_TIME_OUT_DAY"));
        }
        catch (NumberFormatException e)
        {
            logger.error("scanFlowTimeout get FLOW_TIME_OUT_DAY error : ", e);
            dayNum = 7;
        }
        long spaceNum = 2;
        try
        {
            spaceNum = Long.valueOf(ConfigHolder.getCfg("TASK_REMAINING_DAYS"));
        }
        catch (NumberFormatException e)
        {
            logger.error("scanFlowTimeout get TASK_REMAINING_DAYS error : ", e);
            spaceNum = 2;
        }
        long curDate = new Date().getTime();
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("startDay", new Date(curDate - Config.DAY_TIME * (dayNum + 32)));
        params.put("endDay", new Date(curDate + Config.DAY_TIME * (dayNum + 32)));
        List<WorkCalendar> dayList = workCalendarMapper.findWorkCalendarByRange(params);
        List<ProcActTime> actTimeList = procActTimeMapper.findAllProcActTime();
        List<RunActTime> runActList = new ArrayList<RunActTime>();
        List<RunActTime> existRunActList;
        List<RunActTime> updateActList;
        for(ActHiTaskinst act : noTimeList)
        {
            runActTime = new RunActTime();
            runActTime.setStatus(CheckFlowTimeOutThread.getMSG_STATUS());
            flowTimeOutService.copyProperties(act, runActTime);
            runActTime.setFlowType(FlowTypeUtils.getFlowType(act.getPname()));
            actTime = flowTimeOutService.findActTime(actTimeList, act);
            taskStatus = flowTimeOutService.checkActTimeOutStatus(dayList, actTime, act, dayNum, spaceNum, runActTime);
            runActTime.setTaskStatus(taskStatus);
            act.setLastCompTime(runActTime.getLastCompTime());
            act.setTaskStatus(taskStatus);
            runActList.add(runActTime);
        }
        
        existRunActList = homeMapper.queryRunActTimeByIds(runActList);
        if(CollectionUtils.isNotEmpty(existRunActList))
        {
            updateActList =
                flowTimeOutService.filterAndGetUpList(existRunActList, runActList, CheckFlowTimeOutThread.getMSG_STATUS());
            if(CollectionUtils.isNotEmpty(runActList))
            {
                homeMapper.insertBatchRunActTimes(runActList);
            }
            if(CollectionUtils.isNotEmpty(updateActList))
            {
                homeMapper.updateBatchRunActTime(updateActList);
                flowTimeOutService.filterExistList(existRunActList, updateActList);
                if(CollectionUtils.isNotEmpty(existRunActList))
                    homeMapper.updateBatchRunActStatus(existRunActList);
                updateActList.clear();
            }
            else
            {
                if(CollectionUtils.isNotEmpty(existRunActList))
                    homeMapper.updateBatchRunActStatus(existRunActList);
            }
        }
        else
        {
            homeMapper.insertBatchRunActTimes(runActList);
        }
        
        runActList.clear();
        existRunActList.clear();
    }
    
    @Override
    public int insertActDesc(ActCheckDesc actCheckDesc)
    {
        actCheckDesc.setId(UUIDUtils.generate16Str());
        return actHiTaskinstMapper.insertActDesc(actCheckDesc);
    }
    
    @Override
    public int findActHiTaskinstByDeptId(String deptId)
    {
        return actHiTaskinstMapper.findActHiTaskinstByDeptId(deptId);
    }
    
    @Override
    public Page<ActHiTaskinst> processedActHiTaskinstByPage(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> list = null;
        try
        {
            list = actHiTaskinstMapper.processedActHiTaskinstByPage(page);
        }
        catch (Exception e)
        {
            logger.error("actHiTaskinstService | actHiTaskinstServiceImpl | processedActHiTaskinstByPage Error:   " + e);
            throw new ServiceException(
                "actHiTaskinstService | actHiTaskinstServiceImpl | processedActHiTaskinstByPage SQL Exception", e);
        }
        
        //工单查询 增加 工单流向部门查询
        ActHiTaskinst ac = null;
        if(null != list && !list.isEmpty())
        {
            for(int i = 0; i < list.size(); i++)
            {
                ac = list.get(i);
                
                if(StringUtils.isNotEmpty(ac.getAssignee()))
                {
                    
                    //1.根据用户名查询部门
                    ac.setDept(actHiTaskinstMapper.getUserDeptByLoginName(ac.getLoginName()));
                }
                else
                {
                    //2.根据 appNo 查询地址  根据地址和tasktype 获取deptid
                    if(StringUtils.isNotEmpty(ac.getPname()))
                    {
                        if(pnameMap.containsKey(ac.getPname()))
                        {
                            Map<String, Object> pMap = new HashMap<>();
                            String taskType = pnameMap.get(ac.getPname()).get(ac.getTaskName());
                            pMap.put("taskType", taskType);
                            pMap.put("appNo", ac.getAppNo());
                            String dept = actHiTaskinstMapper.getUserDeptByTaskTypeAndAppNo(pMap);
                            ac.setDept(dept);
                        }
                        else
                        {
                            ac.setDept("Null");
                        }
                    }
                }
            }
        }
        
        page.setResults(list);
        return page;
    }
}
