package com.vms.activiti.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 申请信息实体类 S_APP
 * appTypeCode relaAppCode consNo consName psOrgNo voltCode elecAddr consSortCode   electypeCode
 * @author sunjie
 *
 */
@XmlRootElement
@JsonIgnoreProperties (ignoreUnknown = true)
public class ApplicationInfo implements Serializable
{
    
    private static final long serialVersionUID = 1L;
    
    //业务主键
    private String id;
    
    private Long appNo;
    
    private Long appId;
    
    private Long mainAppId;
    
    //后付费和预付费变更标志
    private String tmpFlag;
    
    //业务类型
    private String appTypeCode;
    
    //申请编号
    private String relaAppCode;
    
    // 受理日期
    private String handleTime;
    
    //供电单位编号
    private String psOrgNo;
    
    //供电单位 
    private String orgName;
    
    //受理部门
    private String handleDeptNo;
    
    // 申请方式
    private String appmode;
    
    //用户标识
    private Long consId;
    
    //用户编号
    private String consNo;
    
    private String custNo;
    
    //用户名称
    private String consName;
    
    private String custQueryNo;
    
    private String tmpPayRelaNo;
    
    private String orgnConsNo;
    
    private String shiftNo;
    
    private String lodeAttrCode;
    
    private String hecIndustryCode;
    
    private String holiday;
    
    private String transferCode;
    
    private String elecTypeCode;
    
    private String mrSectNo;
    
    private String orgnRunCap;
    
    private String bgnDate;
    
    private String endDate;
    
    private String shiftOutCap;
    
    private String shiftInCap;
    
    private String permenantReduceFlag;
    
    private String content;
    
    private String stUpq;
    
    private String longtermCap;
    
    private String powerUsage;
    
    private String dmdDate;
    
    private String mrdFactorCode;
    
    private String handleFlag;
    
    private String refuseReason;
    
    private String prioCode;
    
    private String infoArcDate;
    
    private Date tmpDate;
    
    private String tContractCap;
    
    private String appRunCap;
    
    private String tRunCap;
    
    private String annualGp;
    
    //用户类别
    private String consSortCode;
    
    //用电类别
    private String electypeCode;
    
    //原有容量
    private Long orgnContractCap;
    
    //合计容量
    private Long tCcontractCap;
    
    //用电地址
    private String elecAddr;
    
    //行业分类
    private String tradeCode;
    
    //增加或减少的容量
    private Double contractCap;
    
    private BigDecimal schemecontractCap;
    
    //供电电压
    private String voltCode;
    
    //电费通知方式
    private String notifyMode;
    
    //电费结算方式
    private String settleMode;
    
    //用户付费模式
    private String consPayMode;
    
    //票据类型
    private String noteTypeCode;
    
    //申请原因
    private String reason;
    
    //申请 备注
    private String remark;
    
    //客户标识
    private Long custId;
    
    private String name;//客户名称
    
    private String economyTypeCode; //经济类型  from c_cust表
    
    private String creditlevelCode; //信用价值
    
    private String valuelevelCode; //价值等级
    
    private String riskLevelCode; //风险等级
    
    private String legalPerson; //法人
    
    private String vipFlag; //VIP标志
    
    private String openScode; //经营范围
    
    private double regCapItal; //注册资金
    
    private String vipLevel; //vip等级
    
    private String salesAmt;
    
    private String brief;
    
    //负荷性质
    private String electricType;
    
    private Long chkCycle;
    
    private Date lastChkDate;
    
    private List<SappCert> certList;
    
    private List<SappContact> contactList;
    
    /*
     * 证件信息表  S_APP_CERT
     */
    private Long actId;
    
    private Long certId;
    
    //证件类型
    private String certtypeCode;
    
    //证件持有人姓名
    private String certname;
    
    //证件号码
    private String certNo;
    
    /**
     * 联系信息表 S_APP_CONTACT
     */
    private Long contactId;
    
    private Long acId;
    
    //联系人
    private String contactName;
    
    //移动电话
    private String mobIle;
    
    //办公电话
    private String officeTel;
    
    // 住宅电话 
    private String homephone;
    
    //电子邮箱
    private String email;
    
    // 邮编
    private String postalcode;
    
    //联系地址
    private String addr;
    
    //传真号码
    private String faxNo;
    
    /**
     * 行政区O_DISTRICT
     */
    //行政区 
    private String distrctNo;
    
    private UserAccount UserAccount;
    
    /**
     * S_APP_VAT
     * 申请增值税
     * 
     */
    //增值税申请标识
    private Long avatId;
    
    //增值税标识
    private Long vatId;
    
    //增值税名
    private String vatName;
    
    //增值税号
    private String vatNo;
    
    //增值税帐号
    private String vatAcct;
    
    //增值税银行
    private String bankCode;
    
    //注册地址
    private String regAddr;
    
    private String bankName;//银行名称
    
    private Long bankAcctId;
    
    private Long bankId;//唯一主键
    
    private Long headOfficeCode;//总行代码
    
    private String acctName;//账户名称
    
    private String bankAcct;//银行账号
    
    private Long payPrioCode;//优先级
    
    private String addrCode;//省市区code
    
    private String addrName;//省市区name
    
    private String codeType;
    
    private String codeName;
    
    //========用电明细地址信息
    private Long appElecAddrId;//用电地址申请标识
    
    private Long elecAddrId;//用电地址标识
    
    private String provinceCode;//省码
    
    private String cityCode;//市码
    
    private String countyCode;//区县码
    
    private String streetCode;//街道码（乡镇）
    
    private String villageCode;//居委会码（村）
    
    private String roadCode;//道路码
    
    private String communityCode;//小区码
    
    private String plateNo;//门牌号
    
    private String bailFlag;//是否收取保证金
    
    private String collectionFlag;//是否托收
    
    private String grid;//网格
    
    private String flag;//更新或新增
    
    private String codeType1;
    
    private String codeType2;
    
    private String codeType3;
    
    private String codeType4;
    
    private String codeType5;
    
    private String codeType6;
    
    //====工作流相关信息
    private String taskId;
    
    private String processId;
    
    private boolean saveFlag; //保存成功标识
    
    private int page;
    
    private int rows;
    
    private String mobile;
    
    private String certTypeCode;
    
    private String certTypeCodeName;
    
    //==业务收费相关
    private Long bcsId;//收费标准标识
    
    private String typeCode;//收费项目类型
    
    private String typeCodeFmt;
    
    private Double prc;//单价
    
    private Double rcvblAmt;//应收金额
    
    private String periodNo;//期数
    
    private String confirmEmpNo;//确认人代码
    
    private String confirmEmpName;
    
    private Date confirmDate;//确定时间
    
    private String confirmDateStr;
    
    private Date payDeadline;//本条费用缴费的最后日期,期限
    
    private String payDeadlineStr;
    
    private String calcBasisCode;//本条费用计算依据简单描述
    
    private String memo;//本条费用的其他情况说明
    
    private String psOrgName;//供电单位名称
    
    private String psAdministrativeLevel;//供电单位所属行政级别
    
    private Long rcvblId;//应收主键
    
    private Double rcvedAmt;
    
    private Double retAmt;
    
    private String statusCode;//收费状态
    
    /**
     * S_APP_ACCT
     * 申请账户
     * @return
     */
    // 申请账户标识
    private Long appAcctId;
    
    //客户基本信息申请标识
    private Long appnId;
    
    private Long acctId;//银行账户标识
    
    private Long caAcctId;//账户标识
    
    private String payMode;
    
    /***
     * S_APP_PAYMENT_RELA申请支付关系
     */
    private Long aprId;//申请支付关系标识
    
    private Long prId;//支付关系标识
    
    private Long payAgreementNo;//收费协议号
    
    private Integer start;
    
    private Integer end;
    
    private String newConsNo;//新用户编号
    
    private String newConsName;//新用户名称
    
    private Long newConsId;//新用户id
    
    private int arcflag;//是否归档 0未归档，1已归档
    
    private double depositAmt;//档案保证金，变更类流程显示用
    
    public Long getBcsId()
    {
        return bcsId;
    }
    
    public void setBcsId(Long bcsId)
    {
        this.bcsId = bcsId;
    }
    
    public String getTypeCode()
    {
        return typeCode;
    }
    
    public void setTypeCode(String typeCode)
    {
        this.typeCode = typeCode;
    }
    
    public String getTypeCodeFmt()
    {
        return typeCodeFmt;
    }
    
    public void setTypeCodeFmt(String typeCodeFmt)
    {
        this.typeCodeFmt = typeCodeFmt;
    }
    
    public Double getPrc()
    {
        return prc;
    }
    
    public void setPrc(Double prc)
    {
        this.prc = prc;
    }
    
    public Double getRcvblAmt()
    {
        return rcvblAmt;
    }
    
    public void setRcvblAmt(Double rcvblAmt)
    {
        this.rcvblAmt = rcvblAmt;
    }
    
    public String getPeriodNo()
    {
        return periodNo;
    }
    
    public void setPeriodNo(String periodNo)
    {
        this.periodNo = periodNo;
    }
    
    public String getConfirmEmpNo()
    {
        return confirmEmpNo;
    }
    
    public void setConfirmEmpNo(String confirmEmpNo)
    {
        this.confirmEmpNo = confirmEmpNo;
    }
    
    public String getConfirmEmpName()
    {
        return confirmEmpName;
    }
    
    public void setConfirmEmpName(String confirmEmpName)
    {
        this.confirmEmpName = confirmEmpName;
    }
    
    public Date getConfirmDate()
    {
        return confirmDate;
    }
    
    public void setConfirmDate(Date confirmDate)
    {
        this.confirmDate = confirmDate;
    }
    
    public String getConfirmDateStr()
    {
        return confirmDateStr;
    }
    
    public void setConfirmDateStr(String confirmDateStr)
    {
        this.confirmDateStr = confirmDateStr;
    }
    
    public Date getPayDeadline()
    {
        return payDeadline;
    }
    
    public void setPayDeadline(Date payDeadline)
    {
        this.payDeadline = payDeadline;
    }
    
    public String getPayDeadlineStr()
    {
        return payDeadlineStr;
    }
    
    public void setPayDeadlineStr(String payDeadlineStr)
    {
        this.payDeadlineStr = payDeadlineStr;
    }
    
    public String getCalcBasisCode()
    {
        return calcBasisCode;
    }
    
    public void setCalcBasisCode(String calcBasisCode)
    {
        this.calcBasisCode = calcBasisCode;
    }
    
    public String getMemo()
    {
        return memo;
    }
    
    public void setMemo(String memo)
    {
        this.memo = memo;
    }
    
    public String getPsOrgName()
    {
        return psOrgName;
    }
    
    public void setPsOrgName(String psOrgName)
    {
        this.psOrgName = psOrgName;
    }
    
    public String getPsAdministrativeLevel()
    {
        return psAdministrativeLevel;
    }
    
    public void setPsAdministrativeLevel(String psAdministrativeLevel)
    {
        this.psAdministrativeLevel = psAdministrativeLevel;
    }
    
    public Long getRcvblId()
    {
        return rcvblId;
    }
    
    public void setRcvblId(Long rcvblId)
    {
        this.rcvblId = rcvblId;
    }
    
    public Double getRcvedAmt()
    {
        return rcvedAmt;
    }
    
    public void setRcvedAmt(Double rcvedAmt)
    {
        this.rcvedAmt = rcvedAmt;
    }
    
    public Double getRetAmt()
    {
        return retAmt;
    }
    
    public void setRetAmt(Double retAmt)
    {
        this.retAmt = retAmt;
    }
    
    public String getStatusCode()
    {
        return statusCode;
    }
    
    public void setStatusCode(String statusCode)
    {
        this.statusCode = statusCode;
    }
    
    public String getCodeType()
    {
        return codeType;
    }
    
    public void setCodeType(String codeType)
    {
        this.codeType = codeType;
    }
    
    public String getCodeName()
    {
        return codeName;
    }
    
    public void setCodeName(String codeName)
    {
        this.codeName = codeName;
    }
    
    public String getAddrCode()
    {
        return addrCode;
    }
    
    public void setAddrCode(String addrCode)
    {
        this.addrCode = addrCode;
    }
    
    public String getAddrName()
    {
        return addrName;
    }
    
    public void setAddrName(String addrName)
    {
        this.addrName = addrName;
    }
    
    public Long getAvatId()
    {
        return avatId;
    }
    
    public void setAvatId(Long avatId)
    {
        this.avatId = avatId;
    }
    
    public Long getVatId()
    {
        return vatId;
    }
    
    public void setVatId(Long vatId)
    {
        this.vatId = vatId;
    }
    
    public String getVatName()
    {
        return vatName;
    }
    
    public void setVatName(String vatName)
    {
        this.vatName = vatName;
    }
    
    public String getVatNo()
    {
        return vatNo;
    }
    
    public void setVatNo(String vatNo)
    {
        this.vatNo = vatNo;
    }
    
    public String getVatAcct()
    {
        return vatAcct;
    }
    
    public void setVatAcct(String vatAcct)
    {
        this.vatAcct = vatAcct;
    }
    
    public String getBankCode()
    {
        return bankCode;
    }
    
    public void setBankCode(String bankCode)
    {
        this.bankCode = bankCode;
    }
    
    public String getRegAddr()
    {
        return regAddr;
    }
    
    public void setRegAddr(String regAddr)
    {
        this.regAddr = regAddr;
    }
    
    public Long getAprId()
    {
        return aprId;
    }
    
    public void setAprId(Long aprId)
    {
        this.aprId = aprId;
    }
    
    public Long getPrId()
    {
        return prId;
    }
    
    public void setPrId(Long prId)
    {
        this.prId = prId;
    }
    
    public Long getPayAgreementNo()
    {
        return payAgreementNo;
    }
    
    public void setPayAgreementNo(Long payAgreementNo)
    {
        this.payAgreementNo = payAgreementNo;
    }
    
    public Long getAppAcctId()
    {
        return appAcctId;
    }
    
    public void setAppAcctId(Long appAcctId)
    {
        this.appAcctId = appAcctId;
    }
    
    public Long getAppnId()
    {
        return appnId;
    }
    
    public void setAppnId(Long appnId)
    {
        this.appnId = appnId;
    }
    
    public Long getAcctId()
    {
        return acctId;
    }
    
    public void setAcctId(Long acctId)
    {
        this.acctId = acctId;
    }
    
    public String getPayMode()
    {
        return payMode;
    }
    
    public void setPayMode(String payMode)
    {
        this.payMode = payMode;
    }
    
    public String getConsSortCode()
    {
        return consSortCode;
    }
    
    public void setConsSortCode(String consSortCode)
    {
        this.consSortCode = consSortCode;
    }
    
    public Long getConsId()
    {
        return consId;
    }
    
    public void setConsId(Long consId)
    {
        this.consId = consId;
    }
    
    public Long getAppNo()
    {
        return appNo;
    }
    
    public void setAppNo(Long appNo)
    {
        this.appNo = appNo;
    }
    
    public Long getContactId()
    {
        return contactId;
    }
    
    public void setContactId(Long contactId)
    {
        this.contactId = contactId;
    }
    
    public Long getActId()
    {
        return actId;
    }
    
    public void setActId(Long actId)
    {
        this.actId = actId;
    }
    
    public Long getCertId()
    {
        return certId;
    }
    
    public void setCertId(Long certId)
    {
        this.certId = certId;
    }
    
    public Long getAppId()
    {
        return appId;
    }
    
    public void setAppId(Long appId)
    {
        this.appId = appId;
    }
    
    public Long getAcId()
    {
        return acId;
    }
    
    public void setAcId(Long acId)
    {
        this.acId = acId;
    }
    
    public UserAccount getUserAccount()
    {
        return UserAccount;
    }
    
    public void setUserAccount(UserAccount userAccount)
    {
        UserAccount = userAccount;
    }
    
    public String getReason()
    {
        return reason;
    }
    
    public void setReason(String reason)
    {
        this.reason = reason;
    }
    
    public String getAppTypeCode()
    {
        return appTypeCode;
    }
    
    public void setAppTypeCode(String appTypeCode)
    {
        this.appTypeCode = appTypeCode;
    }
    
    public String getRelaAppCode()
    {
        return relaAppCode;
    }
    
    public void setRelaAppCode(String relaAppCode)
    {
        this.relaAppCode = relaAppCode;
    }
    
    public String getHandleTime()
    {
        return handleTime;
    }
    
    public void setHandleTime(String handleTime)
    {
        this.handleTime = handleTime;
    }
    
    public String getPsOrgNo()
    {
        return psOrgNo;
    }
    
    public void setPsOrgNo(String psOrgNo)
    {
        this.psOrgNo = psOrgNo;
    }
    
    public String getAppmode()
    {
        return appmode;
    }
    
    public void setAppmode(String appmode)
    {
        this.appmode = appmode;
    }
    
    public String getConsNo()
    {
        return consNo;
    }
    
    public void setConsNo(String consNo)
    {
        this.consNo = consNo;
    }
    
    public String getConsName()
    {
        return consName;
    }
    
    public void setConsName(String consName)
    {
        this.consName = consName;
    }
    
    public String getElectypeCode()
    {
        return electypeCode;
    }
    
    public void setElectypeCode(String electypeCode)
    {
        this.electypeCode = electypeCode;
    }
    
    public String getElecAddr()
    {
        return elecAddr;
    }
    
    public void setElecAddr(String elecAddr)
    {
        this.elecAddr = elecAddr;
    }
    
    public String getTradeCode()
    {
        return tradeCode;
    }
    
    public void setTradeCode(String tradeCode)
    {
        this.tradeCode = tradeCode;
    }
    
    public Double getContractCap()
    {
        return contractCap;
    }
    
    public void setContractCap(Double contractCap)
    {
        this.contractCap = contractCap;
    }
    
    public String getVoltCode()
    {
        return voltCode;
    }
    
    public void setVoltCode(String voltCode)
    {
        this.voltCode = voltCode;
    }
    
    public String getNotifyMode()
    {
        return notifyMode;
    }
    
    public void setNotifyMode(String notifyMode)
    {
        this.notifyMode = notifyMode;
    }
    
    public String getSettleMode()
    {
        return settleMode;
    }
    
    public void setSettleMode(String settleMode)
    {
        this.settleMode = settleMode;
    }
    
    public String getNoteTypeCode()
    {
        return noteTypeCode;
    }
    
    public void setNoteTypeCode(String noteTypeCode)
    {
        this.noteTypeCode = noteTypeCode;
    }
    
    public String getRemark()
    {
        return remark;
    }
    
    public void setRemark(String remark)
    {
        this.remark = remark;
    }
    
    public String getCerttypeCode()
    {
        return certtypeCode;
    }
    
    public void setCerttypeCode(String certtypeCode)
    {
        this.certtypeCode = certtypeCode;
    }
    
    public String getCertname()
    {
        return certname;
    }
    
    public void setCertname(String certname)
    {
        this.certname = certname;
    }
    
    public String getCertNo()
    {
        return certNo;
    }
    
    public void setCertNo(String certNo)
    {
        this.certNo = certNo;
    }
    
    public String getContactName()
    {
        return contactName;
    }
    
    public void setContactName(String contactName)
    {
        this.contactName = contactName;
    }
    
    public String getMobIle()
    {
        return mobIle;
    }
    
    public void setMobIle(String mobIle)
    {
        this.mobIle = mobIle;
    }
    
    public String getOfficeTel()
    {
        return officeTel;
    }
    
    public void setOfficeTel(String officeTel)
    {
        this.officeTel = officeTel;
    }
    
    public String getHomephone()
    {
        return homephone;
    }
    
    public void setHomephone(String homephone)
    {
        this.homephone = homephone;
    }
    
    public String getEmail()
    {
        return email;
    }
    
    public void setEmail(String email)
    {
        this.email = email;
    }
    
    public String getPostalcode()
    {
        return postalcode;
    }
    
    public void setPostalcode(String postalcode)
    {
        this.postalcode = postalcode;
    }
    
    public String getAddr()
    {
        return addr;
    }
    
    public void setAddr(String addr)
    {
        this.addr = addr;
    }
    
    public String getFaxNo()
    {
        return faxNo;
    }
    
    public void setFaxNo(String faxNo)
    {
        this.faxNo = faxNo;
    }
    
    public String getDistrctNo()
    {
        return distrctNo;
    }
    
    public void setDistrctNo(String distrctNo)
    {
        this.distrctNo = distrctNo;
    }
    
    public String getConsPayMode()
    {
        return consPayMode;
    }
    
    public void setConsPayMode(String consPayMode)
    {
        this.consPayMode = consPayMode;
    }
    
    public String getOrgName()
    {
        return orgName;
    }
    
    public void setOrgName(String orgName)
    {
        this.orgName = orgName;
    }
    
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public Long getChkCycle()
    {
        return chkCycle;
    }
    
    public void setChkCycle(Long chkCycle)
    {
        this.chkCycle = chkCycle;
    }
    
    public Date getLastChkDate()
    {
        if(lastChkDate == null)
        {
            return null;
        }
        return (Date) lastChkDate.clone();
    }
    
    public void setLastChkDate(Date lastChkDate)
    {
        if(lastChkDate == null)
        {
            this.lastChkDate = null;
        }
        else
        {
            this.lastChkDate = (Date) lastChkDate.clone();
        }
    }
    
    public String getTmpFlag()
    {
        return tmpFlag;
    }
    
    public void setTmpFlag(String tmpFlag)
    {
        this.tmpFlag = tmpFlag;
    }
    
    public String getBankName()
    {
        return bankName;
    }
    
    public void setBankName(String bankName)
    {
        this.bankName = bankName;
    }
    
    public Long getBankId()
    {
        return bankId;
    }
    
    public void setBankId(Long bankId)
    {
        this.bankId = bankId;
    }
    
    public Long getHeadOfficeCode()
    {
        return headOfficeCode;
    }
    
    public void setHeadOfficeCode(Long headOfficeCode)
    {
        this.headOfficeCode = headOfficeCode;
    }
    
    public String getAcctName()
    {
        return acctName;
    }
    
    public void setAcctName(String acctName)
    {
        this.acctName = acctName;
    }
    
    public String getBankAcct()
    {
        return bankAcct;
    }
    
    public void setBankAcct(String bankAcct)
    {
        this.bankAcct = bankAcct;
    }
    
    public Long getPayPrioCode()
    {
        return payPrioCode;
    }
    
    public void setPayPrioCode(Long payPrioCode)
    {
        this.payPrioCode = payPrioCode;
    }
    
    public String getEconomyTypeCode()
    {
        return economyTypeCode;
    }
    
    public void setEconomyTypeCode(String economyTypeCode)
    {
        this.economyTypeCode = economyTypeCode;
    }
    
    public String getCreditlevelCode()
    {
        return creditlevelCode;
    }
    
    public void setCreditlevelCode(String creditlevelCode)
    {
        this.creditlevelCode = creditlevelCode;
    }
    
    public String getValuelevelCode()
    {
        return valuelevelCode;
    }
    
    public void setValuelevelCode(String valuelevelCode)
    {
        this.valuelevelCode = valuelevelCode;
    }
    
    public String getRiskLevelCode()
    {
        return riskLevelCode;
    }
    
    public void setRiskLevelCode(String riskLevelCode)
    {
        this.riskLevelCode = riskLevelCode;
    }
    
    public String getLegalPerson()
    {
        return legalPerson;
    }
    
    public void setLegalPerson(String legalPerson)
    {
        this.legalPerson = legalPerson;
    }
    
    public String getVipFlag()
    {
        return vipFlag;
    }
    
    public void setVipFlag(String vipFlag)
    {
        this.vipFlag = vipFlag;
    }
    
    public String getOpenScode()
    {
        return openScode;
    }
    
    public void setOpenScode(String openScode)
    {
        this.openScode = openScode;
    }
    
    public double getRegCapItal()
    {
        return regCapItal;
    }
    
    public void setRegCapItal(double regCapItal)
    {
        this.regCapItal = regCapItal;
    }
    
    public String getVipLevel()
    {
        return vipLevel;
    }
    
    public void setVipLevel(String vipLevel)
    {
        this.vipLevel = vipLevel;
    }
    
    public String getSalesAmt()
    {
        return salesAmt;
    }
    
    public void setSalesAmt(String salesAmt)
    {
        this.salesAmt = salesAmt;
    }
    
    public String getBrief()
    {
        return brief;
    }
    
    public void setBrief(String brief)
    {
        this.brief = brief;
    }
    
    public List<SappCert> getCertList()
    {
        return certList;
    }
    
    public void setCertList(List<SappCert> certList)
    {
        this.certList = certList;
    }
    
    public List<SappContact> getContactList()
    {
        return contactList;
    }
    
    public void setContactList(List<SappContact> contactList)
    {
        this.contactList = contactList;
    }
    
    public Long getAppElecAddrId()
    {
        return appElecAddrId;
    }
    
    public void setAppElecAddrId(Long appElecAddrId)
    {
        this.appElecAddrId = appElecAddrId;
    }
    
    public Long getElecAddrId()
    {
        return elecAddrId;
    }
    
    public void setElecAddrId(Long elecAddrId)
    {
        this.elecAddrId = elecAddrId;
    }
    
    public String getProvinceCode()
    {
        return provinceCode;
    }
    
    public void setProvinceCode(String provinceCode)
    {
        this.provinceCode = provinceCode;
    }
    
    public String getCityCode()
    {
        return cityCode;
    }
    
    public void setCityCode(String cityCode)
    {
        this.cityCode = cityCode;
    }
    
    public String getCountyCode()
    {
        return countyCode;
    }
    
    public void setCountyCode(String countyCode)
    {
        this.countyCode = countyCode;
    }
    
    public String getStreetCode()
    {
        return streetCode;
    }
    
    public void setStreetCode(String streetCode)
    {
        this.streetCode = streetCode;
    }
    
    public String getVillageCode()
    {
        return villageCode;
    }
    
    public void setVillageCode(String villageCode)
    {
        this.villageCode = villageCode;
    }
    
    public String getRoadCode()
    {
        return roadCode;
    }
    
    public void setRoadCode(String roadCode)
    {
        this.roadCode = roadCode;
    }
    
    public String getCommunityCode()
    {
        return communityCode;
    }
    
    public void setCommunityCode(String communityCode)
    {
        this.communityCode = communityCode;
    }
    
    public String getPlateNo()
    {
        return plateNo;
    }
    
    public void setPlateNo(String plateNo)
    {
        this.plateNo = plateNo;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getElectricType()
    {
        return electricType;
    }
    
    public void setElectricType(String electricType)
    {
        this.electricType = electricType;
    }
    
    public Long getCustId()
    {
        return custId;
    }
    
    public void setCustId(Long custId)
    {
        this.custId = custId;
    }
    
    public Long getOrgnContractCap()
    {
        return orgnContractCap;
    }
    
    public void setOrgnContractCap(Long orgnContractCap)
    {
        this.orgnContractCap = orgnContractCap;
    }
    
    public Long gettCcontractCap()
    {
        return tCcontractCap;
    }
    
    public void settCcontractCap(Long tCcontractCap)
    {
        this.tCcontractCap = tCcontractCap;
    }
    
    public String getBailFlag()
    {
        return bailFlag;
    }
    
    public void setBailFlag(String bailFlag)
    {
        this.bailFlag = bailFlag;
    }
    
    public String getCollectionFlag()
    {
        return collectionFlag;
    }
    
    public void setCollectionFlag(String collectionFlag)
    {
        this.collectionFlag = collectionFlag;
    }
    
    public String getGrid()
    {
        return grid;
    }
    
    public void setGrid(String grid)
    {
        this.grid = grid;
    }
    
    public Long getBankAcctId()
    {
        return bankAcctId;
    }
    
    public void setBankAcctId(Long bankAcctId)
    {
        this.bankAcctId = bankAcctId;
    }
    
    public String getFlag()
    {
        return flag;
    }
    
    public void setFlag(String flag)
    {
        this.flag = flag;
    }
    
    public String getTaskId()
    {
        return taskId;
    }
    
    public void setTaskId(String taskId)
    {
        this.taskId = taskId;
    }
    
    public String getProcessId()
    {
        return processId;
    }
    
    public void setProcessId(String processId)
    {
        this.processId = processId;
    }
    
    public Long getMainAppId()
    {
        return mainAppId;
    }
    
    public void setMainAppId(Long mainAppId)
    {
        this.mainAppId = mainAppId;
    }
    
    public String getHandleDeptNo()
    {
        return handleDeptNo;
    }
    
    public void setHandleDeptNo(String handleDeptNo)
    {
        this.handleDeptNo = handleDeptNo;
    }
    
    public String getCustQueryNo()
    {
        return custQueryNo;
    }
    
    public void setCustQueryNo(String custQueryNo)
    {
        this.custQueryNo = custQueryNo;
    }
    
    public String getTmpPayRelaNo()
    {
        return tmpPayRelaNo;
    }
    
    public void setTmpPayRelaNo(String tmpPayRelaNo)
    {
        this.tmpPayRelaNo = tmpPayRelaNo;
    }
    
    public String getOrgnConsNo()
    {
        return orgnConsNo;
    }
    
    public void setOrgnConsNo(String orgnConsNo)
    {
        this.orgnConsNo = orgnConsNo;
    }
    
    public String getShiftNo()
    {
        return shiftNo;
    }
    
    public void setShiftNo(String shiftNo)
    {
        this.shiftNo = shiftNo;
    }
    
    public String getLodeAttrCode()
    {
        return lodeAttrCode;
    }
    
    public void setLodeAttrCode(String lodeAttrCode)
    {
        this.lodeAttrCode = lodeAttrCode;
    }
    
    public String getHecIndustryCode()
    {
        return hecIndustryCode;
    }
    
    public void setHecIndustryCode(String hecIndustryCode)
    {
        this.hecIndustryCode = hecIndustryCode;
    }
    
    public String getHoliday()
    {
        return holiday;
    }
    
    public void setHoliday(String holiday)
    {
        this.holiday = holiday;
    }
    
    public String getTransferCode()
    {
        return transferCode;
    }
    
    public void setTransferCode(String transferCode)
    {
        this.transferCode = transferCode;
    }
    
    public String getMrSectNo()
    {
        return mrSectNo;
    }
    
    public void setMrSectNo(String mrSectNo)
    {
        this.mrSectNo = mrSectNo;
    }
    
    public String getOrgnRunCap()
    {
        return orgnRunCap;
    }
    
    public void setOrgnRunCap(String orgnRunCap)
    {
        this.orgnRunCap = orgnRunCap;
    }
    
    public String getBgnDate()
    {
        return bgnDate;
    }
    
    public void setBgnDate(String bgnDate)
    {
        this.bgnDate = bgnDate;
    }
    
    public String getEndDate()
    {
        return endDate;
    }
    
    public void setEndDate(String endDate)
    {
        this.endDate = endDate;
    }
    
    public String getShiftOutCap()
    {
        return shiftOutCap;
    }
    
    public void setShiftOutCap(String shiftOutCap)
    {
        this.shiftOutCap = shiftOutCap;
    }
    
    public String getShiftInCap()
    {
        return shiftInCap;
    }
    
    public void setShiftInCap(String shiftInCap)
    {
        this.shiftInCap = shiftInCap;
    }
    
    public String getPermenantReduceFlag()
    {
        return permenantReduceFlag;
    }
    
    public void setPermenantReduceFlag(String permenantReduceFlag)
    {
        this.permenantReduceFlag = permenantReduceFlag;
    }
    
    public String getContent()
    {
        return content;
    }
    
    public void setContent(String content)
    {
        this.content = content;
    }
    
    public String getStUpq()
    {
        return stUpq;
    }
    
    public void setStUpq(String stUpq)
    {
        this.stUpq = stUpq;
    }
    
    public String getLongtermCap()
    {
        return longtermCap;
    }
    
    public void setLongtermCap(String longtermCap)
    {
        this.longtermCap = longtermCap;
    }
    
    public String getPowerUsage()
    {
        return powerUsage;
    }
    
    public void setPowerUsage(String powerUsage)
    {
        this.powerUsage = powerUsage;
    }
    
    public String getDmdDate()
    {
        return dmdDate;
    }
    
    public void setDmdDate(String dmdDate)
    {
        this.dmdDate = dmdDate;
    }
    
    public String getMrdFactorCode()
    {
        return mrdFactorCode;
    }
    
    public void setMrdFactorCode(String mrdFactorCode)
    {
        this.mrdFactorCode = mrdFactorCode;
    }
    
    public String getHandleFlag()
    {
        return handleFlag;
    }
    
    public void setHandleFlag(String handleFlag)
    {
        this.handleFlag = handleFlag;
    }
    
    public String getRefuseReason()
    {
        return refuseReason;
    }
    
    public void setRefuseReason(String refuseReason)
    {
        this.refuseReason = refuseReason;
    }
    
    public String getPrioCode()
    {
        return prioCode;
    }
    
    public void setPrioCode(String prioCode)
    {
        this.prioCode = prioCode;
    }
    
    public String getInfoArcDate()
    {
        return infoArcDate;
    }
    
    public void setInfoArcDate(String infoArcDate)
    {
        this.infoArcDate = infoArcDate;
    }
    
    public String getElecTypeCode()
    {
        return elecTypeCode;
    }
    
    public void setElecTypeCode(String elecTypeCode)
    {
        this.elecTypeCode = elecTypeCode;
    }
    
    public Date getTmpDate()
    {
        return tmpDate;
    }
    
    public void setTmpDate(Date tmpDate)
    {
        this.tmpDate = tmpDate;
    }
    
    public String gettContractCap()
    {
        return tContractCap;
    }
    
    public void settContractCap(String tContractCap)
    {
        this.tContractCap = tContractCap;
    }
    
    public String getAppRunCap()
    {
        return appRunCap;
    }
    
    public void setAppRunCap(String appRunCap)
    {
        this.appRunCap = appRunCap;
    }
    
    public String gettRunCap()
    {
        return tRunCap;
    }
    
    public void settRunCap(String tRunCap)
    {
        this.tRunCap = tRunCap;
    }
    
    public String getCustNo()
    {
        return custNo;
    }
    
    public void setCustNo(String custNo)
    {
        this.custNo = custNo;
    }
    
    public String getAnnualGp()
    {
        return annualGp;
    }
    
    public void setAnnualGp(String annualGp)
    {
        this.annualGp = annualGp;
    }
    
    public String getCodeType1()
    {
        return codeType1;
    }
    
    public void setCodeType1(String codeType1)
    {
        this.codeType1 = codeType1;
    }
    
    public String getCodeType2()
    {
        return codeType2;
    }
    
    public void setCodeType2(String codeType2)
    {
        this.codeType2 = codeType2;
    }
    
    public String getCodeType3()
    {
        return codeType3;
    }
    
    public void setCodeType3(String codeType3)
    {
        this.codeType3 = codeType3;
    }
    
    public String getCodeType4()
    {
        return codeType4;
    }
    
    public void setCodeType4(String codeType4)
    {
        this.codeType4 = codeType4;
    }
    
    public String getCodeType5()
    {
        return codeType5;
    }
    
    public void setCodeType5(String codeType5)
    {
        this.codeType5 = codeType5;
    }
    
    public String getCodeType6()
    {
        return codeType6;
    }
    
    public void setCodeType6(String codeType6)
    {
        this.codeType6 = codeType6;
    }
    
    public boolean isSaveFlag()
    {
        return saveFlag;
    }
    
    public void setSaveFlag(boolean saveFlag)
    {
        this.saveFlag = saveFlag;
    }
    
    public int getPage()
    {
        return page;
    }
    
    public void setPage(int page)
    {
        this.page = page;
    }
    
    public int getRows()
    {
        return rows;
    }
    
    public void setRows(int rows)
    {
        this.rows = rows;
    }
    
    public String getMobile()
    {
        return mobile;
    }
    
    public void setMobile(String mobile)
    {
        this.mobile = mobile;
    }
    
    public String getCertTypeCode()
    {
        return certTypeCode;
    }
    
    public void setCertTypeCode(String certTypeCode)
    {
        this.certTypeCode = certTypeCode;
    }
    
    public String getCertTypeCodeName()
    {
        return certTypeCodeName;
    }
    
    public void setCertTypeCodeName(String certTypeCodeName)
    {
        this.certTypeCodeName = certTypeCodeName;
    }
    
    public BigDecimal getSchemecontractCap()
    {
        return schemecontractCap;
    }
    
    public void setSchemecontractCap(BigDecimal schemecontractCap)
    {
        this.schemecontractCap = schemecontractCap;
    }
    
    public Integer getStart()
    {
        return start;
    }
    
    public void setStart(Integer start)
    {
        this.start = start;
    }
    
    public Integer getEnd()
    {
        return end;
    }
    
    public void setEnd(Integer end)
    {
        this.end = end;
    }
    
    public String getNewConsNo()
    {
        return newConsNo;
    }
    
    public void setNewConsNo(String newConsNo)
    {
        this.newConsNo = newConsNo;
    }
    
    public String getNewConsName()
    {
        return newConsName;
    }
    
    public void setNewConsName(String newConsName)
    {
        this.newConsName = newConsName;
    }
    
    public Long getNewConsId()
    {
        return newConsId;
    }
    
    public void setNewConsId(Long newConsId)
    {
        this.newConsId = newConsId;
    }
    
    public int getArcflag()
    {
        return arcflag;
    }
    
    public void setArcflag(int arcflag)
    {
        this.arcflag = arcflag;
    }
    
    public Long getCaAcctId()
    {
        return caAcctId;
    }
    
    public void setCaAcctId(Long caAcctId)
    {
        this.caAcctId = caAcctId;
    }
    
    public double getDepositAmt()
    {
        return depositAmt;
    }
    
    public void setDepositAmt(double depositAmt)
    {
        this.depositAmt = depositAmt;
    }
    
}
