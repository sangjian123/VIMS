package com.vms.activiti.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.task.Task;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.vms.activiti.entity.act.ProcessInstance;
import com.vms.activiti.model.WorkFlow;
import com.vms.activiti.service.ActivitiFlowService;
import com.vms.activiti.util.ProcessDefinitionCache;
import com.vms.constant.CommonConstant;
import com.vms.constant.GeneralConstant;
import com.vms.controller.BaseController;
import com.vms.model.Page;
import com.vms.model.User;
import com.vms.service.UserService;
import com.vms.utils.GeneralUtils;

@Controller
@RequestMapping (value = "/workflow")
public class ProcessInstanceController extends BaseController
{
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private RuntimeService runtimeService;
    
    @Autowired
    private RepositoryService repositoryService;
    
    @Autowired
    ActivitiFlowService activitiFlowService;
    
    @Autowired
    TaskService taskService;
    
    @RequestMapping (value = "/running")
    public ModelAndView running(Model model, HttpServletRequest request)
    {
        ModelAndView mav = new ModelAndView("workflow/running-manage");
        
        return mav;
    }
    
    /**
     * 运行中流程列表
     *
     * @param request
     * @return
     */
    @RequestMapping (value = "/running/dataGrid", method = RequestMethod.POST)
    @ResponseBody
    public Object dataGrid(HttpServletRequest request)
    {
        WorkFlow workFlowQe = new WorkFlow();
        //        String processDefinitionId = request.getParameter ("processDefinitionId");
        //        String processInstanceId = request.getParameter ("processInstanceId");
        String appNo = request.getParameter("appNo");
        //        String assignee = request.getParameter ("assignee");
        ProcessInstance processInstance = new ProcessInstance();
        //        processInstance.setProcessDefinitionId (processDefinitionId);
        //        processInstance.setProcessInstanceId (processInstanceId);
        processInstance.setAppNo(appNo);
        //        processInstance.setAssignee (assignee);
        
        String processType = request.getParameter("procType");
        
        processInstance.setProcessType(processType);
        
        Page<ProcessInstance> page = new Page<ProcessInstance>(processInstance);
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            Map<String, Object> params = new HashMap<String, Object>();
            if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
            {
                params.put("order", sortCol + GeneralConstant.SPACE + order);
                page.setConditions(params);
            }
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        
        page.setPageNo(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_ROWS)));
        
        List<ProcessInstance> list = activitiFlowService.processInstanceList(page);
        
        if(GeneralUtils.isNotNullOrZeroSize(list))
        {
            
            ProcessDefinitionCache.setRepositoryService(repositoryService);
            
            for(ProcessInstance instance : list)
            {
                
                workFlowQe.setBusinessKey(instance.getBusinessKey());
                WorkFlow wf = activitiFlowService.queryFlowUser(workFlowQe);
                //申请人name
                instance.setName(null != wf ? wf.getName() : "");
                //当前处理人assignee
                List<Task> tasks =
                    taskService.createTaskQuery().processInstanceId(instance.getId()).active().orderByTaskCreateTime().desc()
                        .listPage(0, 1);
                if(tasks.size() > 0)
                {
                    String assignee = tasks.get(0).getAssignee();
                    if(StringUtils.isNotBlank(assignee))
                    {
                        User user = userService.findUserById(assignee);
                        if(null == user)
                        {
                            logger.info("get user by id is null,user is not exist");
                            instance.setAssignee("user is not exist");
                        }
                        else
                        {
                            
                            instance.setAssignee(user.getNickName());
                        }
                    }
                }
                instance.setActivityName(ProcessDefinitionCache.getActivityName(instance.getProcessDefinitionId(),
                    instance.getActivityId()));
                if("1".equals(instance.getSuspendedState()))
                { // 设置是否暂停
                    instance.setSuspended(false);
                }
                else
                {
                    instance.setSuspended(true);
                }
            }
        }
        page.setResults(list);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(CommonConstant.PAGE_RESULT_ROWS, page.getResults());
        map.put(CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord());
        return map;
    }
    
    /**
     * 挂起、激活流程实例
     */
    @RequestMapping (value = "update/{state}/{processInstanceId}")
    @ResponseBody
    public Object updateState(@PathVariable ("state") String state, @PathVariable ("processInstanceId") String processInstanceId,
        RedirectAttributes redirectAttributes)
    {
        try
        {
            if(state.equals("active"))
            {
                redirectAttributes.addFlashAttribute("message", "已激活ID为[" + processInstanceId + "]的流程实例。");
                runtimeService.activateProcessInstanceById(processInstanceId);
            }
            else if(state.equals("suspend"))
            {
                runtimeService.suspendProcessInstanceById(processInstanceId);
                redirectAttributes.addFlashAttribute("message", "已挂起ID为[" + processInstanceId + "]的流程实例。");
            }
            return renderSuccess(super.getProperty("oper_success"));
        }
        catch (Exception e)
        {
            return renderError(super.getProperty("oper_fail"));
        }
    }
}
