package com.vms.activiti.entity.act;

import java.io.Serializable;

import com.vms.constant.ConstantCode;
import com.vms.utils.I18nUtils;

public class ProcessTimeOut implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 172648009897744657L;
    
    private String id;
    
    private String procDefId;
    
    private String taskName;
    
    private String timeType;
    
    private int dayNum;
    
    private String procName;
    
    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }
    
    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }
    
    /**
     * @return the procDefId
     */
    public String getProcDefId()
    {
        return procDefId;
    }
    
    /**
     * @param procDefId the procDefId to set
     */
    public void setProcDefId(String procDefId)
    {
        this.procDefId = procDefId;
    }
    
    /**
     * @return the taskName
     */
    public String getTaskName()
    {
        return taskName;
    }
    
    /**
     * @param taskName the taskName to set
     */
    public void setTaskName(String taskName)
    {
        this.taskName = taskName;
    }
    
    /**
     * @return the timeType
     */
    public String getTimeType()
    {
        return timeType;
    }
    
    /**
     * @param timeType the timeType to set
     */
    public void setTimeType(String timeType)
    {
        this.timeType = timeType;
    }
    
    /**
     * @return the dayNum
     */
    public int getDayNum()
    {
        return dayNum;
    }
    
    /**
     * @param dayNum the dayNum to set
     */
    public void setDayNum(int dayNum)
    {
        this.dayNum = dayNum;
    }
    
    /**
     * @return the procName
     */
    public String getProcName()
    {
        return procName;
    }
    
    /**
     * @param procName the procName to set
     */
    public void setProcName(String procName)
    {
        this.procName = procName;
    }
    
    @Override
    public String toString()
    {
        return "[" + I18nUtils.getI18nMsg("workflow.process-timeout.taskName") + ":" + taskName + ", "
            + I18nUtils.getI18nMsg("workflow.process-timeout.timeType") + ":" + changeTypeShow(timeType) + ", "
            + I18nUtils.getI18nMsg("workflow.process-timeout.dayNum") + ":" + dayNum + "]";
    }
    
    private String changeTypeShow(String type)
    {
        if(type != null && ConstantCode.STRING_01.equals(type))
        {
            return I18nUtils.getI18nMsg("workflow.process-timeout.workDay");
        }
        else
        {
            return I18nUtils.getI18nMsg("workflow.process-timeout.calendarDay");
        }
    }
    
}
