package com.vms.activiti.mapper;

import java.util.List;

import com.vms.activiti.entity.act.ProcessTimeOut;
import com.vms.model.Page;

public interface ProcessTimeOutMapper
{
    /**
     * 获取超时列表
     * 
     * @param page
     * @return
     */
    List<ProcessTimeOut> queryProcessTimeOutByPage(Page<ProcessTimeOut> page);
    
    /**
     * 新增超时列表
     * 
     * @param processTimeOut
     * @return
     */
    int insertProcessTimeOut(ProcessTimeOut processTimeOut);
    
    /**
     * 修改超时列表
     * 
     * @param processTimeOut
     * @return
     */
    int editProcessTimeOut(ProcessTimeOut processTimeOut);
    
    ProcessTimeOut queryProcessTimeOutById(String id);
}
