package com.vms.activiti.model;

import java.sql.Timestamp;

import com.vms.utils.I18nUtils;

public class PanelInfo
{
    
    private String id;
    
    private String userId;
    
    private String roleId;
    
    private String resourceId;
    
    private String resourceName;
    
    private String nameFmt;
    
    private Long topResourceId;
    
    private Long oldResourceId;
    
    private String topResourceName;
    
    private String url;
    
    private Timestamp createTime;
    
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getUserId()
    {
        return userId;
    }
    
    public void setUserId(String userId)
    {
        this.userId = userId;
    }
    
    public String getRoleId()
    {
        return roleId;
    }
    
    public void setRoleId(String roleId)
    {
        this.roleId = roleId;
    }
    
    public String getResourceId()
    {
        return resourceId;
    }
    
    public void setResourceId(String resourceId)
    {
        this.resourceId = resourceId;
    }
    
    public String getResourceName()
    {
        return resourceName;
    }
    
    public void setResourceName(String resourceName)
    {
        this.resourceName = resourceName;
    }
    
    public String getNameFmt()
    {
        nameFmt = I18nUtils.getI18nMsg(getResourceName());
        return nameFmt;
    }
    
    public void setNameFmt(String nameFmt)
    {
        this.nameFmt = nameFmt;
    }
    
    public Long getTopResourceId()
    {
        return topResourceId;
    }
    
    public void setTopResourceId(Long topResourceId)
    {
        this.topResourceId = topResourceId;
    }
    
    public Long getOldResourceId()
    {
        return oldResourceId;
    }
    
    public void setOldResourceId(Long oldResourceId)
    {
        this.oldResourceId = oldResourceId;
    }
    
    public String getTopResourceName()
    {
        return topResourceName;
    }
    
    public void setTopResourceName(String topResourceName)
    {
        this.topResourceName = topResourceName;
    }
    
    public String getUrl()
    {
        return url;
    }
    
    @Override
    public int hashCode()
    {
        String in = id;
        return in.hashCode();
    }
    
    @Override
    public boolean equals(Object obj)
    {
        if(null == obj)
        {
            return false;
        }
        if(this.getClass() != obj.getClass())
        {
            
            return false;
        }
        PanelInfo s = (PanelInfo) obj;
        return id.equals(s.id);
    }
    
    @Override
    public String toString()
    {
        return "PanelInfo{" + "id=" + id + ", nameFmt='" + nameFmt + '\'' + ", url='" + url + '\'' + '\'' + ", userId=" + userId
            + ", resourceId=" + resourceId + ", topResourceId=" + topResourceId + '}';
    }
    
    public void setUrl(String url)
    {
        this.url = url;
    }
    
    public Timestamp getCreateTime()
    {
        return createTime;
    }
    
    public void setCreateTime(Timestamp createTime)
    {
        this.createTime = createTime;
    }
}
