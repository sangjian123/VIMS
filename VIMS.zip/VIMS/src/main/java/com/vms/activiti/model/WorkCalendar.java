package com.vms.activiti.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 工作日历维护
 * @author lucheng
 *
 */
public class WorkCalendar implements Serializable
{
    
    /**
     * 序列化
     */
    private static final long serialVersionUID = 4771346263774447157L;
    
    private String workDay;
    
    private String workMonth;
    
    private String workYear;
    
    /**
     * 是否是工作日：01-是，02-否
     */
    private String isWork;
    
    private Date updateTime;
    
    private Date workYmd;
    
    public String getWorkDay ()
    {
        return workDay;
    }
    
    public void setWorkDay (String workDay)
    {
        this.workDay = workDay;
    }
    
    public String getWorkMonth ()
    {
        return workMonth;
    }
    
    public void setWorkMonth (String workMonth)
    {
        this.workMonth = workMonth;
    }
    
    public String getWorkYear ()
    {
        return workYear;
    }
    
    public void setWorkYear (String workYear)
    {
        this.workYear = workYear;
    }
    
    public String getIsWork ()
    {
        return isWork;
    }
    
    public void setIsWork (String isWork)
    {
        this.isWork = isWork;
    }
    
    public Date getUpdateTime ()
    {
        return updateTime;
    }
    
    public void setUpdateTime (Date updateTime)
    {
        this.updateTime = updateTime;
    }
    
    public Date getWorkYmd ()
    {
        return workYmd;
    }
    
    public void setWorkYmd (Date workYmd)
    {
        this.workYmd = workYmd;
    }
    
}
