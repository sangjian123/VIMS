package com.vms.activiti.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.activiti.entity.act.ProcessType;
import com.vms.activiti.service.ProcessTypeService;
import com.vms.controller.BaseController;
import com.vms.utils.UUIDUtils;

@Controller
@RequestMapping ("/processType")
public class ProcessTypeController extends BaseController
{
    @Autowired
    private ProcessTypeService processTypeService;
    
    @RequestMapping ("")
    public String index(HttpServletRequest request, Model model)
    {
        request.setAttribute("procName", request.getParameter("procName"));
        
        String procName = request.getParameter("procName");
        
        ProcessType processType = processTypeService.queryProcessTypeByName(procName);
        
        if(null == processType)
        {
            
            processType = new ProcessType();
            processType.setId(UUIDUtils.generate16Str());
            processType.setProcName(procName);
            processType.setProcType("3");
            
        }
        
        model.addAttribute("processType", processType);
        
        return "/workflow/process-type";
    }
    
    @RequestMapping ("/query")
    @ResponseBody
    public Map<String, Object> queryProcessTimeOutByPage(ProcessType processType, HttpServletRequest request)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        //        Page <ProcessType> page = new Page <ProcessType> (processType);
        //        page.setPageNo (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_PAGE)));
        //        page.setPageSize (NumberUtils.toInt (request.getParameter (CommonConstant.PAGE_PARAM_ROWS)));
        //        
        //        page = processTypeService.queryProcessTypeByPage (page);
        //        map.put (CommonConstant.PAGE_RESULT_ROWS, page.getResults ());
        //        map.put (CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord ());
        
        return map;
    }
    
    @RequestMapping ("/addOrUpdateProcessType")
    @ResponseBody
    public Object addOrUpdateProcessType(ProcessType processType)
    {
        ProcessType old = null;
        int rt = 0;
        old = processTypeService.queryProcessTypeByName(processType.getProcName());
        
        if(null == old)
        {
            //新增
            rt = processTypeService.insertProcessType(processType);
        }
        else
        {
            //修改
            rt = processTypeService.editProcessType(processType);
        }
        
        //        //获取当前登录用户
        //        User curUser = getCurrentUser ();
        //        //获取操作描述 key = 类名+"_"+方法名 
        //        String funDesc = LogRenderUtils.getLogReqMap ("ProcessTimeOutController_add");
        //        try {
        //            //分析新增对象的内容
        ////            String operDetail = processTimeOutService.analyseEditContent (old,processTimeOut);
        //            if(StringUtils.isNotBlank (operDetail)){
        //                //插入日志
        //                logService.insertSysLog (curUser, ConstantCode.STRING_02, getRemoteAddr (), funDesc, operDetail, null, null);
        //            }
        //        } catch (Exception ex) {
        //            logger.error (funDesc + "  bussness log insert error",ex);
        //        }
        
        if(rt == 0)
        {
            return renderError(processType.getProcName());
        }
        else
        {
            return renderSuccess(super.getProperty("oper_success"));
        }
    }
    
}
