package com.vms.activiti.mapper;

import java.util.List;

import com.vms.activiti.model.ProcActTime;

public interface ProcActTimeMapper
{
    /**
     * 查询所有流程超时时间
     *
     * @return
     */
    List<ProcActTime> findAllProcActTime();
}
