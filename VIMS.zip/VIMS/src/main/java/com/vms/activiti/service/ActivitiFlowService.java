package com.vms.activiti.service;

import java.util.List;
import java.util.Map;

import com.vms.activiti.entity.act.ProcessInstance;
import com.vms.activiti.model.ApplicationInfo;
import com.vms.activiti.model.WorkFlow;
import com.vms.model.Page;

/**
 * 工作流的service	
 * @author kxx
 *
 */
public interface ActivitiFlowService
{
    
    void updateIdBySapp(Long id, Long appid);
    
    public WorkFlow queryFlowUser(String processInstance);
    
    public ApplicationInfo queryAppidByBusinessKey(String businessKey);
    
    ApplicationInfo queryAppInfoByAppId(Long appId);
    
    //根据id分配下一个岗位的用户
    void updateAssigneeById(String id, String name);
    
    //查询工作流模型key集合
    List<String> queryFlowKey();
    
    //根据查询条件查询 查询代办信息
    ApplicationInfo queryAppidByBusinessKey(WorkFlow workFlowQe);
    
    WorkFlow queryFlowUser(WorkFlow workFlowQe);
    
    List<WorkFlow> queryProcessNameByPage();
    
    List<WorkFlow> queryStepName(WorkFlow workFlow);
    
    List<ProcessInstance> processInstanceList(Page<ProcessInstance> page);
    
    /**
     * 修改任务状态
     *
     * @param appId
     * @param status
     * @return
     */
    int updateTaskStatus(Long appId, String status);
    
    /**
     * 判断流程是否可终止
     * @param appId
     * @return
     */
    Map<String, Object> findTerminateStatus(Long appId);
    
    /**
     * 删除申请信息
     * @param appId
     */
    void delSApp(String appId);
}
