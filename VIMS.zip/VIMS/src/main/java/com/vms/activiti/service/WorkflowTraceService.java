package com.vms.activiti.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.identity.User;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.bpmn.behavior.UserTaskActivityBehavior;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.delegate.ActivityBehavior;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.task.TaskDefinition;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vms.activiti.mapper.ActHiTaskinstMapper;
import com.vms.activiti.model.ActHiTaskinst;
import com.vms.activiti.util.WorkflowUtils;
import com.vms.utils.DateUtils;

/**
 * 工作流跟踪相关Service
 *
 * @author HenryYan
 */
@Component
public class WorkflowTraceService
{
    protected Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    protected RuntimeService runtimeService;
    
    @Autowired
    protected TaskService taskService;
    
    @Autowired
    protected RepositoryService repositoryService;
    
    @Autowired
    protected IdentityService identityService;
    
    @Autowired
    private ActHiTaskinstMapper actHiTaskinstMapper;
    
    private static Map<String, Map<String, String>> pnameMap = new HashMap<>();
    
    static
    {
        //低压居民新装
        Map<String, String> ResidentInstallationStep = new HashMap<>();
        ResidentInstallationStep.put("Site investigation and Install meter", "01");
        ResidentInstallationStep.put("Business Fees", "06");
        ResidentInstallationStep.put("QA audit", "08");
        ResidentInstallationStep.put("Business filing", "09");
        ResidentInstallationStep.put("Archiving", "09");
        
        pnameMap.put("ResidentInstallation", ResidentInstallationStep);
        
        //非居民新装
        Map<String, String> LVNonresidentInstallationStep = new HashMap<>();
        LVNonresidentInstallationStep.put("Site investigation", "01");
        LVNonresidentInstallationStep.put("Business Fees", "06");
        LVNonresidentInstallationStep.put("Install meter and Power on", "02");
        LVNonresidentInstallationStep.put("Business filing", "09");
        LVNonresidentInstallationStep.put("Archiving", "09");
        
        pnameMap.put("LVNon-residentInstallation", LVNonresidentInstallationStep);
        
        //高压新装
        Map<String, String> HVInstallationStep = new HashMap<>();
        HVInstallationStep.put("Site investigation", "01");
        HVInstallationStep.put("Business Fees", "06");
        HVInstallationStep.put("Install meter and Power on", "02");
        HVInstallationStep.put("Business filing", "09");
        HVInstallationStep.put("Archiving", "09");
        
        pnameMap.put("HVInstallation", HVInstallationStep);
        
        //过户
        Map<String, String> AccountTransferStep = new HashMap<>();
        AccountTransferStep.put("Expense clearing", "07");
        AccountTransferStep.put("Business filing", "09");
        AccountTransferStep.put("Archiving", "09");
        
        pnameMap.put("AccountTransfer", AccountTransferStep);
        
        //销户
        Map<String, String> AccountDeactivationStep = new HashMap<>();
        AccountDeactivationStep.put("Expense clearing", "07");
        //旧归档翻译
        AccountDeactivationStep.put("Business filing", "09");
        //新归档翻译
        AccountDeactivationStep.put("Archiving", "09");
        
        pnameMap.put("AccountDeactivation", AccountDeactivationStep);
        
        //容量变更
        Map<String, String> CapacityChangeStep = new HashMap<>();
        CapacityChangeStep.put("Site investigation", "01");
        CapacityChangeStep.put("Business Fees", "06");
        CapacityChangeStep.put("Install/Remove meter", "02");
        CapacityChangeStep.put("Expense clearing", "07");
        CapacityChangeStep.put("Business filing", "09");
        CapacityChangeStep.put("Archiving", "09");
        pnameMap.put("CapacityChange", CapacityChangeStep);
        
        //改类
        Map<String, String> CategoryChangeStep = new HashMap<>();
        CategoryChangeStep.put("Site investigation", "01");
        CategoryChangeStep.put("Install/Remove meter", "02");
        CategoryChangeStep.put("Expense clearing", "07");
        CategoryChangeStep.put("Business filing", "09");
        CategoryChangeStep.put("Archiving", "09");
        pnameMap.put("CategoryChange", CategoryChangeStep);
        
        //故障报修
        Map<String, String> FaultRepairStep = new HashMap<>();
        AccountDeactivationStep.put("Fault Handling", "04");
        //        AccountDeactivationStep.put ("Return Visit", "");
        
        pnameMap.put("Fault Repair", FaultRepairStep);
    }
    
    /**
     * 流程跟踪图
     *
     * @param processInstanceId
     *            流程实例ID
     * @return 封装了各种节点信息
     */
    public Map<String, List<Map<String, Object>>> traceProcess(String processInstanceId)
    {
        
        Map<String, List<Map<String, Object>>> result = new HashMap<String, List<Map<String, Object>>>();
        Execution execution = runtimeService.createExecutionQuery().executionId(processInstanceId).singleResult();// 执行实例
        String activityId = "";
        Object property;
        try
        {
            property = PropertyUtils.getProperty(execution, "activityId");
            if(property != null)
            {
                activityId = property.toString();
            }
        }
        catch (Exception e)
        {
            logger.error(" PropertyUtils.getProperty error:", e);
        }
        
        ProcessInstance processInstance =
            runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        ProcessDefinitionEntity processDefinition =
            (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(processInstance
                .getProcessDefinitionId());
        List<ActivityImpl> activitiList = processDefinition.getActivities();// 获得当前任务的所有节点
        
        List<Map<String, Object>> activityInfos = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> actTasks = new ArrayList<Map<String, Object>>();
        
        List<ActHiTaskinst> actHiTasks = actHiTaskinstMapper.findTaskinstByTaskKeyAndId(processInstanceId);
        for(ActivityImpl activity : activitiList)
        {
            boolean currentActiviti = false;
            String id = activity.getId();
            
            // 当前节点
            if(id.equals(activityId))
            {
                currentActiviti = true;
            }
            
            Map<String, Object> activityImageInfo =
                packageSingleActivitiInfo(activity, processInstance, currentActiviti, processInstanceId);
            
            activityInfos.add(activityImageInfo);
        }
        
        // 迭代历史任务
        for(ActHiTaskinst actTask : actHiTasks)
        {
            Map<String, Object> act = packageHistask(actTask);
            actTasks.add(act);
        }
        
        result.put("activityInfos", activityInfos);
        result.put("actTasks", actTasks);
        
        return result;
    }
    
    /**
     * 流程跟踪图-new  增加appNo
     *
     * @param processInstanceId
     *            流程实例ID
     * @return 封装了各种节点信息
     */
    public Map<String, List<Map<String, Object>>> traceProcess(String processInstanceId, String appNo)
    {
        
        Map<String, List<Map<String, Object>>> result = new HashMap<String, List<Map<String, Object>>>();
        Execution execution = runtimeService.createExecutionQuery().executionId(processInstanceId).singleResult();// 执行实例
        String activityId = "";
        Object property;
        try
        {
            property = PropertyUtils.getProperty(execution, "activityId");
            if(property != null)
            {
                activityId = property.toString();
            }
        }
        catch (Exception e)
        {
            logger.error(" PropertyUtils.getProperty error:", e);
        }
        
        ProcessInstance processInstance =
            runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        ProcessDefinitionEntity processDefinition =
            (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(processInstance
                .getProcessDefinitionId());
        List<ActivityImpl> activitiList = processDefinition.getActivities();// 获得当前任务的所有节点
        
        List<Map<String, Object>> activityInfos = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> actTasks = new ArrayList<Map<String, Object>>();
        
        List<ActHiTaskinst> actHiTasks = actHiTaskinstMapper.findTaskinstByTaskKeyAndId(processInstanceId);
        for(ActivityImpl activity : activitiList)
        {
            boolean currentActiviti = false;
            String id = activity.getId();
            
            // 当前节点
            if(id.equals(activityId))
            {
                currentActiviti = true;
            }
            
            Map<String, Object> activityImageInfo =
                packageSingleActivitiInfo(activity, processInstance, currentActiviti, processInstanceId);
            
            activityInfos.add(activityImageInfo);
        }
        
        // 迭代历史任务
        for(ActHiTaskinst actTask : actHiTasks)
        {
            Map<String, Object> act = packageHistask(actTask, appNo);
            actTasks.add(act);
        }
        
        result.put("activityInfos", activityInfos);
        result.put("actTasks", actTasks);
        
        return result;
    }
    
    /**
     * 流程跟踪图
     *
     * @param processInstanceId
     *            流程实例ID
     * @return 封装了各种节点信息
     */
    public Map<String, List<Map<String, Object>>> traceCompProcess(String processInstanceId, String procDefId)
    {
        String activityId = "";
        ProcessInstance processInstance = null;
        Map<String, List<Map<String, Object>>> result = new HashMap<String, List<Map<String, Object>>>();
        /*if (StringUtils.isNotBlank (processInstanceId))
        {
            Execution execution = runtimeService.createExecutionQuery ().executionId (processInstanceId).singleResult ();// 执行实例
            if (execution != null)
            {
                Object property = PropertyUtils.getProperty (execution, "activityId");
                if (property != null)
                {
                    activityId = property.toString ();
                }
                processInstance =
                    runtimeService.createProcessInstanceQuery ().processInstanceId (processInstanceId).singleResult ();
                procDefId = processInstance.getProcessDefinitionId ();
            }
        }*/
        ProcessDefinitionEntity processDefinition =
            (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(procDefId);
        List<ActivityImpl> activitiList = processDefinition.getActivities();// 获得当前任务的所有节点
        List<Map<String, Object>> activityInfos = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> actTasks = new ArrayList<Map<String, Object>>();
        
        List<ActHiTaskinst> actHiTasks = actHiTaskinstMapper.findTaskinstByTaskKeyAndId(processInstanceId);
        for(ActivityImpl activity : activitiList)
        {
            boolean currentActiviti = false;
            String id = activity.getId();
            
            // 当前节点
            if(id.equals(activityId))
            {
                currentActiviti = true;
            }
            
            Map<String, Object> activityImageInfo =
                packageSingleActivitiInfo(activity, processInstance, currentActiviti, processInstanceId);
            
            activityInfos.add(activityImageInfo);
            
        }
        
        // 迭代历史任务
        for(ActHiTaskinst actTask : actHiTasks)
        {
            Map<String, Object> act = packageHistask(actTask);
            actTasks.add(act);
        }
        
        result.put("activityInfos", activityInfos);
        result.put("actTasks", actTasks);
        
        return result;
    }
    
    /**
     * 流程跟踪图-new 新增appNo
     *
     * @param processInstanceId
     *            流程实例ID
     * @return 封装了各种节点信息
     */
    public Map<String, List<Map<String, Object>>> traceCompProcess(String processInstanceId, String procDefId, String appNo)
    {
        String activityId = "";
        ProcessInstance processInstance = null;
        Map<String, List<Map<String, Object>>> result = new HashMap<String, List<Map<String, Object>>>();
        /*if (StringUtils.isNotBlank (processInstanceId))
        {
            Execution execution = runtimeService.createExecutionQuery ().executionId (processInstanceId).singleResult ();// 执行实例
            if (execution != null)
            {
                Object property = PropertyUtils.getProperty (execution, "activityId");
                if (property != null)
                {
                    activityId = property.toString ();
                }
                processInstance =
                    runtimeService.createProcessInstanceQuery ().processInstanceId (processInstanceId).singleResult ();
                procDefId = processInstance.getProcessDefinitionId ();
            }
        }*/
        ProcessDefinitionEntity processDefinition =
            (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(procDefId);
        List<ActivityImpl> activitiList = processDefinition.getActivities();// 获得当前任务的所有节点
        List<Map<String, Object>> activityInfos = new ArrayList<Map<String, Object>>();
        List<Map<String, Object>> actTasks = new ArrayList<Map<String, Object>>();
        
        List<ActHiTaskinst> actHiTasks = actHiTaskinstMapper.findTaskinstByTaskKeyAndId(processInstanceId);
        for(ActivityImpl activity : activitiList)
        {
            boolean currentActiviti = false;
            String id = activity.getId();
            
            // 当前节点
            if(id.equals(activityId))
            {
                currentActiviti = true;
            }
            
            Map<String, Object> activityImageInfo =
                packageSingleActivitiInfo(activity, processInstance, currentActiviti, processInstanceId);
            
            activityInfos.add(activityImageInfo);
            
        }
        
        // 迭代历史任务
        for(ActHiTaskinst actTask : actHiTasks)
        {
            Map<String, Object> act = packageHistask(actTask, appNo);
            actTasks.add(act);
        }
        
        result.put("activityInfos", activityInfos);
        result.put("actTasks", actTasks);
        
        return result;
    }
    
    /**
     * 封装输出信息，包括：当前节点的X、Y坐标、变量信息、任务类型、任务描述
     *
     * @param activity
     * @param processInstance
     * @param currentActiviti
     * @return
     */
    private Map<String, Object> packageSingleActivitiInfo(ActivityImpl activity, ProcessInstance processInstance,
        boolean currentActiviti, String processInstanceId)
    {
        Map<String, Object> vars = new HashMap<String, Object>();
        Map<String, Object> activityInfo = new HashMap<String, Object>();
        activityInfo.put("currentActiviti", currentActiviti);
        setPosition(activity, activityInfo);
        setWidthAndHeight(activity, activityInfo);
        
        Map<String, Object> properties = activity.getProperties();
        vars.put("任务类型", WorkflowUtils.parseToZhType(properties.get("type").toString()));
        
        ActivityBehavior activityBehavior = activity.getActivityBehavior();
        logger.debug("activityBehavior={}", activityBehavior);
        if(activityBehavior instanceof UserTaskActivityBehavior)
        {
            
            Task currentTask = null;
            
            /*
             * 当前节点的task
             */
            if(currentActiviti)
            {
                currentTask = getCurrentTaskInfo(processInstance);
            }
            
            /*
             * 当前任务的分配角色
             */
            UserTaskActivityBehavior userTaskActivityBehavior = (UserTaskActivityBehavior) activityBehavior;
            TaskDefinition taskDefinition = userTaskActivityBehavior.getTaskDefinition();
            Set<Expression> candidateGroupIdExpressions = taskDefinition.getCandidateGroupIdExpressions();
            if(!candidateGroupIdExpressions.isEmpty())
            {
                
                // 任务的处理角色
                setTaskGroup(vars, candidateGroupIdExpressions);
                
                // 当前处理人
                if(currentTask != null)
                {
                    setCurrentTaskAssignee(vars, currentTask);
                }
            }
        }
        
        vars.put("节点说明", properties.get("documentation"));
        
        String description = activity.getProcessDefinition().getDescription();
        vars.put("描述", description);
        
        logger.debug("trace variables: {}", vars);
        activityInfo.put("vars", vars);
        //增加其他处理
        //setHisTask (vars, activity, processInstanceId);
        return activityInfo;
    }
    
    /**
     * 封装输出信息任务信息
     *
     * @param activity
     * @param processInstance
     * @param currentActiviti
     * @return
     */
    private Map<String, Object> packageHistask(ActHiTaskinst acHiTask)
    {
        Map<String, Object> vars = new HashMap<String, Object>();
        Map<String, Object> activityInfo = new HashMap<String, Object>();
        vars.put("CurrentTime", DateUtils.formatDate(new Date(), DateUtils.DATE_PATTERN));
        if(null != acHiTask)
        {
            vars.put("nodeName", acHiTask.getName());
            vars.put("Operator", acHiTask.getAssignee());
            vars.put("StartTime", DateUtils.formatDate(acHiTask.getStartTime(), DateUtils.DATE_PATTERN));
            vars.put("EndTime", DateUtils.formatDate(acHiTask.getEndTime(), DateUtils.DATE_PATTERN));
            if(StringUtils.isBlank(acHiTask.getDeleteReason()) && null != acHiTask.getEndTime())
            {
                vars.put("taskStatus", "processing");//正在处理
            }
            else
            {
                vars.put("taskStatus", "completed");//处理完成
            }
        }
        else
        {
            vars.put("taskStatus", "unHandled");//未处理
        }
        activityInfo.put("vars", vars);
        //增加其他处理
        return activityInfo;
    }
    
    /**
     * 封装输出信息任务信息
     *
     * @param activity
     * @param processInstance
     * @param currentActiviti
     * @return
     */
    private Map<String, Object> packageHistask(ActHiTaskinst acHiTask, String appNo)
    {
        Map<String, Object> vars = new HashMap<String, Object>();
        Map<String, Object> activityInfo = new HashMap<String, Object>();
        vars.put("CurrentTime", DateUtils.formatDate(new Date(), DateUtils.DATE_PATTERN));
        if(null != acHiTask)
        {
            vars.put("nodeName", acHiTask.getName());
            
            if(StringUtils.isNotEmpty(acHiTask.getAssignee()))
            {
                
                //1.根据用户名查询部门
                vars.put("Department", actHiTaskinstMapper.getUserDeptByLoginName(acHiTask.getLoginName()));
            }
            else
            {
                //2.根据 appNo 查询地址  根据地址和tasktype 获取deptid
                if(StringUtils.isNotEmpty(acHiTask.getPname()))
                {
                    if(pnameMap.containsKey(acHiTask.getPname()))
                    {
                        Map<String, Object> pMap = new HashMap<>();
                        String taskType = pnameMap.get(acHiTask.getPname()).get(acHiTask.getName());
                        pMap.put("taskType", taskType);
                        pMap.put("appNo", appNo);
                        String dept = actHiTaskinstMapper.getUserDeptByTaskTypeAndAppNo(pMap);
                        vars.put("Department", dept);
                    }
                    else
                    {
                        vars.put("Department", "Null");
                    }
                }
            }
            
            vars.put("Operator", acHiTask.getAssignee());
            vars.put("StartTime", DateUtils.formatDate(acHiTask.getStartTime(), DateUtils.DATE_PATTERN));
            vars.put("EndTime", DateUtils.formatDate(acHiTask.getEndTime(), DateUtils.DATE_PATTERN));
            if(StringUtils.isBlank(acHiTask.getDeleteReason()) && null != acHiTask.getEndTime())
            {
                vars.put("taskStatus", "processing");//正在处理
            }
            else
            {
                vars.put("taskStatus", "completed");//处理完成
            }
        }
        else
        {
            vars.put("taskStatus", "unHandled");//未处理
        }
        activityInfo.put("vars", vars);
        //增加其他处理
        return activityInfo;
    }
    
    private void setTaskGroup(Map<String, Object> vars, Set<Expression> candidateGroupIdExpressions)
    {
        String roles = "";
        for(Expression expression : candidateGroupIdExpressions)
        {
            String roleName = "";
            String expressionText = expression.getExpressionText();
            if(null != identityService.createGroupQuery().groupId(expressionText).singleResult())
            {
                roleName = identityService.createGroupQuery().groupId(expressionText).singleResult().getName();
                roles += roleName;
            }
        }
        vars.put("任务所属角色", roles);
    }
    
    /**
     * 设置当前处理人信息
     *
     * @param vars
     * @param currentTask
     */
    private void setCurrentTaskAssignee(Map<String, Object> vars, Task currentTask)
    {
        String assignee = currentTask.getAssignee();
        if(assignee != null)
        {
            User assigneeUser = identityService.createUserQuery().userId(assignee).singleResult();
            String userInfo = "";
            if(assigneeUser != null)
            {
                userInfo = assigneeUser.getFirstName() + " " + assigneeUser.getLastName();
            }
            
            vars.put("当前处理人", userInfo);
            vars.put("处理时间", currentTask.getDueDate());
        }
    }
    
    /**
     * 获取当前节点信息
     *
     * @param processInstance
     * @return
     */
    private Task getCurrentTaskInfo(ProcessInstance processInstance)
    {
        Task currentTask = null;
        try
        {
            String activitiId = (String) PropertyUtils.getProperty(processInstance, "activityId");
            logger.debug("current activity id: {}", activitiId);
            
            currentTask =
                taskService.createTaskQuery().processInstanceId(processInstance.getId()).taskDefinitionKey(activitiId)
                    .singleResult();
            logger.debug("current task for processInstance: {}", ToStringBuilder.reflectionToString(currentTask));
            
        }
        catch (Exception e)
        {
            logger.error("can not get property activityId from processInstance: {}", processInstance);
        }
        return currentTask;
    }
    
    /**
     * 设置宽度、高度属性
     *
     * @param activity
     * @param activityInfo
     */
    private void setWidthAndHeight(ActivityImpl activity, Map<String, Object> activityInfo)
    {
        activityInfo.put("width", activity.getWidth());
        activityInfo.put("height", activity.getHeight());
    }
    
    /**
     * 设置坐标位置
     *
     * @param activity
     * @param activityInfo
     */
    private void setPosition(ActivityImpl activity, Map<String, Object> activityInfo)
    {
        activityInfo.put("x", activity.getX());
        activityInfo.put("y", activity.getY());
    }
}
