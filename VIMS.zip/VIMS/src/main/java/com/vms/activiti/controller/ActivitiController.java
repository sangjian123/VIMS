package com.vms.activiti.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.editor.constants.ModelDataJsonConstants;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.ManagementService;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.identity.User;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.context.Context;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.activiti.engine.task.Task;
import org.activiti.image.ProcessDiagramGenerator;
import org.activiti.spring.ProcessEngineFactoryBean;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vms.activiti.entity.act.ProcessDefinition;
import com.vms.activiti.service.ActivitiService;
import com.vms.activiti.service.JumpActivityCmd;
import com.vms.activiti.service.WorkflowProcessDefinitionService;
import com.vms.activiti.service.WorkflowTraceService;
import com.vms.activiti.util.UserUtil;
import com.vms.activiti.util.WorkflowUtils;
import com.vms.constant.CommonConstant;
import com.vms.constant.GeneralConstant;
import com.vms.controller.BaseController;
import com.vms.model.Page;
import com.vms.utils.GeneralUtils;

/**
 * 流程管理控制器
 *
 * @author HenryYan
 */
@Controller
@RequestMapping (value = "/workflow")
public class ActivitiController extends BaseController
{
    
    protected WorkflowProcessDefinitionService workflowProcessDefinitionService;
    
    protected RepositoryService repositoryService;
    
    protected RuntimeService runtimeService;
    
    protected TaskService taskService;
    
    protected WorkflowTraceService traceService;
    
    @Autowired
    ManagementService managementService;
    
    protected static Map<String, org.activiti.engine.repository.ProcessDefinition> PROCESS_DEFINITION_CACHE =
        new HashMap<String, org.activiti.engine.repository.ProcessDefinition>();
    
    @Autowired
    ProcessEngineFactoryBean processEngine;
    
    @Autowired
    ProcessEngineConfiguration processEngineConfiguration;
    
    @Autowired
    private ActivitiService activitiService;
    
    /**
     * 流程定义列表
     *
     * @return
     */
    @RequestMapping (value = "/process-list")
    public ModelAndView toProcessList(HttpServletRequest request)
    {
        ModelAndView mav = new ModelAndView("workflow/process-list");
        return mav;
    }
    
    /**
     * 部署心流程
     *
     * @return
     */
    @RequestMapping (value = "/process-import")
    public ModelAndView toProcessImport(HttpServletRequest request)
    {
        ModelAndView mav = new ModelAndView("workflow/process-import");
        return mav;
    }
    
    @RequestMapping (value = "/process/datagrid", method = RequestMethod.POST)
    @ResponseBody
    public Object processList(HttpServletRequest request)
    {
        
        String processDefinitionName = request.getParameter("processDefinitionName");
        String isSuspended = request.getParameter("isSuspended");
        ProcessDefinition processDefinition = new ProcessDefinition();
        processDefinition.setSuspended(isSuspended);
        
        //processType
        String processType = request.getParameter("procType");
        processDefinition.setProcessType(processType);
        
        Map<String, Object> map = new HashMap<String, Object>();
        if(StringUtils.isNotBlank(processDefinitionName))
        {
            processDefinitionName = processDefinitionName.trim();
            processDefinitionName = processDefinitionName.replaceAll("_", "/_");
            processDefinitionName = processDefinitionName.replaceAll("%", "/%");
            processDefinition.setName(processDefinitionName);
        }
        Page<ProcessDefinition> page = new Page<ProcessDefinition>(processDefinition);
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            Map<String, Object> params = new HashMap<String, Object>();
            if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
            {
                if("deploymentTime".equals(sortCol))
                {
                    sortCol = "DEPLOY_TIME_";
                }
                
                params.put("order", sortCol + GeneralConstant.SPACE + order);
                page.setConditions(params);
            }
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        
        page.setPageNo(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_ROWS)));
        page = activitiService.processManageList(page);
        
        map.put(CommonConstant.PAGE_RESULT_ROWS, page.getResults());
        map.put(CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord());
        return map;
    }
    
    /**
     * 部署全部流程
     *
     * @return
     * @throws Exception
     */
    @RequestMapping (value = "/redeploy/all")
    public String redeployAll(@Value ("#{APP_PROPERTIES['export.diagram.path']}") String exportDir) throws Exception
    {
        workflowProcessDefinitionService.deployAllFromClasspath(exportDir);
        return "redirect:/workflow/process-list";
    }
    
    /**
     * 读取资源，通过部署ID
     *
     * @param processDefinitionId 流程定义
     * @param resourceType        资源类型(xml|image)
     * @throws Exception
     */
    @RequestMapping (value = "/resource/read")
    public void loadByDeployment(@RequestParam ("processDefinitionId") String processDefinitionId,
        @RequestParam ("resourceType") String resourceType, HttpServletResponse response) throws Exception
    {
        org.activiti.engine.repository.ProcessDefinition processDefinition =
            repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
        String resourceName = "";
        if(resourceType.equals("image"))
        {
            resourceName = processDefinition.getDiagramResourceName();
        }
        else if(resourceType.equals("xml"))
        {
            resourceName = processDefinition.getResourceName();
            StringBuilder disposition = new StringBuilder().append("attachment; filename=\"");
            disposition.append(resourceName);
            response.setContentType("application/xml");
            response.setHeader("Content-Disposition", disposition.toString());
        }
        InputStream resourceAsStream = repositoryService.getResourceAsStream(processDefinition.getDeploymentId(), resourceName);
        OutputStream out = null;
        byte[] b = new byte[1024];
        int len = -1;
        try
        {
            out = response.getOutputStream();
            while((len = resourceAsStream.read(b, 0, 1024)) != -1)
            {
                out.write(b, 0, len);
            }
            out.flush();
        }
        catch (IOException ex)
        {
            logger.error("流程导出失败", ex);
        }
        finally
        {
            IOUtils.closeQuietly(out);
        }
        
    }
    
    /**
     * 读取资源，通过流程ID
     *
     * @param resourceType      资源类型(xml|image)
     * @param processInstanceId 流程实例ID
     * @param response
     * @throws Exception
     */
    @RequestMapping (value = "/resource/process-instance")
    public void loadByProcessInstance(@RequestParam ("type") String resourceType, @RequestParam ("pid") String processInstanceId,
        HttpServletResponse response) throws Exception
    {
        InputStream resourceAsStream = null;
        org.activiti.engine.runtime.ProcessInstance processInstance =
            runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        org.activiti.engine.repository.ProcessDefinition processDefinition =
            repositoryService.createProcessDefinitionQuery().processDefinitionId(processInstance.getProcessDefinitionId())
                .singleResult();
        
        String resourceName = "";
        if(resourceType.equals("image"))
        {
            resourceName = processDefinition.getDiagramResourceName();
        }
        else if(resourceType.equals("xml"))
        {
            resourceName = processDefinition.getResourceName();
        }
        resourceAsStream = repositoryService.getResourceAsStream(processDefinition.getDeploymentId(), resourceName);
        byte[] b = new byte[1024];
        int len = -1;
        while((len = resourceAsStream.read(b, 0, 1024)) != -1)
        {
            response.getOutputStream().write(b, 0, len);
        }
    }
    
    /**
     * 删除部署的流程，级联删除流程实例
     *
     * @param deploymentId 流程部署ID
     */
    @RequestMapping (value = "/process/delete")
    public String delete(@RequestParam ("deploymentId") String deploymentId)
    {
        repositoryService.deleteDeployment(deploymentId, true);
        return "redirect:/workflow/process-list";
    }
    
    /**
     * 输出跟踪流程信息new 增加appno
     *
     * @param processInstanceId
     * @return
     * @throws Exception
     */
    @RequestMapping (value = "/process/traceNew")
    @ResponseBody
    public Map<String, List<Map<String, Object>>> traceProcess(@RequestParam ("pid") String processInstanceId,
        @RequestParam ("appno") String appNo) throws Exception
    {
        return traceService.traceProcess(processInstanceId, appNo);
    }
    
    /**
     * 输出跟踪流程信息
     *
     * @param processInstanceId
     * @return
     * @throws Exception
     */
    @RequestMapping (value = "/process/trace")
    @ResponseBody
    public Map<String, List<Map<String, Object>>> traceProcess(@RequestParam ("pid") String processInstanceId) throws Exception
    {
        return traceService.traceProcess(processInstanceId);
    }
    
    /**
     * 读取带跟踪的图片
     */
    @RequestMapping (value = "/process/trace/auto/{executionId}")
    public void readResource(@PathVariable ("executionId") String executionId, HttpServletResponse response) throws Exception
    {
        org.activiti.engine.runtime.ProcessInstance processInstance =
            runtimeService.createProcessInstanceQuery().processInstanceId(executionId).singleResult();
        BpmnModel bpmnModel = repositoryService.getBpmnModel(processInstance.getProcessDefinitionId());
        List<String> activeActivityIds = runtimeService.getActiveActivityIds(executionId);
        
        // 使用spring注入引擎请使用下面的这行代码
        processEngineConfiguration = processEngine.getProcessEngineConfiguration();
        Context.setProcessEngineConfiguration((ProcessEngineConfigurationImpl) processEngineConfiguration);
        
        ProcessDiagramGenerator diagramGenerator = processEngineConfiguration.getProcessDiagramGenerator();
        InputStream imageStream =
            diagramGenerator.generateDiagram(bpmnModel, "png", activeActivityIds, null,
                processEngineConfiguration.getActivityFontName(), processEngineConfiguration.getLabelFontName(), null, 1.0);
        
        // 输出资源内容到相应对象
        byte[] b = new byte[1024];
        int len;
        while((len = imageStream.read(b, 0, 1024)) != -1)
        {
            response.getOutputStream().write(b, 0, len);
        }
    }
    
    @RequestMapping (value = "/deploy")
    public String deploy(RedirectAttributes attr, @Value ("#{APP_PROPERTIES['export.diagram.path']}") String exportDir,
        @RequestParam (value = "file", required = false) MultipartFile file)
    {
        
        String fileName = file.getOriginalFilename();
        
        if(GeneralUtils.isNullOrZeroLength(fileName) || !fileName.endsWith("bpmn20.xml"))
        {
            attr.addFlashAttribute("msg",
                JSONObject.toJSON(renderError(super.getProperty("workflow.process-list.tipWorkFlowFile"))));
        }
        else
        {
            try
            {
                InputStream fileInputStream = file.getInputStream();
                Deployment deployment = null;
                
                String extension = FilenameUtils.getExtension(fileName);
                if(extension.equals("zip") || extension.equals("bar"))
                {
                    ZipInputStream zip = new ZipInputStream(fileInputStream);
                    deployment = repositoryService.createDeployment().addZipInputStream(zip).deploy();
                }
                else
                {
                    deployment =
                        repositoryService.createDeployment().name(fileName.replace(".xml", ""))
                            .addInputStream(fileName, fileInputStream).deploy();
                }
                
                List<org.activiti.engine.repository.ProcessDefinition> list =
                    repositoryService.createProcessDefinitionQuery().deploymentId(deployment.getId()).list();
                
                for(org.activiti.engine.repository.ProcessDefinition processDefinition : list)
                {
                    WorkflowUtils.exportDiagramToFile(repositoryService, processDefinition, exportDir);
                }
                
                attr.addFlashAttribute("msg", JSONObject.toJSON(renderSuccess(super.getProperty("oper_success"))));
            }
            catch (Exception e)
            {
                logger.error("error on deploy process, because of file input stream {exportDir:" + exportDir, e);
                attr.addFlashAttribute("msg", JSONObject.toJSON(renderError(super.getProperty("error_system_info"))));
            }
        }
        
        return "redirect:/workflow/process-list";
    }
    
    @RequestMapping (value = "/process/convert-to-model/{processDefinitionId}")
    @ResponseBody
    public Map<String, Object> convertToModel(@PathVariable ("processDefinitionId") String processDefinitionId)
    {
        Map<String, Object> result = new HashMap<String, Object>();
        try
        {
            org.activiti.engine.repository.ProcessDefinition processDefinition =
                repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
            InputStream bpmnStream =
                repositoryService.getResourceAsStream(processDefinition.getDeploymentId(), processDefinition.getResourceName());
            XMLInputFactory xif = XMLInputFactory.newInstance();
            InputStreamReader in = new InputStreamReader(bpmnStream, "UTF-8");
            XMLStreamReader xtr = xif.createXMLStreamReader(in);
            BpmnModel bpmnModel = new BpmnXMLConverter().convertToBpmnModel(xtr);
            
            BpmnJsonConverter converter = new BpmnJsonConverter();
            com.fasterxml.jackson.databind.node.ObjectNode modelNode = converter.convertToJson(bpmnModel);
            Model modelData = repositoryService.newModel();
            modelData.setKey(processDefinition.getKey());
            modelData.setName(processDefinition.getName());
            modelData.setCategory(processDefinition.getDeploymentId());
            
            ObjectNode modelObjectNode = new ObjectMapper().createObjectNode();
            modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, processDefinition.getName());
            modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, 1);
            modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, processDefinition.getDescription());
            modelData.setMetaInfo(modelObjectNode.toString());
            
            repositoryService.saveModel(modelData);
            
            repositoryService.addModelEditorSource(modelData.getId(), modelNode.toString().getBytes("utf-8"));
            
            result.put("message", 1);
            
        }
        catch (Exception e)
        {
            logger.error("转换为模型失败：processDefinitionId={}", processDefinitionId, e);
        }
        return result;
    }
    
    /**
     * 待办任务--Portlet
     */
    @RequestMapping (value = "/task/todo/list")
    @ResponseBody
    public List<Map<String, Object>> todoList(HttpSession session) throws Exception
    {
        User user = UserUtil.getUserFromSession(session);
        List<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm");
        
        // 已经签收的任务
        List<Task> todoList = taskService.createTaskQuery().taskAssignee(user.getId()).active().list();
        for(Task task : todoList)
        {
            String processDefinitionId = task.getProcessDefinitionId();
            org.activiti.engine.repository.ProcessDefinition processDefinition = getProcessDefinition(processDefinitionId);
            
            Map<String, Object> singleTask = packageTaskInfo(sdf, task, processDefinition);
            singleTask.put("status", "todo");
            result.add(singleTask);
        }
        
        // 等待签收的任务
        List<Task> toClaimList = taskService.createTaskQuery().taskCandidateUser(user.getId()).active().list();
        for(Task task : toClaimList)
        {
            String processDefinitionId = task.getProcessDefinitionId();
            org.activiti.engine.repository.ProcessDefinition processDefinition = getProcessDefinition(processDefinitionId);
            
            Map<String, Object> singleTask = packageTaskInfo(sdf, task, processDefinition);
            singleTask.put("status", "claim");
            result.add(singleTask);
        }
        
        return result;
    }
    
    private Map<String, Object> packageTaskInfo(SimpleDateFormat sdf, Task task,
        org.activiti.engine.repository.ProcessDefinition processDefinition)
    {
        Map<String, Object> singleTask = new HashMap<String, Object>();
        singleTask.put("id", task.getId());
        singleTask.put("name", task.getName());
        singleTask.put("createTime", sdf.format(task.getCreateTime()));
        singleTask.put("pdname", processDefinition.getName());
        singleTask.put("pdversion", processDefinition.getVersion());
        singleTask.put("pid", task.getProcessInstanceId());
        return singleTask;
    }
    
    private org.activiti.engine.repository.ProcessDefinition getProcessDefinition(String processDefinitionId)
    {
        org.activiti.engine.repository.ProcessDefinition processDefinition = PROCESS_DEFINITION_CACHE.get(processDefinitionId);
        if(processDefinition == null)
        {
            processDefinition =
                repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
            PROCESS_DEFINITION_CACHE.put(processDefinitionId, processDefinition);
        }
        return processDefinition;
    }
    
    /**
     * 挂起、激活流程实例
     */
    @RequestMapping (value = "processdefinition/update/{state}/{processDefinitionId}")
    public String updateState(@PathVariable ("state") String state,
        @PathVariable ("processDefinitionId") String processDefinitionId, RedirectAttributes redirectAttributes)
    {
        if(state.equals("active"))
        {
            redirectAttributes.addFlashAttribute("message", "已激活ID为[" + processDefinitionId + "]的流程定义。");
            repositoryService.activateProcessDefinitionById(processDefinitionId, true, null);
        }
        else if(state.equals("suspend"))
        {
            repositoryService.suspendProcessDefinitionById(processDefinitionId, true, null);
            redirectAttributes.addFlashAttribute("message", "已挂起ID为[" + processDefinitionId + "]的流程定义。");
        }
        return "redirect:/workflow/process-list";
    }
    
    /**
     * 导出图片文件到硬盘
     *
     * @return
     */
    @RequestMapping (value = "export/diagrams")
    @ResponseBody
    public List<String> exportDiagrams(@Value ("#{APP_PROPERTIES['export.diagram.path']}") String exportDir) throws IOException
    {
        List<String> files = new ArrayList<String>();
        List<org.activiti.engine.repository.ProcessDefinition> list = repositoryService.createProcessDefinitionQuery().list();
        
        for(org.activiti.engine.repository.ProcessDefinition processDefinition : list)
        {
            files.add(WorkflowUtils.exportDiagramToFile(repositoryService, processDefinition, exportDir));
        }
        
        return files;
    }
    
    @RequestMapping (value = "activity/jump")
    @ResponseBody
    public boolean jump(@RequestParam ("executionId") String executionId, @RequestParam ("activityId") String activityId)
    {
        Command<Object> cmd = new JumpActivityCmd(executionId, activityId);
        managementService.executeCommand(cmd);
        return true;
    }
    
    @RequestMapping (value = "bpmn/model/{processDefinitionId}")
    @ResponseBody
    public BpmnModel queryBpmnModel(@PathVariable ("processDefinitionId") String processDefinitionId)
    {
        return repositoryService.getBpmnModel(processDefinitionId);
    }
    
    @Autowired
    public void setWorkflowProcessDefinitionService(WorkflowProcessDefinitionService workflowProcessDefinitionService)
    {
        this.workflowProcessDefinitionService = workflowProcessDefinitionService;
    }
    
    @Autowired
    public void setRepositoryService(RepositoryService repositoryService)
    {
        this.repositoryService = repositoryService;
    }
    
    @Autowired
    public void setRuntimeService(RuntimeService runtimeService)
    {
        this.runtimeService = runtimeService;
    }
    
    @Autowired
    public void setTraceService(WorkflowTraceService traceService)
    {
        this.traceService = traceService;
    }
    
    @Autowired
    public void setTaskService(TaskService taskService)
    {
        this.taskService = taskService;
    }
    
}