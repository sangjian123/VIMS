package com.vms.activiti.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.vms.activiti.entity.oa.Leave;
import com.vms.activiti.model.WorkFlow;
import com.vms.activiti.service.ActivitiFlowService;
import com.vms.activiti.service.LeaveManager;
import com.vms.activiti.service.LeaveWorkflowService;
import com.vms.activiti.util.Page;
import com.vms.activiti.util.PageUtil;
import com.vms.activiti.util.Variable;
import com.vms.controller.BaseController;
import com.vms.model.Organization;
import com.vms.service.UserService;
import com.vms.utils.GeneralUtils;

/**
 * 请假控制器，包含保存、启动流程
 *
 * @author HenryYan
 */
@Controller
@RequestMapping (value = "/oa/leave")
public class LeaveController extends BaseController
{
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    protected LeaveManager leaveManager;
    
    @Autowired
    protected LeaveWorkflowService workflowService;
    
    @Autowired
    protected RuntimeService runtimeService;
    
    @Autowired
    protected TaskService taskService;
    
    @Autowired
    protected ActivitiFlowService activitiFlowService;
    
    @Autowired
    private UserService userService;
    
    /**
     * 任务列表
     *
     * @param
     */
    @RequestMapping (value = "list/task")
    public ModelAndView taskList(HttpSession session, HttpServletRequest request)
    {
        List<WorkFlow> list = activitiFlowService.queryProcessNameByPage();
        //list.add (0, null);
        request.setAttribute("extra", list);
        Organization organization = getOrganization();
        request.setAttribute("organization", organization);
        ModelAndView mav = new ModelAndView("oa/gridHandleList");
        return mav;
    }
    
    /**
     * 网格任务列表
     *
     * @param
     */
    @RequestMapping (value = "list/gridTask")
    public ModelAndView gridHandleList(HttpSession session, HttpServletRequest request)
    {
        List<WorkFlow> list = activitiFlowService.queryProcessNameByPage();
        //list.add (0, null);
        request.setAttribute("extra", list);
        Organization organization = getOrganization();
        request.setAttribute("organization", organization);
        ModelAndView mav = new ModelAndView("oa/gridHandleList");
        return mav;
    }
    
    /**
     * 根据流程名称 id 查询节点名称
     * 
     * 	
     */
    @RequestMapping (value = "list/task/queryStepName")
    public @ResponseBody Object quaryStepName(HttpServletRequest request)
    {
        WorkFlow workFlow = new WorkFlow();
        String processName = request.getParameter("name");
        workFlow.setProcessName(processName);
        List<WorkFlow> list = activitiFlowService.queryStepName(workFlow);
        return list;
    }
    
    /**
     * 查询当前用户的代办事项个数
     */
    @RequestMapping (value = "list/task/totalCount")
    @ResponseBody
    public long totalCountByUser(HttpServletRequest request)
    {
        return workflowService.findTodoTasksCount(super.getUserId());
    }
    
    @RequestMapping (value = "list/task/dataGrid", method = RequestMethod.POST)
    @ResponseBody
    public Object dataGrid(HttpServletRequest request)
    {
        
        Page<WorkFlow> page = new Page<WorkFlow>(PageUtil.PAGE_SIZE);
        int[] pageParams = PageUtil.init(page, request);
        //获取id
        String userId = super.getUserId();
        WorkFlow workFlowQe = new WorkFlow();
        String startUserId = request.getParameter("startUserId");
        if(GeneralUtils.isNotNullOrZeroLength(startUserId))
        {
            workFlowQe.setStartUserId(startUserId.trim());
        }
        String name = request.getParameter("name");
        if(GeneralUtils.isNotNullOrZeroLength(name))
        {
            workFlowQe.setName(name.trim());
        }
        String activityName = request.getParameter("activityName");
        if(GeneralUtils.isNotNullOrZeroLength(activityName))
        {
            workFlowQe.setActivityName(activityName.trim());
        }
        String consNo = request.getParameter("consNo");
        if(GeneralUtils.isNotNullOrZeroLength(consNo))
        {
            workFlowQe.setConsNo(consNo.trim());
        }
        String consName = request.getParameter("consName");
        if(GeneralUtils.isNotNullOrZeroLength(consName))
        {
            workFlowQe.setConsName(consName.trim());
        }
        String processName = request.getParameter("processName");
        if(GeneralUtils.isNotNullOrZeroLength(processName))
        {
            workFlowQe.setProcessName(processName.trim());
        }
        String appNo = request.getParameter("appNo");
        if(GeneralUtils.isNotNullOrZeroLength(appNo))
        {
            appNo = appNo.trim();
        }
        Map<String, Object> map = new HashMap<String, Object>();
        
        List<WorkFlow> list = workflowService.findTodoTasks(userId, page, pageParams, appNo, workFlowQe);
        
        List<Object> objects = new ArrayList<Object>();
        JSONObject object;
        for(WorkFlow wf : list)
        {
            object = new JSONObject();
            object.put("consNo", wf.getConsNo());
            object.put("consName", wf.getConsName());
            object.put("orgName", wf.getOrgName());
            object.put("taskId", wf.getTask().getId());
            object.put("taskName", wf.getTask().getName());
            object.put("taskAssignee", wf.getTask().getAssignee());
            object.put("taskCreateTime", wf.getTask().getCreateTime());
            object.put("taskDefinitionKey", wf.getTask().getTaskDefinitionKey());
            object.put("piId", wf.getProcessInstance().getId());
            object.put("piSuspended", wf.getProcessInstance().isSuspended());
            object.put("piProcessDefinitionId", wf.getProcessInstance().getProcessDefinitionId());
            object.put("processInstanceId", wf.getProcessInstanceId());
            object.put("businessKey", wf.getBusinessKey());
            object.put("appId", wf.getApp_id());
            object.put("appNo", wf.getAppNo());
            object.put("processName", wf.getProcessName());
            object.put("startUserId", wf.getStartUserId());
            object.put("name", wf.getName());
            object.put("version", wf.getVersion());
            object.put("customUrl", wf.getCustomUrl());
            objects.add(object);
        }
        Long cnt = null;
        if(GeneralUtils.isNotNullOrZeroLength(startUserId) || GeneralUtils.isNotNullOrZeroLength(name)
            || GeneralUtils.isNotNullOrZeroLength(activityName) || GeneralUtils.isNotNullOrZeroLength(consNo)
            || GeneralUtils.isNotNullOrZeroLength(consName) || GeneralUtils.isNotNullOrZeroLength(appNo))
        {
            cnt = (long) list.size();
        }
        else
        {
            cnt = workflowService.findTodoTasksCount(userId);
        }
        map.put("rows", objects);
        map.put("total", cnt.intValue());
        return map;
    }
    
    /**
     * 读取运行中的流程实例
     *
     * @return
     */
    @RequestMapping (value = "list/running")
    public String running(HttpServletRequest request, HttpServletResponse response)
    {
        return "/oa/running";
    }
    
    /**
     * 读取运行中的流程实例
     *
     * @return
     */
    @RequestMapping (value = "list/run")
    public @ResponseBody Map<String, Object> runningList(HttpServletRequest request, HttpServletResponse response)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        int pageNo = Integer.parseInt(request.getParameter("page"));
        int pageSize = Integer.parseInt(request.getParameter("rows"));
        
        String appNo = request.getParameter("appNo");
        Page<WorkFlow> pages = new Page<WorkFlow>(pageSize);
        pages.setPageNo(pageNo);
        int[] pageParams = null;
        Map<String, Object> mapWork = workflowService.findRunningProcessInstaces(pages, pageParams, appNo);
        @SuppressWarnings ("unchecked")
        List<WorkFlow> list = (List<WorkFlow>) mapWork.get("list");
        
        List<Object> objects = new ArrayList<Object>();
        JSONObject object;
        for(WorkFlow workFlow : list)
        {
            object = new JSONObject();
            object.put("businessKey", workFlow.getBusinessKey());
            object.put("processInstanceId", workFlow.getProcessInstanceId());
            object.put("piId", workFlow.getProcessInstance().getId());
            object.put("appNo", workFlow.getAppNo());
            object.put("processName", workFlow.getProcessName());
            object.put("name", workFlow.getName());
            object.put("taskName", workFlow.getTask().getName());
            object.put("createTime", workFlow.getTask().getCreateTime());
            object.put("version", workFlow.getVersion());
            object.put("assignee", workFlow.getTask().getAssignee());
            object.put("processDefinitionId", workFlow.getTask().getProcessDefinitionId());
            object.put("suspended", workFlow.getProcessInstance().isSuspended());
            objects.add(object);
        }
        int count = (Integer) mapWork.get("count");
        map.put("rows", objects);
        map.put("total", count);
        return map;
    }
    
    @RequestMapping (value = "list/finished1")
    public @ResponseBody Map<String, Object> finished1(HttpServletRequest request, HttpServletResponse response)
    {
        Page<WorkFlow> page = new Page<WorkFlow>(PageUtil.PAGE_SIZE);
        int[] pageParams = PageUtil.init(page, request);
        
        return workflowService.findFinishedProcessInstaces(pageParams);
    }
    
    /**
     * 读取运行中的流程实例
     *
     * @return
     */
    @RequestMapping (value = "list/finished")
    public String finished(HttpServletRequest request, HttpServletResponse response)
    {
        return "/oa/finished";
    }
    
    /**
     * 签收任务
     */
    @RequestMapping (value = "task/claim/{id}")
    @ResponseBody
    public Object claim(@PathVariable ("id") String taskId)
    {
        //        taskService.claim (taskId, super.getUserId ());
        //        redirectAttributes.addFlashAttribute ("message", "Task claims success");
        //        return new ModelAndView ("redirect:/oa/leave/list/task");
        try
        {
            taskService.claim(taskId, super.getUserId());
            return renderSuccess(getProperty("oper_success"));
        }
        catch (Exception e)
        {
            logger.error("claim task error : ", e);
            return renderError(getProperty("oper_fail"));
        }
    }
    
    /**
     * 指派任务
     */
    @RequestMapping (value = "task/assign")
    @ResponseBody
    public Object assign(HttpServletRequest request, HttpServletResponse response)
    {
        String appId = request.getParameter("appid");//申请编号
        String userId = request.getParameter("userId");//用户id
        String taskId = request.getParameter("taskId");//流程id
        String tprocinstId = request.getParameter("tprocinstId");
        try
        {
            taskService.claim(taskId, userId);
            return renderSuccess(getProperty("oper_success"));
        }
        catch (Exception e)
        {
            logger.error("assign task error : ", e);
            return renderError(getProperty("oper_fail"));
        }
    }
    
    /**
     * 读取详细数据
     *
     * @param id
     * @return
     */
    @RequestMapping (value = "detail/{id}")
    @ResponseBody
    public Leave getLeave(@PathVariable ("id") Long id)
    {
        Leave leave = leaveManager.getLeave(id);
        return leave;
    }
    
    /**
     * 读取详细数据
     *
     * @param id
     * @return
     */
    @RequestMapping (value = "detail-with-vars/{id}/{taskId}")
    @ResponseBody
    public Leave getLeaveWithVars(@PathVariable ("id") Long id, @PathVariable ("taskId") String taskId)
    {
        Leave leave = leaveManager.getLeave(id);
        Map<String, Object> variables = taskService.getVariables(taskId);
        leave.setVariables(variables);
        return leave;
    }
    
    /**
     * 完成任务
     *
     * @param taskId
     * @return
     */
    @RequestMapping (value = "complete/{id}", method = {RequestMethod.POST, RequestMethod.GET })
    @ResponseBody
    public String complete(@PathVariable ("id") String taskId, Variable var)
    {
        try
        {
            Map<String, Object> variables = var.getVariableMap();
            taskService.complete(taskId, variables);
            return "success";
        }
        catch (Exception e)
        {
            logger.error("error on complete task {}, variables={}", new Object[]{taskId, var.getVariableMap(), e });
            return "error";
        }
    }
    
    /**
     * 撤销认领
     */
    @RequestMapping (value = "task/unclaim/{id}")
    @ResponseBody
    public Object unclaim(@PathVariable ("id") String taskId)
    {
        try
        {
            taskService.unclaim(taskId);
            return renderSuccess(getProperty("oper_success"));
        }
        catch (Exception e)
        {
            logger.error("unclaim task error : ", e);
            return renderError(getProperty("oper_fail"));
        }
    }
    
    /**
     * 网格任务列表
     *
     * @param
     */
    @RequestMapping (value = "list/completedWorkList")
    public ModelAndView completedWorkList(HttpSession session, HttpServletRequest request)
    {
        List<WorkFlow> list = activitiFlowService.queryProcessNameByPage();
        //list.add (0, null);
        request.setAttribute("extra", list);
        Organization organization = getOrganization();
        request.setAttribute("organization", organization);
        ModelAndView mav = new ModelAndView("oa/processedWorkList");
        return mav;
    }
}
