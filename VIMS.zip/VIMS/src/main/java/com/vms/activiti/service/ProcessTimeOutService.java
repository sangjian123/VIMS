package com.vms.activiti.service;

import com.vms.activiti.entity.act.ProcessTimeOut;
import com.vms.model.Page;

public interface ProcessTimeOutService
{
    /**
     * 获取超时列表
     * 
     * @param page
     * @return
     */
    Page<ProcessTimeOut> queryProcessTimeOutByPage(Page<ProcessTimeOut> page);
    
    /**
     * 新增修改超时列表
     * 
     * @param processTimeOut
     * @return
     */
    int insertOrEditProcessTimeOut(ProcessTimeOut processTimeOut);
    
    /**
     * 查询超时信息
     * @param id
     * @return
     */
    ProcessTimeOut queryProcessTimeOutById(String id);
    
    String analyseEditContent(ProcessTimeOut old, ProcessTimeOut processTimeOut);
}
