package com.vms.activiti.model;

import java.io.Serializable;

public class ProcActTime implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 5961393262304121822L;
    
    private Long id;
    
    private String procName;
    
    private String procDefId;
    
    private String taskName;
    
    /**
     * 02-正常日,01-工作日
     */
    private String timeType;
    
    private Long dayNum;
    
    public Long getId()
    {
        return id;
    }
    
    public void setId(Long id)
    {
        this.id = id;
    }
    
    public String getProcDefId()
    {
        return procDefId;
    }
    
    public void setProcDefId(String procDefId)
    {
        this.procDefId = procDefId;
    }
    
    public String getTaskName()
    {
        return taskName;
    }
    
    public void setTaskName(String taskName)
    {
        this.taskName = taskName;
    }
    
    public String getTimeType()
    {
        return timeType;
    }
    
    public void setTimeType(String timeType)
    {
        this.timeType = timeType;
    }
    
    public Long getDayNum()
    {
        return dayNum;
    }
    
    public void setDayNum(Long dayNum)
    {
        this.dayNum = dayNum;
    }
    
    public String getProcName()
    {
        return procName;
    }
    
    public void setProcName(String procName)
    {
        this.procName = procName;
    }
    
}
