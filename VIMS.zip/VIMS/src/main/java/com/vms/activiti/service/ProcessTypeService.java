package com.vms.activiti.service;

import java.util.List;

import com.vms.activiti.entity.act.ProcessType;

public interface ProcessTypeService
{
    /**
     * 新增修改超时列表
     * 
     * @param processTimeOut
     * @return
     */
    int editProcessType(ProcessType processType);
    
    /**
     * 新增修改超时列表
     * 
     * @param processTimeOut
     * @return
     */
    int insertProcessType(ProcessType processType);
    
    /**
     * 查询流程类型
     * @param id
     * @return
     */
    ProcessType queryProcessTypeById(String id);
    
    /**
     * 查询流程类型
     * @param processName
     * @return
     */
    ProcessType queryProcessTypeByName(String processName);
    
    List<ProcessType> queryAllProcessType();
    
    String analyseEditContent(ProcessType oldProcessType, ProcessType newProcessType);
    
}
