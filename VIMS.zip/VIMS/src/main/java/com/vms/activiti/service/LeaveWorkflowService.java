package com.vms.activiti.service;

import java.util.List;
import java.util.Map;

import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;

import com.vms.activiti.entity.oa.Leave;
import com.vms.activiti.model.ApplicationInfo;
import com.vms.activiti.model.Ttododet;
import com.vms.activiti.model.WorkFlow;
import com.vms.activiti.util.Page;

/**
 * 请假流程Service
 *
 * @author HenryYan
 */
public interface LeaveWorkflowService
{
    
    /**
     * 启动流程
     *
     * @param entity
     */
    ProcessInstance startWorkflow(Leave entity, Map<String, Object> variables, String flowFlag);
    
    /**
     * 查询待办任务个数
     *
     * @param userId 用户ID
     * @return
     */
    public long findTodoTasksCount(String userId);
    
    /**
     * 查询待办任务
     *
     * @param userId 用户ID
     * @return
     */
    List<WorkFlow> findTodoTasks(String userId, com.vms.activiti.util.Page<WorkFlow> page, int[] pageParams, String appNo,
        WorkFlow workFlowQe);
    
    /**
     * 读取运行中的流程
     *
     * @return
     */
    Map<String, Object> findRunningProcessInstaces(Page<WorkFlow> page, int[] pageParams, String appNo);
    
    /**
     * 读取已结束中的流程
     *
     * @return
     */
    Map<String, Object> findFinishedProcessInstaces(int[] pageParams);
    
    /**
     * 查询流程定义对象
     *
     * @param processDefinitionId 流程定义ID
     * @return
     */
    ProcessDefinition getProcessDefinition(String processDefinitionId);
    
    /**
     * 启动高低压申请流程
     *
     * @param entity
     */
    ProcessInstance startApplyWorkflow(ApplicationInfo applicationInfo, Map<String, Object> variables, String flowFlag);
    
    ProcessInstance startApplyWorkAsset(Ttododet ttododet);
    
    /**
     * 启动MDM防窃电工作流
     * @param appId
     * @param variables
     * @param flowFlag
     * @return
     */
    ProcessInstance startPowerStealWorkflow(Long appId, Map<String, Object> variables, String flowFlag);
    
}
