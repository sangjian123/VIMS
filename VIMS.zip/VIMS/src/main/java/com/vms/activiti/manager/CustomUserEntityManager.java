package com.vms.activiti.manager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.activiti.engine.identity.Group;
import org.activiti.engine.identity.User;
import org.activiti.engine.impl.Page;
import org.activiti.engine.impl.UserQueryImpl;
import org.activiti.engine.impl.persistence.entity.GroupEntity;
import org.activiti.engine.impl.persistence.entity.IdentityInfoEntity;
import org.activiti.engine.impl.persistence.entity.UserEntity;
import org.activiti.engine.impl.persistence.entity.UserEntityManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.vms.mapper.RoleMapper;
import com.vms.mapper.UserMapper;
import com.vms.model.Role;
import com.vms.utils.AesKeyUtils;
import com.vms.utils.PropertiesReader;

public class CustomUserEntityManager extends UserEntityManager
{
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    private RoleMapper roleMapper;
    
    @Autowired
    private UserMapper userMapper;
    
    @Override
    public User findUserById(String userId)
    {
        User user = null;
        if(StringUtils.isNotBlank(userId))
        {
            com.vms.model.User userInfo = userMapper.findUserById(userId);
            if(null != userInfo)
            {
                user = buildUserEntity(userInfo);
            }
        }
        if(null == user)
        {
            logger.info("用户名:" + userId + ";无法获取用户信息");
        }
        return user;
    }
    
    @Override
    public List<Group> findGroupsByUser(String userId)
    {
        List<Group> list = null;
        if(StringUtils.isNotBlank(userId))
        {
            List<Role> roles = roleMapper.findRoleByUserId(userId);
            Group group;
            if(!CollectionUtils.isEmpty(roles))
            {
                list = new ArrayList<Group>();
                for(Role role : roles)
                {
                    group = new GroupEntity();
                    group.setId(role.getId().toString());
                    group.setName(role.getName());
                    group.setType("assignment");
                    list.add(group);
                }
            }
        }
        if(CollectionUtils.isEmpty(list))
        {
            logger.info("用户名:" + userId + ";无法获取角色权限信息");
        }
        return list;
    }
    
    @Override
    public Boolean checkPassword(String userId, String password)
    {
        User user = findUserById(userId);
        if(user != null && password != null)
        {
            try
            {
                password = AesKeyUtils.encrypt(password, PropertiesReader.getUserPwdKey());
            }
            catch (IOException e)
            {
                logger.error("activiti password change error :" + password, e);
            }
            if(password.equals(user.getPassword()))
            {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public long findUserCountByQueryCriteria(UserQueryImpl query)
    {
        
        return userMapper.countLongUser();
    }
    
    @Override
    public List<User> findUserByQueryCriteria(UserQueryImpl query, Page page)
    {
        List<com.vms.model.User> users = new ArrayList<com.vms.model.User>();
        if(null != page)
        {
            com.vms.model.Page p = new com.vms.model.Page();
            p.setPageNo(page.getFirstResult());
            p.setPageSize(page.getMaxResults());
            p.setCalcIndex(false);
            users = userMapper.findSysUserByPage(p);
        }
        else if(null != query)
        {
            if(StringUtils.isNotBlank(query.getId()))
            {
                try
                {
                    com.vms.model.User user = userMapper.findUserById(query.getId());
                    users.add(user);
                }
                catch (NumberFormatException ne)
                {
                    super.findUserByQueryCriteria(query, page);
                }
            }
        }
        return changeToUserList(users);
    }
    
    @Override
    public List<User> findPotentialStarterUsers(String proceDefId)
    {
        return super.findPotentialStarterUsers(proceDefId);
    }
    
    @Override
    public List<User> findUsersByNativeQuery(Map<String, Object> parameterMap, int firstResult, int maxResults)
    {
        return super.findUsersByNativeQuery(parameterMap, firstResult, maxResults);
    }
    
    @Override
    public long findUserCountByNativeQuery(Map<String, Object> parameterMap)
    {
        return super.findUserCountByNativeQuery(parameterMap);
    }
    
    @Override
    public IdentityInfoEntity findUserInfoByUserIdAndKey(String userId, String key)
    {
        return super.findUserInfoByUserIdAndKey(userId, key);
    }
    
    @Override
    public List<String> findUserInfoKeysByUserIdAndType(String userId, String type)
    {
        return super.findUserInfoKeysByUserIdAndType(userId, type);
    }
    
    private List<User> changeToUserList(List<com.vms.model.User> users)
    {
        List<User> results = new ArrayList<User>();
        if(!CollectionUtils.isEmpty(users))
        {
            for(com.vms.model.User u : users)
            {
                results.add(buildUserEntity(u));
            }
        }
        return results;
    }
    
    private User buildUserEntity(com.vms.model.User u)
    {
        User user = new UserEntity();
        user.setId(u.getId().toString());
        user.setFirstName(u.getLoginname());
        user.setLastName(u.getNickName());
        user.setPassword(u.getPassword());
        user.setEmail("");
        return user;
    }
}
