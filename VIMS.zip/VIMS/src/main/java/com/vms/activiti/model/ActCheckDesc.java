package com.vms.activiti.model;

import java.io.Serializable;

public class ActCheckDesc implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -7972350954334746162L;
    
    /**
     * id
     */
    private String id;
    
    /**
     * 流程实例id
     */
    private String procInstId;
    
    /**
     * 环节id
     */
    private String stepId;
    
    /**
     * 描述
     */
    private String actDesc;
    
    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }
    
    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }
    
    /**
     * @return the procInstId
     */
    public String getProcInstId()
    {
        return procInstId;
    }
    
    /**
     * @param procInstId the procInstId to set
     */
    public void setProcInstId(String procInstId)
    {
        this.procInstId = procInstId;
    }
    
    /**
     * @return the stepId
     */
    public String getStepId()
    {
        return stepId;
    }
    
    /**
     * @param stepId the stepId to set
     */
    public void setStepId(String stepId)
    {
        this.stepId = stepId;
    }
    
    /**
     * @return the actDesc
     */
    public String getActDesc()
    {
        return actDesc;
    }
    
    /**
     * @param actDesc the actDesc to set
     */
    public void setActDesc(String actDesc)
    {
        this.actDesc = actDesc;
    }
    
}
