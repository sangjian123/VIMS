package com.vms.activiti.service;

import com.vms.activiti.entity.oa.Leave;

/**
 * 请假实体管理
 *
 * @author HenryYan
 */
public interface LeaveManager
{
    
    public Leave getLeave(Long id);
    
    public void saveLeave(Leave entity);
    
}
