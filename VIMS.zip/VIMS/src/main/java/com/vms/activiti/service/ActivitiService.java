package com.vms.activiti.service;

import com.vms.activiti.entity.act.ProcessDefinition;
import com.vms.model.Page;

/**
 * 创建工作流service，丰富act包中缺少的func
 * @author lucheng
 *
 */
public interface ActivitiService
{
    
    /**
     * 流程管理查询列表
     * @param page
     * @return
     */
    public Page<ProcessDefinition> processManageList(Page<ProcessDefinition> page);
    
}
