package com.vms.activiti.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vms.activiti.entity.act.ProcessDefinition;
import com.vms.activiti.mapper.activitiFlowMapper;
import com.vms.activiti.service.ActivitiService;
import com.vms.model.Page;

@Service
@Transactional
public class ActivitiServiceImpl implements ActivitiService
{
    @Autowired
    private activitiFlowMapper activitiFlowMapper;
    
    @Override
    public Page<ProcessDefinition> processManageList(Page<ProcessDefinition> page)
    {
        List<ProcessDefinition> processList = activitiFlowMapper.processManageList(page);
        page.setResults(processList);
        return page;
    }
    
}
