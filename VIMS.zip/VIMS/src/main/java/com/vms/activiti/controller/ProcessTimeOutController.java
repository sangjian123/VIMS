package com.vms.activiti.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.activiti.entity.act.ProcessTimeOut;
import com.vms.activiti.service.ProcessTimeOutService;
import com.vms.constant.CommonConstant;
import com.vms.controller.BaseController;
import com.vms.model.Page;

@Controller
@RequestMapping ("/processTimeOut")
public class ProcessTimeOutController extends BaseController
{
    @Autowired
    private ProcessTimeOutService processTimeOutService;
    
    @RequestMapping ("")
    public String index(HttpServletRequest request)
    {
        request.setAttribute("procDefId", request.getParameter("procDefId"));
        request.setAttribute("procName", request.getParameter("procName"));
        return "/workflow/process-timeout";
    }
    
    @RequestMapping ("/query")
    @ResponseBody
    public Map<String, Object> queryProcessTimeOutByPage(ProcessTimeOut processTimeOut, HttpServletRequest request)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        Page<ProcessTimeOut> page = new Page<ProcessTimeOut>(processTimeOut);
        page.setPageNo(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_PAGE)));
        page.setPageSize(NumberUtils.toInt(request.getParameter(CommonConstant.PAGE_PARAM_ROWS)));
        
        page = processTimeOutService.queryProcessTimeOutByPage(page);
        map.put(CommonConstant.PAGE_RESULT_ROWS, page.getResults());
        map.put(CommonConstant.PAGE_RESULT_TOTAL, page.getTotalRecord());
        
        return map;
    }
    
    @RequestMapping ("/insertOrEditProcessTimeOut")
    @ResponseBody
    public Object addOrUpdateProcessTimeOut(ProcessTimeOut processTimeOut)
    {
        ProcessTimeOut old = null;
        if(processTimeOut.getId() == null || processTimeOut.getId().length() <= 0)
        {
            
        }
        else
        {
            old = processTimeOutService.queryProcessTimeOutById(processTimeOut.getId());
        }
        
        int rt = processTimeOutService.insertOrEditProcessTimeOut(processTimeOut);
        
        if(rt == 0)
        {
            return renderError(processTimeOut.getTaskName());
        }
        else
        {
            return renderSuccess(super.getProperty("oper_success"));
        }
    }
    
}
