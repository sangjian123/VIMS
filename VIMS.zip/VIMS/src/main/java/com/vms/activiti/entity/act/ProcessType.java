package com.vms.activiti.entity.act;

import java.io.Serializable;

public class ProcessType implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -5644736130749901702L;
    
    private String id;
    
    private String procName;
    
    //0-新增 1-变更 2-销户 3-其他
    private String procType;
    
    public String getId()
    {
        return id;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public String getProcName()
    {
        return procName;
    }
    
    public void setProcName(String procName)
    {
        this.procName = procName;
    }
    
    public String getProcType()
    {
        return procType;
    }
    
    public void setProcType(String procType)
    {
        this.procType = procType;
    }
    
}
