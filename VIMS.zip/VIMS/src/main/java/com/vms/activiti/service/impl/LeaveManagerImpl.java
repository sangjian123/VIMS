package com.vms.activiti.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vms.activiti.dao.LeaveDao;
import com.vms.activiti.entity.oa.Leave;
import com.vms.activiti.service.LeaveManager;

/**
 * 请假实体管理
 *
 * @author HenryYan
 */
@Service ("leaveManager")
@Transactional (readOnly = true)
public class LeaveManagerImpl implements LeaveManager
{
    
    private LeaveDao leaveDao;
    
    @Override
    public Leave getLeave(Long id)
    {
        return leaveDao.findOne(id);
    }
    
    @Transactional (readOnly = false)
    @Override
    public void saveLeave(Leave entity)
    {
        if(entity.getId() == null)
        {
            entity.setApplyTime(new Date());
        }
        leaveDao.save(entity);
    }
    
    @Autowired
    public void setLeaveDao(LeaveDao leaveDao)
    {
        this.leaveDao = leaveDao;
    }
    
}
