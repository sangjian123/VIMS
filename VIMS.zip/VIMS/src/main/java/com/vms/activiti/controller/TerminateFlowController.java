package com.vms.activiti.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.activiti.engine.RuntimeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.vms.activiti.service.ActivitiFlowService;
import com.vms.controller.BaseController;
import com.vms.model.User;
import com.vms.utils.FlowTypeUtils;

/**
 * 终止流程控制器
 *
 * @author HenryYan
 */
@Controller
@RequestMapping (value = "/terminateFlow")
public class TerminateFlowController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger(TerminateFlowController.class);
    
    @Autowired
    private RuntimeService runtimeService;
    
    @Autowired
    protected ActivitiFlowService activitiFlowService;
    
    /**
     * 终止流程
     */
    @RequestMapping ("/updateTaskToEnd")
    @ResponseBody
    public Object updateTaskToEnd(HttpServletRequest request)
    {
        String appId = request.getParameter("appId");
        String appNo = request.getParameter("appNo");
        String procDefId = request.getParameter("procDefId");
        //流程名
        String flowName = request.getParameter("flowName");
        //环节名
        String actName = request.getParameter("actName");
        //终止原因
        String stopReason = request.getParameter("stopReason");
        try
        {
            Map<String, Object> map = activitiFlowService.findTerminateStatus(Long.valueOf(appId));
            
            //0:正常，1:已经收取业务费，2:已经装表，3:已经拆表，4:已经生成账单，5：已收保证金，6：已退保证金
            if("1".equals(map.get("msg")))
            {
                return renderError(getProperty("workflow.running-manage.charged"));
            }
            else if("2".equals(map.get("msg")))
            {
                return renderError(getProperty("workflow.running-manage.installed"));
            }
            else if("3".equals(map.get("msg")))
            {
                return renderError(getProperty("workflow.running-manage.removed"));
            }
            else if("4".equals(map.get("msg")))
            {
                return renderError(getProperty("workflow.running-manage.generated"));
            }
            else if("5".equals(map.get("msg")))
            {
                return renderError(getProperty("workflow.running-manage.deposit1") + "&amt=" + map.get("amt"));
            }
            else if("6".equals(map.get("msg")))
            {
                return renderError(getProperty("workflow.running-manage.deposit2"));
            }
            //            runtimeService.suspendProcessInstanceById (procDefId);
            //            activitiFlowService.updateTaskStatus (Long.valueOf (appId), "04");
            if(StringUtils.isEmpty(stopReason))
            {
                User user = getCurrentUser();
                stopReason = user == null ? "" : user.getLoginname() + " terminate app:" + appId;
            }
            if(FlowTypeUtils.isCrmFlow(flowName))
            {
                
                runtimeService.deleteProcessInstance(procDefId, stopReason);
                
            }
            else
            {
                runtimeService.deleteProcessInstance(procDefId, stopReason);
            }
        }
        catch (Exception e)
        {
            LOGGER.error("stop flow task error : ", e);
            return renderError(getProperty("oper_fail"));
        }
        
        if("".equals(flowName))
        {
            if("".equals(actName))
            {
                // 流程终止-业务数据处理
                
            }
        }
        return renderSuccess(getProperty("oper_success"));
    }
    
}