package com.vms.activiti.model;

import java.io.Serializable;

public class ProcessTree implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = -2589701425998029402L;
    
    private String id;
    
    private String pid;
    
    private String text;
    
    /**
     * @return the id
     */
    public String getId()
    {
        return id;
    }
    
    /**
     * @param id the id to set
     */
    public void setId(String id)
    {
        this.id = id;
    }
    
    /**
     * @return the pid
     */
    public String getPid()
    {
        return pid;
    }
    
    /**
     * @param pid the pid to set
     */
    public void setPid(String pid)
    {
        this.pid = pid;
    }
    
    /**
     * @return the text
     */
    public String getText()
    {
        return text;
    }
    
    /**
     * @param text the text to set
     */
    public void setText(String text)
    {
        this.text = text;
    }
    
}
