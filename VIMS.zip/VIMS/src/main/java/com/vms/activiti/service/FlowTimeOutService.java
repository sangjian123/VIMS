package com.vms.activiti.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.vms.activiti.model.ActHiTaskinst;
import com.vms.activiti.model.ProcActTime;
import com.vms.activiti.model.RunActTime;
import com.vms.activiti.model.WorkCalendar;

public interface FlowTimeOutService
{
    /**
     * 检验超时状态
     * @param dayList
     * @param actTime
     * @param act
     * @param dayNum
     * @param spaceNum
     * @param runActTime
     * @return
     */
    String checkActTimeOutStatus(List<WorkCalendar> dayList, ProcActTime actTime, ActHiTaskinst act, long dayNum, long spaceNum,
        RunActTime runActTime);
    
    /**
     * 查询结束日期
     * @param dayList
     * @param startTime
     * @param dayNum
     * @return
     */
    Date findEndDay(List<WorkCalendar> dayList, Date startTime, long dayNum);
    
    /**
     * 查询超时设置
     * @param actTimeList
     * @param act
     * @return
     */
    ProcActTime findActTime(List<ProcActTime> actTimeList, ActHiTaskinst act);
    
    /**
     * 判断是否更新
     * @param existMap
     * @param temp
     * @return
     */
    boolean checkUpdate(Map<String, RunActTime> existMap, RunActTime temp);
    
    /**
     * 过滤已存在记录
     * @param existList
     * @param upList
     */
    void filterExistList(List<RunActTime> existList, List<RunActTime> upList);
    
    /**
     * 分析更新记录
     * @param existList
     * @param msgList
     * @param status
     * @return
     */
    List<RunActTime> filterAndGetUpList(List<RunActTime> existList, List<RunActTime> msgList, String status);
    
    /**
     * 设置属性
     * @param act
     * @param msg
     */
    void copyProperties(ActHiTaskinst act, RunActTime msg);
    
}
