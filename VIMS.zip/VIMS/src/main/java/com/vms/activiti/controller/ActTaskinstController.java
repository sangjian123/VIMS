package com.vms.activiti.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.activiti.engine.FormService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.activiti.entity.act.ProcessType;
import com.vms.activiti.model.ActHiTaskinst;
import com.vms.activiti.service.ActHiTaskinstService;
import com.vms.activiti.service.ActivitiFlowService;
import com.vms.activiti.service.ProcessTypeService;
import com.vms.constant.CommonConstant;
import com.vms.constant.ConstantCode;
import com.vms.constant.GeneralConstant;
import com.vms.controller.BaseController;
import com.vms.model.Page;
import com.vms.model.Tree;
import com.vms.model.User;
import com.vms.utils.RedisCacheUtil;
import com.vms.utils.UUIDUtils;

@Scope ("prototype")
@Controller
@RequestMapping ("/actTaskinst")
public class ActTaskinstController extends BaseController
{
    
    @Autowired
    private ActHiTaskinstService actHiTaskinstService;
    
    @Autowired
    private FormService formService;
    
    @Autowired
    protected ActivitiFlowService activitiFlowService;
    
    private RedisCacheUtil redisCacheUtil = new RedisCacheUtil();
    
    @Autowired
    private ProcessTypeService processTypeService;
    
    @RequestMapping ("/actTaskinstList")
    @ResponseBody
    public Map<String, Object> lineLosslist(ActHiTaskinst actHiTaskinst, HttpServletRequest request)
    {
        User user = getCurrentUser();
        actHiTaskinst.setApplyState("1");
        actHiTaskinst.setSuspensionState("1");
        //        actHiTaskinst.setUserId (user.getName ());
        actHiTaskinst.setUserId(user.getId());
        //		if(actHiTaskinst.getPsOrgNo() == null ){
        //			actHiTaskinst.setPsOrgNo(super.getOrganization().getOrgNo());
        //		}
        //模糊查询 consName  startUserId
        if(StringUtils.isNotBlank(actHiTaskinst.getConsName()))
        {
            String consName = actHiTaskinst.getConsName();
            consName = consName.trim();
            consName = consName.replaceAll("_", "/_");
            consName = consName.replaceAll("%", "/%");
            actHiTaskinst.setConsName(consName);
        }
        
        if(StringUtils.isNotBlank(actHiTaskinst.getStartUserId()))
        {
            String startUserId = actHiTaskinst.getStartUserId();
            startUserId = startUserId.trim();
            startUserId = startUserId.replaceAll("_", "/_");
            startUserId = startUserId.replaceAll("%", "/%");
            actHiTaskinst.setStartUserId(startUserId);
        }
        if(StringUtils.isNotBlank(actHiTaskinst.getTaskStatus()))
        {
            if(ConstantCode.STRING_1.equals(actHiTaskinst.getTaskStatus()))
            {
                actHiTaskinst.setTaskStatus(ConstantCode.STRING_03);
            }
            else
            {
                actHiTaskinst.setTaskStatus(null);
            }
        }
        Page<ActHiTaskinst> page = new Page<ActHiTaskinst>(actHiTaskinst);
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            if("handleTime".equals(sortCol))
            {
                sortCol = "HANDLE_TIME";
            }
            else if("lastCompTime".equals(sortCol))
            {
                sortCol = "LAST_COMP_TIME";
            }
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        try
        {
            page.setPageNo(getCurrentPage(request));
            page.setPageSize(getPageSize(request));
            page = actHiTaskinstService.findgActHiTaskinstByPage(page);
            //获取到自定义表单的url
            List<ActHiTaskinst> noTimes = fillFormKey(page);
            if(noTimes.size() > 0)
            {
                actHiTaskinstService.findCompTimeByList(noTimes);
            }
            return ajaxResult(page, true);
        }
        catch (Exception e)
        {
            logger.error("lineLosslist method has error " + e);
            return ajaxResult(null, false);
        }
        
    }
    
    @RequestMapping ("/waitHandleList")
    @ResponseBody
    public Map<String, Object> waitHandleList(ActHiTaskinst actHiTaskinst, HttpServletRequest request)
    {
        Page<ActHiTaskinst> page = queryTaskInit(actHiTaskinst, request);
        try
        {
            page.setPageNo(getCurrentPage(request));
            page.setPageSize(getPageSize(request));
            page = actHiTaskinstService.findWaitHandleByPage(page);
            //获取到自定义表单的url
            List<ActHiTaskinst> noTimes = fillFormKey(page);
            if(noTimes.size() > 0)
            {
                actHiTaskinstService.findCompTimeByList(noTimes);
            }
            return ajaxResult(page, true);
        }
        catch (Exception e)
        {
            logger.error("lineLosslist method has error " + e);
            return ajaxResult(null, false);
        }
    }
    
    @RequestMapping ("/gridHandleList")
    @ResponseBody
    public Map<String, Object> gridHandleList(ActHiTaskinst actHiTaskinst, HttpServletRequest request)
    {
        Page<ActHiTaskinst> page = queryTaskInit(actHiTaskinst, request);
        try
        {
            page.setPageNo(getCurrentPage(request));
            page.setPageSize(getPageSize(request));
            page = actHiTaskinstService.findGridHandleByPage(page);
            List<ActHiTaskinst> noTimes = fillFormKey(page);
            if(noTimes.size() > 0)
            {
                actHiTaskinstService.findCompTimeByList(noTimes);
            }
            return ajaxResult(page, true);
        }
        catch (Exception e)
        {
            logger.error("lineLosslist method has error " + e);
            return ajaxResult(null, false);
        }
    }
    
    private List<ActHiTaskinst> fillFormKey(Page<ActHiTaskinst> page)
    {
        List<ActHiTaskinst> noTimeList = new ArrayList<ActHiTaskinst>();
        List<ActHiTaskinst> results = page.getResults();
        if(CollectionUtils.isNotEmpty(results))
        {
            //获取到自定义表单的url
            for(ActHiTaskinst act : results)
            {
                if(act.getLastCompTime() == null)
                {
                    noTimeList.add(act);
                }
                try
                {
                    String customUrl = formService.getTaskFormData(act.getTaskId()).getFormKey();
                    logger.info("============================{}", customUrl);
                    act.setCustomUrl(customUrl);
                }
                catch (Exception e)
                {
                    logger.error("Activity getTaskFormData error " + e);
                }
            }
        }
        return noTimeList;
    }
    
    private Page<ActHiTaskinst> queryTaskInit(ActHiTaskinst actHiTaskinst, HttpServletRequest request)
    {
        User user = getCurrentUser();
        actHiTaskinst.setApplyState("1");
        actHiTaskinst.setSuspensionState("1");
        actHiTaskinst.setUserId(user.getId());
        //      if(actHiTaskinst.getPsOrgNo() == null ){
        //          actHiTaskinst.setPsOrgNo(super.getOrganization().getOrgNo());
        //      }
        //模糊查询 consName  startUserId
        if(StringUtils.isNotBlank(actHiTaskinst.getConsName()))
        {
            String consName = actHiTaskinst.getConsName();
            consName = consName.trim();
            consName = consName.replaceAll("_", "/_");
            consName = consName.replaceAll("%", "/%");
            actHiTaskinst.setConsName(consName);
        }
        
        if(StringUtils.isNotBlank(actHiTaskinst.getStartUserId()))
        {
            String startUserId = actHiTaskinst.getStartUserId();
            startUserId = startUserId.trim();
            startUserId = startUserId.replaceAll("_", "/_");
            startUserId = startUserId.replaceAll("%", "/%");
            actHiTaskinst.setStartUserId(startUserId);
        }
        if(StringUtils.isNotBlank(actHiTaskinst.getTaskStatus()))
        {
            if(ConstantCode.STRING_1.equals(actHiTaskinst.getTaskStatus()))
            {
                actHiTaskinst.setTaskStatus(ConstantCode.STRING_03);
            }
            else
            {
                actHiTaskinst.setTaskStatus(null);
            }
        }
        Page<ActHiTaskinst> page = new Page<ActHiTaskinst>(actHiTaskinst);
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            if("handleTime".equals(sortCol))
            {
                sortCol = "HANDLE_TIME";
            }
            else if("lastCompTime".equals(sortCol))
            {
                sortCol = "LAST_COMP_TIME";
            }
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        return page;
    }
    
    @RequestMapping ("/homeTop5List")
    @ResponseBody
    public Map<String, Object> homeTop5list(ActHiTaskinst actHiTaskinst, HttpServletRequest request)
    {
        User user = getCurrentUser();
        actHiTaskinst.setApplyState("1");
        actHiTaskinst.setSuspensionState("1");
        //        actHiTaskinst.setUserId (user.getName ());
        actHiTaskinst.setUserId(user.getId());
        
        @SuppressWarnings ("unchecked")
        Set<String> urlList = (Set<String>) redisCacheUtil.getDataFromRedis(user.getLoginname());
        
        Page<ActHiTaskinst> page = new Page<ActHiTaskinst>(actHiTaskinst);
        try
        {
            page.setPageNo(1);
            page.setPageSize(5);
            //包含待办事项权限的  才统计
            if(CollectionUtils.isNotEmpty(urlList) && urlList.contains("/oa/leave/list/gridTask"))
            {
                page = actHiTaskinstService.findgActHiTaskinstTop5ByPage(page);
            }
            else
            {
                page.setResults(null);
            }
            List<ActHiTaskinst> results = page.getResults();
            //获取到自定义表单的url
            for(int i = 0; i < results.size(); i++)
            {
                String customUrl = formService.getTaskFormData(results.get(i).getTaskId()).getFormKey();
                results.get(i).setCustomUrl(customUrl);
            }
            return ajaxResult(page, true);
        }
        catch (Exception e)
        {
            logger.error("lineLosslist method has error " + e);
            return ajaxResult(null, false);
        }
        
    }
    
    /**
     * 待办导航树
     *
     * @return
     */
    @RequestMapping ("/findTaskTypeTree")
    @ResponseBody
    public Object findTaskTypeTree(HttpServletRequest request)
    {
        List<Tree> treeList = new ArrayList<Tree>();
        Set<String> existSet = new HashSet<String>();
        
        List<ProcessType> processTypeList = processTypeService.queryAllProcessType();
        
        Tree tree = new Tree();
        //新增
        Long addId = UUIDUtils.generate16Long();
        tree.setId(addId);
        tree.setText(super.getProperty("home_task_add"));
        tree.setName(super.getProperty("home_task_add"));
        tree.setPid("1");
        treeList.add(tree);
        
        //变更
        tree = new Tree();
        Long modifyId = UUIDUtils.generate16Long();
        tree.setId(modifyId);
        tree.setText(super.getProperty("home_task_change"));
        tree.setName(super.getProperty("home_task_change"));
        tree.setPid("1");
        treeList.add(tree);
        
        //改类 销户
        tree = new Tree();
        Long canelId = UUIDUtils.generate16Long();
        tree.setId(canelId);
        tree.setText(super.getProperty("home_task_canel"));
        tree.setName(super.getProperty("home_task_canel"));
        tree.setPid("1");
        treeList.add(tree);
        
        //其他
        tree = new Tree();
        Long otherId = UUIDUtils.generate16Long();
        tree.setId(otherId);
        tree.setText(super.getProperty("home_task_other"));
        tree.setName(super.getProperty("home_task_other"));
        tree.setPid("1");
        treeList.add(tree);
        
        return treeList;
    }
    
}
