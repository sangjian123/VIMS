package com.vms.activiti.service;

import java.util.List;
import java.util.Map;

import com.vms.activiti.model.ActCheckDesc;
import com.vms.activiti.model.ActHiTaskinst;
import com.vms.model.Page;

/**
 * Service
 *
 * @author liuchang	
 */
public interface ActHiTaskinstService
{
    
    /**
     * 查询历史任务实例表
     * act_hi_taskinst
     * 	liuchang
     */
    Page<ActHiTaskinst> findgActHiTaskinstByPage(Page<ActHiTaskinst> page);
    
    /**
     * 查询 历史任务实例表
     * act_hi_taskinst
     * 	liuchang
     */
    Page<ActHiTaskinst> findTaskinstByPage(Page<ActHiTaskinst> page);
    
    /**
     * 所有流程名称
     * ACT_RE_PROCDEF
     * 	liuchang
     */
    List<ActHiTaskinst> quaryPnameByPage();
    
    /**
     * 根据流程名称 id 查询节点名称
     * 
     * 	liuchang
     */
    List<ActHiTaskinst> quaryName(ActHiTaskinst actHiTaskinst);
    
    Page<ActHiTaskinst> findgActHiTaskinstTop5ByPage(Page<ActHiTaskinst> page);
    
    Integer findTaskCount(Map<String, Object> map);
    
    Integer findTaskCountAll(Map<String, Object> map);
    
    /**
     * 查询代办任务
     * ActHiTaskinst
     * tfl
     */
    Page<ActHiTaskinst> findWaitHandleByPage(Page<ActHiTaskinst> page);
    
    /**
     * 查询网格代办任务
     * ActHiTaskinst
     * tfl
     */
    Page<ActHiTaskinst> findGridHandleByPage(Page<ActHiTaskinst> page);
    
    /**
     * app端查询代办
     * @param actHiTaskinst
     * @return
     */
    List<ActHiTaskinst> findgActHiTaskinstForApp(ActHiTaskinst actHiTaskinst);
    
    /**
     * 补充完成时间
     * ActHiTaskinst集合
     * tfl
     */
    void findCompTimeByList(List<ActHiTaskinst> noTimeList);
    
    /**
     * 新增环节操作备注
     * 
     * @param ActCheckDesc actCheckDesc
     * @return int
     */
    int insertActDesc(ActCheckDesc actCheckDesc);
    
    /**
     * 查询部门下未归档工单个数
     * @param deptId
     * @return
     */
    int findActHiTaskinstByDeptId(String deptId);
    
    Page<ActHiTaskinst> processedActHiTaskinstByPage(Page<ActHiTaskinst> page);
}
