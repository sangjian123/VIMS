package com.vms.activiti.controller;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.activiti.mapper.FlowTraceMapper;
import com.vms.activiti.service.WorkflowTraceService;

/**
 * 流程轨迹查看
 *
 * @author tfl
 */
@Controller
@RequestMapping (value = "/flowTrace")
public class FlowTraceController
{
    
    protected Logger logger = LoggerFactory.getLogger(getClass());
    
    protected RepositoryService repositoryService;
    
    protected WorkflowTraceService traceService;
    
    @Autowired
    private FlowTraceMapper flowTraceMapper;
    
    /**
     * 读取资源，通过流程ID
     *
     * @param resourceType
     *            资源类型(xml|image)
     * @param processInstanceId
     *            流程实例ID
     * @param response
     * @throws Exception
     */
    @RequestMapping (value = "/processResource")
    public void loadByProcessInstance(@RequestParam ("type") String resourceType, @RequestParam ("bsKey") String businessKey,
        @RequestParam ("flag") String flagValue, HttpServletResponse response)
    {
        if(StringUtils.isBlank(businessKey))
        {
            logger.info("流程轨迹查看，请求参数为空");
            return;
        }
        Map<String, String> idsMap = null;
        if("run".equals(flagValue))
        {
            idsMap = flowTraceMapper.queryRunFlowIds(businessKey);
        }
        else
        {
            idsMap = flowTraceMapper.queryHiFlowIds(businessKey);
        }
        if(!CollectionUtils.isEmpty(idsMap) && StringUtils.isNotBlank(idsMap.get("PROCINSTID")))
        {
            response.setCharacterEncoding("UTF-8");
            InputStream resourceAsStream = null;
            ProcessDefinition processDefinition =
                repositoryService.createProcessDefinitionQuery().processDefinitionId(idsMap.get("PROCDEFID")).singleResult();
            
            String resourceName = "";
            if(resourceType.equals("image"))
            {
                resourceName = processDefinition.getDiagramResourceName();
            }
            else if(resourceType.equals("xml"))
            {
                resourceName = processDefinition.getResourceName();
            }
            resourceAsStream = repositoryService.getResourceAsStream(processDefinition.getDeploymentId(), resourceName);
            byte[] b = new byte[1024];
            int len = -1;
            try
            {
                while((len = resourceAsStream.read(b, 0, 1024)) != -1)
                {
                    response.getOutputStream().write(b, 0, len);
                }
            }
            catch (Exception e)
            {
                logger.error("loadByProcessInstance error : ", e);
            }
        }
    }
    
    /**
     * 输出跟踪流程信息
     *
     * @param processInstanceId
     * @return
     * @throws Exception
     */
    @RequestMapping (value = "/processTrace")
    @ResponseBody
    public Map<String, List<Map<String, Object>>> traceProcess(@RequestParam ("bsKey") String businessKey,
        @RequestParam ("flag") String flagValue)
    {
        Map<String, List<Map<String, Object>>> result = null;
        if(StringUtils.isBlank(businessKey))
        {
            logger.info("流程轨迹查看，请求参数为空");
            return result;
        }
        Map<String, String> idsMap = null;
        if("run".equals(flagValue))
        {
            idsMap = flowTraceMapper.queryRunFlowIds(businessKey);
        }
        else
        {
            idsMap = flowTraceMapper.queryHiFlowIds(businessKey);
        }
        try
        {
            if(!CollectionUtils.isEmpty(idsMap) && StringUtils.isNotBlank(idsMap.get("PROCINSTID")))
            {
                if("run".equals(flagValue))
                {
                    result = traceService.traceProcess(idsMap.get("PROCINSTID"));
                }
                else
                {
                    result = traceService.traceCompProcess(idsMap.get("PROCINSTID"), idsMap.get("PROCDEFID"));
                }
            }
        }
        catch (Exception e)
        {
            logger.error("traceProcess error : ", e);
        }
        return result;
    }
    
    /**
     * 输出跟踪流程信息-new 增加appNp
     *
     * @param processInstanceId
     * @return
     * @throws Exception
     */
    @RequestMapping (value = "/processTraceNew")
    @ResponseBody
    public Map<String, List<Map<String, Object>>> traceProcess(@RequestParam ("bsKey") String businessKey,
        @RequestParam ("flag") String flagValue, @RequestParam ("appno") String appNo)
    {
        Map<String, List<Map<String, Object>>> result = null;
        if(StringUtils.isBlank(businessKey))
        {
            logger.info("流程轨迹查看，请求参数为空");
            return result;
        }
        Map<String, String> idsMap = null;
        if("run".equals(flagValue))
        {
            idsMap = flowTraceMapper.queryRunFlowIds(businessKey);
        }
        else
        {
            idsMap = flowTraceMapper.queryHiFlowIds(businessKey);
        }
        try
        {
            if(!CollectionUtils.isEmpty(idsMap) && StringUtils.isNotBlank(idsMap.get("PROCINSTID")))
            {
                if("run".equals(flagValue))
                {
                    result = traceService.traceProcess(idsMap.get("PROCINSTID"), appNo);
                }
                else
                {
                    result = traceService.traceCompProcess(idsMap.get("PROCINSTID"), idsMap.get("PROCDEFID"), appNo);
                }
            }
        }
        catch (Exception e)
        {
            logger.error("traceProcess error : ", e);
        }
        return result;
    }
    
    @Autowired
    public void setRepositoryService(RepositoryService repositoryService)
    {
        this.repositoryService = repositoryService;
    }
    
    @Autowired
    public void setTraceService(WorkflowTraceService traceService)
    {
        this.traceService = traceService;
    }
    
}