package com.vms.activiti.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.identity.Group;
import org.activiti.engine.impl.GroupQueryImpl;
import org.activiti.engine.impl.Page;
import org.activiti.engine.impl.persistence.entity.GroupEntity;
import org.activiti.engine.impl.persistence.entity.GroupEntityManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.vms.mapper.RoleMapper;
import com.vms.model.Role;
import com.vms.utils.GeneralUtils;

public class CustomGroupEntityManager extends GroupEntityManager
{
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    @Autowired
    private RoleMapper roleMapper;
    
    @Override
    public List<Group> findGroupsByUser(String userId)
    {
        List<Group> list = null;
        if(StringUtils.isNotBlank(userId))
        {
            List<Role> roles = roleMapper.findRoleByUserId(userId);
            list = changeToGroupList(roles);
        }
        if(CollectionUtils.isEmpty(list))
        {
            logger.info("用户名:" + userId + ";无法获取角色权限信息");
        }
        return list;
    }
    
    @Override
    public List<Group> findGroupByQueryCriteria(GroupQueryImpl query, Page page)
    {
        List<Role> roles = new ArrayList<Role>();
        if(null != page)
        {
            com.vms.model.Page p = new com.vms.model.Page();
            p.setPageNo(page.getFirstResult());
            p.setPageSize(page.getMaxResults());
            p.setCalcIndex(false);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("id", query.getId());
            p.setParams(map);
            roles = roleMapper.findRoleByPage(p);
        }
        else if(null != query)
        {
            if(StringUtils.isNotBlank(query.getUserId()))
            {
                try
                {
                    return findGroupsByUser(query.getUserId());
                }
                catch (NumberFormatException ne)
                {
                    super.findGroupByQueryCriteria(query, page);
                }
            }
            else if(StringUtils.isNotBlank(query.getId()))
            {
                if(GeneralUtils.isNumeric(query.getId()))
                {
                    roles.add(roleMapper.findRoleById(Long.valueOf(query.getId())));
                }
                else
                {
                    roles = roleMapper.findRoleByName(query.getId());
                }
            }
        }
        return changeToGroupList(roles);
    }
    
    @Override
    public long findGroupCountByQueryCriteria(GroupQueryImpl query)
    {
        return roleMapper.countRole();
    }
    
    @Override
    public List<Group> findGroupsByNativeQuery(Map<String, Object> parameterMap, int firstResult, int maxResults)
    {
        return super.findGroupsByNativeQuery(parameterMap, firstResult, maxResults);
    }
    
    @Override
    public long findGroupCountByNativeQuery(Map<String, Object> parameterMap)
    {
        return super.findGroupCountByNativeQuery(parameterMap);
    }
    
    private List<Group> changeToGroupList(List<Role> roles)
    {
        List<Group> results = new ArrayList<Group>();
        Group group;
        if(!CollectionUtils.isEmpty(roles))
        {
            for(Role r : roles)
            {
                group = new GroupEntity();
                group.setId(r.getId().toString());
                group.setName(r.getName());
                group.setType("assignment");
                results.add(group);
            }
        }
        return results;
    }
}
