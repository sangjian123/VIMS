package com.vms.activiti.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.activiti.engine.FormService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricProcessInstanceQuery;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.runtime.ProcessInstanceQuery;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.apache.shiro.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vms.activiti.entity.oa.Leave;
import com.vms.activiti.model.ApplicationInfo;
import com.vms.activiti.model.Ttododet;
import com.vms.activiti.model.WorkFlow;
import com.vms.activiti.service.ActivitiFlowService;
import com.vms.activiti.service.LeaveManager;
import com.vms.activiti.service.LeaveWorkflowService;
import com.vms.activiti.util.Page;
import com.vms.model.ShiroUser;
import com.vms.model.User;
import com.vms.service.UserService;
import com.vms.utils.GeneralUtils;
import com.vms.utils.ServiceException;
import com.vms.utils.UUIDUtils;

/**
 * 请假流程Service
 *
 * @author HenryYan
 */
@Service
@Transactional
public class LeaveWorkflowServiceImpl implements LeaveWorkflowService
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(LeaveWorkflowServiceImpl.class);
    
    @Resource (name = "leaveManager")
    private LeaveManager leaveManager;
    
    private RuntimeService runtimeService;
    
    protected TaskService taskService;
    
    protected HistoryService historyService;
    
    protected RepositoryService repositoryService;
    
    @Autowired
    private IdentityService identityService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ActivitiFlowService activitiFlowService;
    
    @Autowired
    private FormService formService;
    
    /**
     * 启动请假流程
     *
     * @param entity
     */
    public ProcessInstance startWorkflow(Leave entity, Map<String, Object> variables, String flowFlag)
    {
        entity.setId(UUIDUtils.generateUUID());
        //设置申请时间
        entity.setApplyTime(new Date());
        //保存申请请假流程
        leaveManager.saveLeave(entity);
        LOGGER.debug("save entity: {}", entity);
        String businessKey = entity.getId().toString();
        
        ProcessInstance processInstance = null;
        try
        {
            // 用来设置启动流程的人员ID，引擎会自动把用户ID保存到activiti:initiator中
            identityService.setAuthenticatedUserId(entity.getUserId());
            
            processInstance = runtimeService.startProcessInstanceByKey(flowFlag, businessKey, variables);
            String processInstanceId = processInstance.getId();
            entity.setProcessInstanceId(processInstanceId);
            LOGGER.debug("start process of {key={}, bkey={}, pid={}, variables={}}", new Object[]{"leave", entity.getId(),
                processInstanceId, variables });
        }
        catch (Exception e)
        {
            LOGGER.error("startWorkflow error ", e);
        }
        finally
        {
            identityService.setAuthenticatedUserId(null);
        }
        return processInstance;
    }
    
    /**
     * 查询待办任务个数
     *
     * @param userId 用户ID
     * @return
     */
    @Transactional (readOnly = true)
    public long findTodoTasksCount(String userId)
    {
        // 根据当前人的ID查询
        TaskQuery taskQuery = taskService.createTaskQuery().taskCandidateOrAssigned(userId).active();
        return taskQuery.count();
    }
    
    /**
     * 查询待办任务
     *
     * @param userId 用户ID
     * @return
     */
    @Transactional (readOnly = true)
    public List<WorkFlow> findTodoTasks(String userId, Page<WorkFlow> page, int[] pageParams, String appNo, WorkFlow workFlowQe)
    {
        List<WorkFlow> results = new ArrayList<WorkFlow>();
        // 根据当前人的ID查询
        TaskQuery taskQuery = taskService.createTaskQuery().taskCandidateOrAssigned(userId).orderByTaskCreateTime().desc();
        List<Task> tasks = taskQuery.listPage(pageParams[0], pageParams[1]);
        
        // 根据流程的业务ID查询实体并关联
        for(Task task : tasks)
        {
            String processInstanceId = task.getProcessInstanceId();
            String processName = workFlowQe.getProcessName();
            ProcessInstanceQuery processInstanceQuery =
                runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId);
            if(GeneralUtils.isNotNullOrZeroLength(processName))
            {
                processInstanceQuery.processDefinitionName(processName);
            }
            ProcessInstance processInstance = processInstanceQuery.active().singleResult();
            if(processInstance == null)
            {
                continue;
            }
            String businessKey = processInstance.getBusinessKey();
            if(businessKey == null)
            {
                continue;
            }
            WorkFlow workflow = new WorkFlow();
            workflow.setProcessInstanceId(processInstanceId);
            workflow.setBusinessKey(processInstance.getBusinessKey());
            workFlowQe.setBusinessKey(processInstance.getBusinessKey());
            //根据BusinessKey查询对应的申请编号
            ApplicationInfo appInfo = activitiFlowService.queryAppidByBusinessKey(workFlowQe);
            if(appInfo != null)
            {
                if(!"".equals(appNo) && appNo != null)
                {
                    if(appNo.equals(appInfo.getAppNo() + ""))
                    {
                        workflow.setApp_id(appInfo.getAppId() + "");
                        workflow.setAppNo(appInfo.getAppNo() + "");
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    workflow.setApp_id(appInfo.getAppId() + "");
                    workflow.setAppNo(appInfo.getAppNo() + "");
                }
                workflow.setOrgName(appInfo.getOrgName());
                workflow.setConsNo(appInfo.getConsNo());
                workflow.setConsName(appInfo.getConsName());
                WorkFlow nameIdList = activitiFlowService.queryFlowUser(workFlowQe);
                //根据流程实例id查询发起流程的人
                workflow.setStartUserId(nameIdList.getStartUserId());
                workflow.setName(nameIdList.getName());
                workflow.setProcessDefinitionId(processInstance.getProcessDefinitionId());
                workflow.setCreateTime(task.getCreateTime());
                workflow.setFlowversion(task.getName());
                workflow.setVersion(getProcessDefinition(processInstance.getProcessDefinitionId()).getVersion());
                workflow.setTask(task);
                workflow.setProcessInstance(processInstance);
                workflow.setProcessName(processInstance.getProcessDefinitionName());
                //获取到自定义表单的url
                String customUrl = formService.getTaskFormData(task.getId()).getFormKey();
                workflow.setCustomUrl(customUrl);
                results.add(workflow);
            }
        }
        return results;
    }
    
    /**
     * 读取运行中的流程
     *
     * @return
     */
    @Transactional (readOnly = true)
    public Map<String, Object> findRunningProcessInstaces(Page<WorkFlow> page, int[] pageParams, String appNo)
    {
        List<WorkFlow> results = new ArrayList<WorkFlow>();
        List<ProcessInstance> listcount = new ArrayList<ProcessInstance>();
        Long cnt = null;
        String keyId = "";
        ApplicationInfo aData = new ApplicationInfo();
        if(GeneralUtils.isNotNullOrZeroLength(appNo))
        {
            WorkFlow woAppNo = new WorkFlow();
            woAppNo.setAppNo(appNo.trim());
            aData = activitiFlowService.queryAppidByBusinessKey(woAppNo);
            //根据appNo 查询businesskey
            keyId = aData.getId();
            ProcessInstance s2 = runtimeService.createProcessInstanceQuery().processInstanceBusinessKey(keyId).singleResult();
            listcount.add(s2);
            //符合查询条件条目数
            cnt = runtimeService.createProcessInstanceQuery().processInstanceBusinessKey(keyId).count();
        }
        else
        {
            listcount =
                runtimeService.createProcessInstanceQuery().active()
                    .listPage((page.getPageNo() - 1) * page.getPageSize(), page.getPageSize());
            //总条目数
            cnt = runtimeService.createProcessInstanceQuery().count();
        }
        Map<String, Object> map = new HashMap<String, Object>();
        // 关联业务实体
        for(ProcessInstance processInstance : listcount)
        {
            String businessKey = processInstance.getBusinessKey();
            if(businessKey == null)
            {
                continue;
            }
            WorkFlow workflow = new WorkFlow();
            workflow.setProcessInstanceId(processInstance.getProcessInstanceId());
            workflow.setBusinessKey(processInstance.getBusinessKey());
            //根据BusinessKey查询对应的申请编号
            ApplicationInfo appInfo = activitiFlowService.queryAppidByBusinessKey(processInstance.getBusinessKey());
            if(appInfo != null)
            {
                if(!"".equals(appNo.trim()) && appNo.trim() != null)
                {
                    if(appNo.trim().equals(appInfo.getAppNo() + ""))
                    {
                        workflow.setApp_id(appInfo.getAppId() + "");
                        workflow.setAppNo(appInfo.getAppNo() + "");
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    workflow.setApp_id(appInfo.getAppId() + "");
                    workflow.setAppNo(appInfo.getAppNo() + "");
                }
                WorkFlow nameIdList = activitiFlowService.queryFlowUser(processInstance.getBusinessKey());
                //根据流程实例id查询发起流程的人
                workflow.setName(nameIdList.getName());
                workflow.setVersion(getProcessDefinition(processInstance.getProcessDefinitionId()).getVersion());
                workflow.setProcessInstance(processInstance);
                workflow.setProcessDefinitionId(processInstance.getProcessDefinitionId());
                workflow.setProcessName(processInstance.getProcessDefinitionName());
                results.add(workflow);
                // 设置当前任务信息
                List<Task> tasks =
                    taskService.createTaskQuery().processInstanceId(processInstance.getId()).active().orderByTaskCreateTime()
                        .desc().listPage(0, 1);
                if(tasks.size() > 0)
                {
                    String assignee = tasks.get(0).getAssignee();
                    User user = userService.findUserById(assignee);
                    if(user != null)
                    {
                        tasks.get(0).setAssignee(user.getNickName());
                    }
                    workflow.setTask(tasks.get(0));
                }
            }
            
        }
        map.put("count", cnt.intValue());
        map.put("list", results);
        return map;
    }
    
    /**
     * 读取已结束中的流程
     *
     * @return
     */
    @Transactional (readOnly = true)
    public Map<String, Object> findFinishedProcessInstaces(int[] pageParams)
    {
        
        List<WorkFlow> results = new ArrayList<WorkFlow>();
        HistoricProcessInstanceQuery historicProcessInstanceQuery =
            historyService.createHistoricProcessInstanceQuery().finished();
        List<HistoricProcessInstance> list =
            historicProcessInstanceQuery.orderByProcessInstanceEndTime().desc().listPage(pageParams[0], pageParams[1]);
        
        // 关联业务实体
        for(HistoricProcessInstance historicProcessInstance : list)
        {
            WorkFlow workflow = new WorkFlow();
            workflow.setBusinessKey(historicProcessInstance.getBusinessKey());
            //根据BusinessKey查询对应的申请编号
            ApplicationInfo appInfo = activitiFlowService.queryAppidByBusinessKey(historicProcessInstance.getBusinessKey());
            if(appInfo != null)
            {
                workflow.setApp_id(appInfo.getAppId() + "");
                workflow.setAppNo(appInfo.getAppNo() + "");
            }
            WorkFlow nameIdList = activitiFlowService.queryFlowUser(historicProcessInstance.getBusinessKey());
            //根据流程实例id查询发起流程的人
            workflow.setName(nameIdList.getStartUserId());
            workflow.setVersion(getProcessDefinition(historicProcessInstance.getProcessDefinitionId()).getVersion());
            workflow.setProcessDefinitionId(historicProcessInstance.getProcessDefinitionId());
            workflow.setHistoricProcessInstance(historicProcessInstance);
            results.add(workflow);
        }
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("rows", results);
        map.put("total", historicProcessInstanceQuery.count());
        
        return map;
    }
    
    /**
     * 查询流程定义对象
     *
     * @param processDefinitionId 流程定义ID
     * @return
     */
    public ProcessDefinition getProcessDefinition(String processDefinitionId)
    {
        ProcessDefinition processDefinition =
            repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
        return processDefinition;
    }
    
    @Autowired
    public void setRuntimeService(RuntimeService runtimeService)
    {
        this.runtimeService = runtimeService;
    }
    
    @Autowired
    public void setTaskService(TaskService taskService)
    {
        this.taskService = taskService;
    }
    
    @Autowired
    public void setHistoryService(HistoryService historyService)
    {
        this.historyService = historyService;
    }
    
    @Autowired
    public void setRepositoryService(RepositoryService repositoryService)
    {
        this.repositoryService = repositoryService;
    }
    
    /**
     * 启动高低压流程
     *
     */
    public ProcessInstance startApplyWorkflow(ApplicationInfo applicationInfo, Map<String, Object> variables, String flowFlag)
    {
        Long id = UUIDUtils.generateUUID();
        String businessKey = id.toString();
        ProcessInstance processInstance = null;
        //将工作流的流程实例的id与高低压申请的主表进行关联
        activitiFlowService.updateIdBySapp(id, applicationInfo.getAppId());
        ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
        try
        {
            // 用来设置启动流程的人员ID，引擎会自动把用户ID保存到activiti:initiator中
            identityService.setAuthenticatedUserId(user.id);
            processInstance = runtimeService.startProcessInstanceByKey(flowFlag, businessKey, variables);
            String processInstanceId = processInstance.getId();
            LOGGER.debug("start process of {key={}, bkey={}, pid={}, variables={}}", new Object[]{flowFlag, id,
                processInstanceId, variables });
        }
        catch (Exception e)
        {
            LOGGER.error("process start error.", e);
            throw new ServiceException("process start error.");
        }
        return processInstance;
    }
    
    //list分页
    @SuppressWarnings ("unchecked")
    public static <T> List<T> splitList(List<WorkFlow> list, int begin, int end)
    {
        @SuppressWarnings ("rawtypes")
        List pageList = null;
        Integer maxSize = end;
        Integer dataSize = list.size();
        if(maxSize < dataSize)
        {
            pageList = list.subList(begin, maxSize);
        }
        else
        {
            pageList = list.subList(begin, list.size());
        }
        return pageList;
    }
    
    @Override
    public ProcessInstance startApplyWorkAsset(Ttododet ttododet)
    {
        Map<String, Object> variables = new HashMap<String, Object>();
        String flowFlag = "";
        String businessKey = ttododet.getTodoId();
        String equipType = ttododet.getEquipType();
        if("301".equals(equipType))
        {
            flowFlag = "assetFiling";
        }
        else if("311".equals(equipType))
        {
            flowFlag = "meterOutStorage";
        }
        else if("302".equals(equipType))
        {
            flowFlag = "assetFiling";
        }
        else if("312".equals(equipType))
        {
            flowFlag = "ditOutStorage";
        }
        else if("303".equals(equipType))
        {
            flowFlag = "assetFiling";
        }
        else if("313".equals(equipType))
        {
            flowFlag = "dlcOutStorage";
        }
        ProcessInstance processInstance = null;
        try
        {
            identityService.setAuthenticatedUserId(ttododet.getEmployeeNo());
            processInstance = runtimeService.startProcessInstanceByKey(flowFlag, businessKey, variables);
        }
        catch (Exception e)
        {
            LOGGER.error("" + e);
            throw e;
        }
        return processInstance;
    }
    
    /**
     * 启动MDM防窃电工作流
     * @param appId
     * @param variables
     * @param flowFlag
     * @return
     */
    @Override
    public ProcessInstance startPowerStealWorkflow(Long appId, Map<String, Object> variables, String flowFlag)
    {
        Long id = UUIDUtils.generateUUID();
        String businessKey = id.toString();
        ProcessInstance processInstance = null;
        activitiFlowService.updateIdBySapp(id, appId);
        ShiroUser user = (ShiroUser) SecurityUtils.getSubject().getPrincipal();
        try
        {
            // 用来设置启动流程的人员ID，引擎会自动把用户ID保存到activiti:initiator中
            identityService.setAuthenticatedUserId(user.id);
            processInstance = runtimeService.startProcessInstanceByKey(flowFlag, businessKey, variables);
            String processInstanceId = processInstance.getId();
            LOGGER.debug("start process of {key={}, bkey={}, pid={}, variables={}}", new Object[]{flowFlag, id,
                processInstanceId, variables });
        }
        catch (Exception e)
        {
            LOGGER.error("process start error.", e);
            throw new ServiceException("process start error.");
        }
        return processInstance;
    }
    
}
