package com.vms.activiti.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vms.activiti.entity.act.ProcessInstance;
import com.vms.activiti.mapper.activitiFlowMapper;
import com.vms.activiti.model.ApplicationInfo;
import com.vms.activiti.model.WorkFlow;
import com.vms.activiti.service.ActivitiFlowService;
import com.vms.model.Page;

/**
 * 工作流的service
 * @author kxx
 *
 */
@Service
public class ActivitiFlowServiceImpl implements ActivitiFlowService
{
    
    @Autowired
    private activitiFlowMapper activitiflowMapper;
    
    /**
     * 修改 客户的申请用电信息与工作流的实例id进行关联
     *
     * @param userVo
     */
    @Override
    public void updateIdBySapp(Long id, Long appid)
    {
        activitiflowMapper.updateIdBySapp(id, appid);
    }
    
    @Override
    public WorkFlow queryFlowUser(String processInstance)
    {
        
        return activitiflowMapper.queryFlowUser(processInstance);
    }
    
    @Override
    public ApplicationInfo queryAppidByBusinessKey(String businessKey)
    {
        return activitiflowMapper.queryAppidByBusinessKey(businessKey);
    }
    
    @Override
    public ApplicationInfo queryAppInfoByAppId(Long appId)
    {
        return activitiflowMapper.queryAppInfoByAppId(appId);
    }
    
    @Override
    public void updateAssigneeById(String id, String name)
    {
        activitiflowMapper.updateAssigneeById(id, name);
    }
    
    @Override
    public List<String> queryFlowKey()
    {
        
        return activitiflowMapper.queryFlowKey();
    }
    
    @Override
    public ApplicationInfo queryAppidByBusinessKey(WorkFlow workFlowQe)
    {
        
        return activitiflowMapper.queryAppidByBusinessKeyQe(workFlowQe);
    }
    
    @Override
    public WorkFlow queryFlowUser(WorkFlow workFlowQe)
    {
        
        return activitiflowMapper.queryFlowUserQe(workFlowQe);
    }
    
    @Override
    public List<WorkFlow> queryProcessNameByPage()
    {
        List<WorkFlow> list = activitiflowMapper.queryProcessNameByPage();
        return list;
    }
    
    @Override
    public List<WorkFlow> queryStepName(WorkFlow workFlow)
    {
        List<WorkFlow> list = activitiflowMapper.queryStepName(workFlow);
        return list;
    }
    
    @Override
    public List<ProcessInstance> processInstanceList(Page<ProcessInstance> page)
    {
        List<ProcessInstance> list = activitiflowMapper.processInstanceList(page);
        return list;
    }
    
    @Override
    public int updateTaskStatus(Long appId, String status)
    {
        return activitiflowMapper.updateTaskStatus(appId, status);
    }
    
    /**
     * 判断流程是否可终止
     * @param appId
     * @return map: 0:正常，1:新装已经收取业务费，2:新装已经装表，3:销户已经拆表，4:过户已经生成账单
     */
    public Map<String, Object> findTerminateStatus(Long appId)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("msg", "0");
        //通过appId查询S_APP数据，判断是什么流程
        ApplicationInfo app = activitiflowMapper.queryAppInfoByAppId(appId);
        if(null != app)
        {
            if("1".equals(activitiflowMapper.queryBillStatus(appId)))
            {//已经生成账单
                map.put("msg", "4");
                return map;
            }
            if("1".equals(activitiflowMapper.queryMeterInstallStatus(appId)))
            {//已经安装电表
                map.put("msg", "2");
                return map;
            }
            if("1".equals(activitiflowMapper.queryMeterRemoveStatus(appId)))
            {//已经拆除电表
                map.put("msg", "3");
                return map;
            }
            if("1".equals(activitiflowMapper.queryBusiFeeStatus(appId)))
            {//已经收取业务费
                map.put("msg", "1");
                return map;
            }
            List<Map<String, Object>> list = activitiflowMapper.queryDepositStatus(appId);
            boolean sflag = false;
            boolean tflag = false;
            for(int i = 0; i < list.size(); i++)
            {
                BigDecimal amt = new BigDecimal(list.get(i).get("amt").toString());
                if(amt.compareTo(BigDecimal.ZERO) < 0)
                {//已退保证金
                    tflag = true;
                }
                else if(amt.compareTo(BigDecimal.ZERO) > 0)
                {//已收保证金
                    sflag = true;
                    map.put("amt", amt);
                }
            }
            if(tflag)
            {//已退不可终止
                map.put("msg", "6");
                return map;
            }
            if(sflag)
            {//已收提示是否退费
                map.put("msg", "5");
                return map;
            }
        }
        return map;
    }
    
    @Override
    public void delSApp(String appId)
    {
        activitiflowMapper.delSApp(appId);
        
    }
    
}
