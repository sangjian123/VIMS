package com.vms.activiti.model;

import java.io.Serializable;
import java.util.Date;

public class SappCert implements Serializable{
    
    private static final long serialVersionUID = -6680123508884767724L;

    private Long actId;

    private Long appId;

    private Long appnId;

    private Long certId;

    private String certTypeCode;

    private String certName;

    private String certNo;

    private Date certEffectDate;

    private Date certExpireDate;

    private String directory;

    public Long getActId() {
        return actId;
    }

    public void setActId(Long actId) {
        this.actId = actId;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public Long getAppnId() {
        return appnId;
    }

    public void setAppnId(Long appnId) {
        this.appnId = appnId;
    }

    public Long getCertId() {
        return certId;
    }

    public void setCertId(Long certId) {
        this.certId = certId;
    }

    public String getCertTypeCode() {
        return certTypeCode;
    }

    public void setCertTypeCode(String certTypeCode) {
        this.certTypeCode = certTypeCode == null ? null : certTypeCode.trim();
    }

    public String getCertName() {
        return certName;
    }

    public void setCertName(String certName) {
        this.certName = certName == null ? null : certName.trim();
    }

    public String getCertNo() {
        return certNo;
    }

    public void setCertNo(String certNo) {
        this.certNo = certNo == null ? null : certNo.trim();
    }

    public Date getCertEffectDate() {
        return certEffectDate;
    }

    public void setCertEffectDate(Date certEffectDate) {
        this.certEffectDate = certEffectDate;
    }

    public Date getCertExpireDate() {
        return certExpireDate;
    }

    public void setCertExpireDate(Date certExpireDate) {
        this.certExpireDate = certExpireDate;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory == null ? null : directory.trim();
    }
}