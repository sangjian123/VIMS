package com.vms.activiti.model;

import java.io.Serializable;

public class UserAccount implements Serializable
{
    
    private static final long serialVersionUID = 1L;
    
    private Integer custId; //客戶Id
    
    private String custNo; //客戶编号
    
    private String name; //客户名称
    
    private String elecAddr; //用电地址
    
    private String mobIle; //联系电话
    
    private String orgName; //供电单位
    
    private String typeCode; //证件类型
    
    private String typeCodeFmt;
    
    private String certNo; //证件号码
    
    private String pLateNo; //门牌号
    
    public String getpLateNo()
    {
        return pLateNo;
    }
    
    public void setpLateNo(String pLateNo)
    {
        this.pLateNo = pLateNo;
    }
    
    public Integer getCustId()
    {
        return custId;
    }
    
    public void setCustId(Integer custId)
    {
        this.custId = custId;
    }
    
    public String getCustNo()
    {
        return custNo;
    }
    
    public void setCustNo(String custNo)
    {
        this.custNo = custNo;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getElecAddr()
    {
        return elecAddr;
    }
    
    public void setElecAddr(String elecAddr)
    {
        this.elecAddr = elecAddr;
    }
    
    public String getMobIle()
    {
        return mobIle;
    }
    
    public void setMobIle(String mobIle)
    {
        this.mobIle = mobIle;
    }
    
    public String getOrgName()
    {
        return orgName;
    }
    
    public void setOrgName(String orgName)
    {
        this.orgName = orgName;
    }
    
    public String getTypeCode()
    {
        return typeCode;
    }
    
    public void setTypeCode(String typeCode)
    {
        this.typeCode = typeCode;
    }
    
    public String getCertNo()
    {
        return certNo;
    }
    
    public void setCertNo(String certNo)
    {
        this.certNo = certNo;
    }
    
    public String getTypeCodeFmt()
    {
        return typeCodeFmt;
    }
    
    public void setTypeCodeFmt(String typeCodeFmt)
    {
        this.typeCodeFmt = typeCodeFmt;
    }
    
}
