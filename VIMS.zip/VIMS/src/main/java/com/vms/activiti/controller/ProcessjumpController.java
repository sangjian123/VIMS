package com.vms.activiti.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.ehcache.management.ManagementService;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.bpmn.behavior.UserTaskActivityBehavior;
import org.activiti.engine.impl.javax.el.ExpressionFactory;
import org.activiti.engine.impl.javax.el.ValueExpression;
import org.activiti.engine.impl.juel.ExpressionFactoryImpl;
import org.activiti.engine.impl.juel.SimpleContext;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.PvmActivity;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.task.TaskDefinition;
import org.activiti.engine.runtime.Execution;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.vms.activiti.mapper.ActHiTaskinstMapper;
import com.vms.activiti.util.Variable;
import com.vms.constant.ConstantCode;
import com.vms.controller.BaseController;
import com.vms.service.UserService;
import com.vms.utils.GeneralUtils;
import com.vms.utils.RedisCacheUtil;

@Scope ("prototype")
@Controller
@RequestMapping ("/processJump")
public class ProcessjumpController extends BaseController
{
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ProcessjumpController.class);
    
    @Autowired
    private TaskService taskService;
    
    @Autowired
    protected RuntimeService runtimeService;
    
    @Autowired
    protected RepositoryService repositoryService;
    
    @Autowired
    protected HistoryService historyService;
    
    @Autowired
    ManagementService managementService;
    
    @Autowired
    private ActHiTaskinstMapper actHiTaskinstMapper;
    
    @Autowired
    private UserService userService;
    
    private RedisCacheUtil redisCacheUtil = new RedisCacheUtil();
    
    /**
     * 选择人员进行流程跳转
     * @param request
     * @param response
     * @return
     */
    @RequestMapping ("/processJumpWorkflow")
    public @ResponseBody Map<String, Object> processJumpWorkflow(HttpServletRequest request, HttpServletResponse response)
    {
        
        String appId = request.getParameter("appid");//申请编号
        String userId = request.getParameter("name");//用户id
        String taskId = request.getParameter("taskId");//流程id
        String tprocinstId = request.getParameter("tprocinstId");
        String status = request.getParameter("status");//状态位，false：回退
        String switchFlag = request.getParameter("switchFlag");//分支标识
        
        boolean isPass = false;
        boolean isFee = false;
        if(status.contains(","))
        {
            String str[] = status.split(",");
            isPass = !"false".equals(str[0]);
            isFee = !"false".equals(str[1]);
        }
        else
        {
            isPass = !"false".equals(status);
        }
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("startMessage", 0);
        
        try
        {
            Variable var = new Variable();
            if(status.contains(","))
            {
                var.setKeys("isPass,isFee");
                String str = isPass ? "true" : "false";
                String str1 = isFee ? "true" : "false";
                var.setValues(str + "," + str1);
                var.setTypes("B,B");
            }
            else
            {
                var.setKeys("isPass");
                String str = isPass ? "true" : "false";
                var.setValues(str);
                var.setTypes("B");
            }
            Map<String, Object> variables = var.getVariableMap();
            if(StringUtils.isNotEmpty(switchFlag))
            {
                variables.put("switchFlag", switchFlag);
            }
            taskService.setVariables(taskId, variables);
            /*   if (isPass == true)
            {
                variables.put ("user", userId);
            }
            else
            {
                variables.put ("user", findBackUserId (tprocinstId, taskId, userId, var));
            }*/
            
            if(null != userId)
            {
                variables.put("user", userId);
            }
            else
            {
                variables.put("user", findBackUserId(tprocinstId, taskId, userId, var));
            }
            taskService.complete(taskId, variables);
            // 回退更新装拆表状态 临时方案
            if("false".equals(status))
            {
                actHiTaskinstMapper.updateMeterStatus(appId);
            }
            map.put("startMessage", 1);
            LOGGER.info("申请编号:" + appId + " 流程跳转成功");
            
        }
        catch (Exception e)
        {
            LOGGER.error("申请编号:" + appId + "流程跳转失败 ", e);
        }
        return map;
    }
    
    /**
     * 选择部门进行流程跳转
     * @param request
     * @param response
     * @return
     */
    @RequestMapping ("/gridJumpflow")
    public @ResponseBody Map<String, Object> gridJumpflow(HttpServletRequest request, HttpServletResponse response)
    {
        
        String appId = request.getParameter("appid");//申请编号
        String deptId = request.getParameter("deptId");//部门标识
        String taskId = request.getParameter("taskId");//流程id
        String tprocinstId = request.getParameter("tprocinstId");
        String status = request.getParameter("status");//状态位，false：回退
        String switchFlag = request.getParameter("switchFlag");//分支标识
        String rcvFeeFlag = request.getParameter("rcvFeeFlag");//收费标识
        boolean isPass = false;
        boolean isFee = false;
        if(status.contains(","))
        {
            String str[] = status.split(",");
            isPass = !"false".equals(str[0]);
            isFee = !"false".equals(str[1]);
        }
        else
        {
            isPass = !"false".equals(status);
        }
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("startMessage", 0);
        
        try
        {
            Variable var = new Variable();
            if(status.contains(","))
            {
                var.setKeys("isPass,isFee");
                String str = isPass ? "true" : "false";
                String str1 = isFee ? "true" : "false";
                var.setValues(str + "," + str1);
                var.setTypes("B,B");
            }
            else
            {
                var.setKeys("isPass");
                String str = isPass ? "true" : "false";
                var.setValues(str);
                var.setTypes("B");
            }
            Map<String, Object> variables = var.getVariableMap();
            taskService.setVariables(taskId, variables);
            /*   if (isPass == true)
            {
                variables.put ("user", userId);
            }
            else
            {
                variables.put ("user", findBackUserId (tprocinstId, taskId, userId, var));
            }*/
            
            if(null != deptId)
            {
                variables.put("dept", deptId);
            }
            else
            {
                variables.put("dept", findBackUserId(tprocinstId, taskId, deptId, var));
            }
            if(StringUtils.isNotEmpty(switchFlag))
            {
                variables.put("switchFlag", switchFlag);
            }
            if(StringUtils.isNotEmpty(rcvFeeFlag))
            {
                variables.put("rcvFeeFlag", rcvFeeFlag);
            }
            else
            {
                String chargeFlag = redisCacheUtil.getDataFromRedis("CRM_WORKFLOW_CHARGE", String.class);
                if(ConstantCode.STRING_0.equals(chargeFlag))
                {
                    variables.put("rcvFeeFlag", "true");
                }
                else
                {
                    variables.put("rcvFeeFlag", "false");
                }
            }
            taskService.complete(taskId, variables);
            // 回退更新装拆表状态 临时方案
            if("false".equals(status))
            {
                actHiTaskinstMapper.updateMeterStatus(appId);
            }
            map.put("startMessage", 1);
            LOGGER.info("申请编号:" + appId + " 流程跳转成功");
            
        }
        catch (Exception e)
        {
            LOGGER.error("申请编号:" + appId + "流程跳转失败 ", e);
        }
        return map;
    }
    
    /**
     * 选择人员进行流程跳转(配送管理，包含业务逻辑)
     * @param request
     * @param response
     * @return
     */
    @RequestMapping ("/processJumpWorkflowDistribution")
    public @ResponseBody Map<String, Object> processJumpWorkflowDistribution(HttpServletRequest request,
        HttpServletResponse response)
    {
        
        String appId = request.getParameter("appid");//申请编号
        String userId = request.getParameter("name");//用户id
        String taskId = request.getParameter("sskId");//流程id
        String tprocinstId = request.getParameter("tprocinstId");
        String status = request.getParameter("status");//状态位，false：回退
        boolean isPass = false;
        boolean isFee = false;
        if(status.contains(","))
        {
            String str[] = status.split(",");
            isPass = !"false".equals(str[0]);
            isFee = !"false".equals(str[1]);
        }
        else
        {
            isPass = !"false".equals(status);
        }
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("startMessage", 0);
        
        try
        {
            
            Variable var = new Variable();
            if(status.contains(","))
            {
                var.setKeys("isPass,isFee");
                String str = isPass ? "true" : "false";
                String str1 = isFee ? "true" : "false";
                var.setValues(str + "," + str1);
                var.setTypes("B,B");
            }
            else
            {
                var.setKeys("isPass");
                String str = isPass ? "true" : "false";
                var.setValues(str);
                var.setTypes("B");
            }
            Map<String, Object> variables = var.getVariableMap();
            taskService.setVariables(taskId, variables);
            /*   if (isPass == true)
            {
            variables.put ("user", userId);
            }
            else
            {
            variables.put ("user", findBackUserId (tprocinstId, taskId, userId, var));
            }*/
            
            if(null != userId)
            {
                variables.put("user", userId);
            }
            else
            {
                variables.put("user", findBackUserId(tprocinstId, taskId, userId, var));
            }
            taskService.complete(taskId, variables);
            map.put("startMessage", 1);
            LOGGER.info("申请编号:" + appId + " 流程跳转成功");
        }
        catch (Exception e)
        {
            LOGGER.error("申请编号:" + appId + "流程跳转失败 ", e);
        }
        return map;
    }
    
    private String findBackUserId(String processInstanceId, String taskId, String userId, Variable var)
    {
        String sourceTaskDefKey = getNextTaskDef(taskId, var).getKey();
        
        List<HistoricTaskInstance> tasks =
            historyService.createHistoricTaskInstanceQuery().processInstanceId(processInstanceId)
                .taskDefinitionKey(sourceTaskDefKey).orderByHistoricTaskInstanceEndTime().desc().listPage(0, 1);
        String assigneeUserId = "";
        if(!CollectionUtils.isEmpty(tasks))
        {
            assigneeUserId = tasks.get(0).getAssignee();
        }
        if(GeneralUtils.isNullOrZeroLength(assigneeUserId))
        {
            if(GeneralUtils.isNotNullOrZeroLength(userId))
            {
                assigneeUserId = userId;
            }
            else
            {
                assigneeUserId = super.getUserId();
            }
        }
        
        return assigneeUserId;
    }
    
    /**
     * 流程跳转
     * @param taskId
     * @param stationName 当前岗位名称
     * @param isPass 通过
     */
    public void Processjump(String taskId, String stationName, boolean isPass)
    {
        Variable var = new Variable();
        Map<String, Object> variables = var.getVariableMap();
        taskService.complete(taskId, variables);
    }
    
    /**
     * 结束节点
     * @param request
     * @param response
     * @return
     */
    @RequestMapping ("/processEndflow")
    @ResponseBody
    public Map<String, Object> processEndflow(HttpServletRequest request, HttpServletResponse response)
    {
        
        String appId = request.getParameter("appid");//申请编号
        String taskId = request.getParameter("taskId");//流程id
        String tprocinstId = request.getParameter("tprocinstId");
        
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("startMessage", 0);
        try
        {
            runtimeService.deleteProcessInstance(tprocinstId, taskId + " 终止 " + appId);
            map.put("startMessage", 1);
        }
        catch (Exception e)
        {
            LOGGER.error("申请编号:" + appId + "结束流程失败 ", e);
        }
        return map;
    }
    
    /**
     * 获取下一个任务定义
     * @param taskId     任务Id信息
     * @return 下一个任务定义
     * @throws Exception
     */
    public TaskDefinition getNextTaskDef(String taskId, Variable var)
    {
        
        ProcessDefinitionEntity processDefinitionEntity = null;
        
        String id = null;
        
        TaskDefinition task = null;
        
        //获取流程实例Id信息
        String processInstanceId = taskService.createTaskQuery().taskId(taskId).singleResult().getProcessInstanceId();
        
        //获取流程发布Id信息
        String definitionId =
            runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult()
                .getProcessDefinitionId();
        
        processDefinitionEntity =
            (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(definitionId);
        
        ExecutionEntity execution =
            (ExecutionEntity) runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        
        //当前流程节点Id信息
        String activitiId = execution.getActivityId();
        
        //获取流程所有节点信息
        List<ActivityImpl> activitiList = processDefinitionEntity.getActivities();
        
        //遍历所有节点信息
        for(ActivityImpl activityImpl : activitiList)
        {
            id = activityImpl.getId();
            if(activitiId.equals(id))
            {
                
                //获取下一个节点信息
                task = nextTaskDefinition(activityImpl, activityImpl.getId(), var, processInstanceId);
                break;
            }
        }
        
        return task;
    }
    
    /**
     * 下一个任务节点信息,
     *
     * 如果下一个节点为用户任务则直接返回,
     *
     * 如果下一个节点为排他网关, 获取排他网关Id信息, 根据排他网关Id信息和execution获取流程实例排他网关Id为key的变量值,
     * 根据变量值分别执行排他网关后线路中的el表达式, 并找到el表达式通过的线路后的用户任务信息
     * @param activityImpl     流程节点信息
     * @param activityId             当前流程节点Id信息
     * @param var               排他网关顺序流线段判断条件, 例如排他网关顺序留线段判断条件为${money>1000}, 若满足流程启动时设置variables中的money>1000, 则流程流向该顺序流信息
     * @param processInstanceId      流程实例Id信息
     * @return
     */
    private TaskDefinition nextTaskDefinition(ActivityImpl activityImpl, String activityId, Variable var, String processInstanceId)
    {
        
        PvmActivity ac = null;
        
        Object s = null;
        
        //如果遍历节点为用户任务并且节点不是当前节点信息
        if("userTask".equals(activityImpl.getProperty("type")) && !activityId.equals(activityImpl.getId()))
        {
            //获取该节点下一个节点信息
            TaskDefinition taskDefinition = ((UserTaskActivityBehavior) activityImpl.getActivityBehavior()).getTaskDefinition();
            return taskDefinition;
        }
        else
        {
            //获取节点所有流向线路信息
            List<PvmTransition> outTransitions = activityImpl.getOutgoingTransitions();
            List<PvmTransition> outTransitionsTemp = null;
            for(PvmTransition tr : outTransitions)
            {
                ac = tr.getDestination(); //获取线路的终点节点
                //如果流向线路为排他网关
                if("exclusiveGateway".equals(ac.getProperty("type")) || "parallelGateway".equals(ac.getProperty("type")))
                {
                    outTransitionsTemp = ac.getOutgoingTransitions();
                    
                    //如果排他网关只有一条线路信息
                    if(outTransitionsTemp.size() == 1)
                    {
                        return nextTaskDefinition((ActivityImpl) outTransitionsTemp.get(0).getDestination(), activityId, var,
                            processInstanceId);
                    }
                    else if(outTransitionsTemp.size() > 1)
                    { //如果排他网关有多条线路信息
                        for(PvmTransition tr1 : outTransitionsTemp)
                        {
                            s = tr1.getProperty("conditionText"); //获取排他网关线路判断条件信息
                            if(isCondition(var.getKeys(), StringUtils.trim(s.toString()), var.getValues()))
                            {
                                return nextTaskDefinition((ActivityImpl) tr1.getDestination(), activityId, var, processInstanceId);
                            }
                        }
                    }
                }
                else if("userTask".equals(ac.getProperty("type")))
                {
                    return ((UserTaskActivityBehavior) ((ActivityImpl) ac).getActivityBehavior()).getTaskDefinition();
                }
                else
                {
                }
            }
            return null;
        }
    }
    
    /**
     * 查询流程启动时设置排他网关判断条件信息
     * @param gatewayId          排他网关Id信息, 流程启动时设置网关路线判断条件key为网关Id信息
     * @param processInstanceId  流程实例Id信息
     * @return
     */
    public String getGatewayCondition(String gatewayId, String processInstanceId)
    {
        Execution execution = runtimeService.createExecutionQuery().processInstanceId(processInstanceId).singleResult();
        return String.valueOf(runtimeService.getVariable(execution.getId(), gatewayId));
    }
    
    /**
     * 根据key和value判断el表达式是否通过信息
     * @param key    el表达式key信息
     * @param el     el表达式信息
     * @param value  el表达式传入值信息
     * @return
     */
    public boolean isCondition(String key, String el, String value)
    {
        ExpressionFactory factory = new ExpressionFactoryImpl();
        SimpleContext context = new SimpleContext();
        context.setVariable(key, factory.createValueExpression(value, String.class));
        ValueExpression e = factory.createValueExpression(context, el, boolean.class);
        return (Boolean) e.getValue(context);
    }
    
}
