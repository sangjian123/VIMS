package com.vms.activiti.controller;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.editor.constants.ModelDataJsonConstants;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ModelQuery;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vms.constant.CommonConstant;
import com.vms.controller.BaseController;
import com.vms.utils.GeneralUtils;
import com.vms.utils.I18nUtils;
import com.vms.utils.ServiceUtils;

/**
 * 流程模型控制器
 *
 * @author henryyan
 */
@Controller
@RequestMapping (value = "/workflow/model")
public class ModelController extends BaseController
{
    
    @Autowired
    RepositoryService repositoryService;
    
    /**
     * 模型列表
     */
    @RequestMapping (value = "list")
    public ModelAndView modelList()
    {
        ModelAndView mav = new ModelAndView("workflow/model-list");
        return mav;
    }
    
    /**
     * 模型列表
     *
     * @param request
     * @return
     */
    @RequestMapping (value = "/dataGrid", method = RequestMethod.POST)
    @ResponseBody
    public Object dataGrid(HttpServletRequest request)
    {
        Map<String, Object> map = new HashMap<String, Object>();
        
        ModelQuery query = repositoryService.createModelQuery();
        String modelName = request.getParameter("modelName");
        String modelId = request.getParameter("modelId");
        if(GeneralUtils.isNotNullOrZeroLength(modelName))
        {
            query.modelNameLike("%" + modelName + "%");
        }
        if(GeneralUtils.isNotNullOrZeroLength(modelId))
        {
            query.modelId(modelId);
        }
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        List<Model> list = null;
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            if(CommonConstant.PAGE_PARAM_ORDER_ASC.equals(order))
            {
                if("lastUpdateTime".equals(sortCol))
                {
                    list = query.orderByLastUpdateTime().asc().list();
                }
                else
                {
                    list = query.orderByCreateTime().asc().list();
                }
            }
            else if(CommonConstant.PAGE_PARAM_ORDER_DESC.equals(order))
            {
                if("lastUpdateTime".equals(sortCol))
                {
                    list = query.orderByLastUpdateTime().desc().list();
                }
                else
                {
                    list = query.orderByCreateTime().desc().list();
                }
            }
            
        }
        else
        {
            list = query.orderByLastUpdateTime().desc().orderByCreateTime().desc().list();
        }
        
        map.put("rows", list);
        map.put("total", 0);
        return map;
    }
    
    /**
     * 添加模型页
     *
     * @return
     */
    @RequestMapping (value = "/gotoModelNew", method = RequestMethod.GET)
    public String gotoModelNew(HttpServletRequest request)
    {
        return "workflow/modelAdd";
    }
    
    /**
     * 创建模型
     */
    @RequestMapping (value = "create", method = RequestMethod.POST)
    @ResponseBody
    public Object create(@RequestParam ("name") String name, @RequestParam ("key") String key,
        @RequestParam ("description") String description, HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            String keyStr = StringUtils.defaultString(key);
            String nameStr = StringUtils.defaultString(name);
            if(repositoryService.createModelQuery().modelKey(keyStr).count() > 0)
            {
                return renderError("The same record exists with key!");
            }
            else if(repositoryService.createModelQuery().modelName(nameStr).count() > 0)
            {
                return renderError("The same record exists with name!");
            }
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode editorNode = objectMapper.createObjectNode();
            editorNode.put("id", "canvas");
            editorNode.put("resourceId", "canvas");
            ObjectNode stencilSetNode = objectMapper.createObjectNode();
            stencilSetNode.put("namespace", "http://b3mn.org/stencilset/bpmn2.0#");
            editorNode.put("stencilset", stencilSetNode);
            Model modelData = repositoryService.newModel();
            
            ObjectNode modelObjectNode = objectMapper.createObjectNode();
            modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, nameStr);
            modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, 1);
            String descrtion = StringUtils.defaultString(description);
            modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, descrtion);
            modelData.setMetaInfo(modelObjectNode.toString());
            modelData.setName(nameStr);
            modelData.setKey(keyStr);
            
            repositoryService.saveModel(modelData);
            
            repositoryService.addModelEditorSource(modelData.getId(), editorNode.toString().getBytes("utf-8"));
            
            return renderSuccess(super.getProperty("oper_success"), modelData.getId());
        }
        catch (Exception e)
        {
            logger.error("创建模型失败：", e);
            return renderError(super.getProperty("oper_fail"));
        }
    }
    
    private String analyseAddContent(Model modelData)
    {
        if(modelData == null)
        {
            return "modelData is empty";
        }
        StringBuilder addSb = new StringBuilder();
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("workflow.model-list.nameInput"), modelData.getName(), addSb);
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("workflow.model-list.keyInput"), modelData.getKey(), addSb);
        ServiceUtils.addPropContent(I18nUtils.getI18nMsg("workflow.model-list.descriptionInput"), modelData.getMetaInfo(), addSb);
        if(addSb.length() > 1)
        {
            addSb.setLength(addSb.length() - 1);
        }
        return addSb.toString();
    }
    
    /**
     * 模型设计
     */
    @RequestMapping (value = "goToFlowDesign", method = RequestMethod.POST)
    public void goToFlowDesign(@RequestParam ("modelId") String modelId, HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            response.sendRedirect(request.getContextPath() + "/modeler.html?modelId=" + modelId);
        }
        catch (Exception e)
        {
            logger.error("模型设计失败：", e);
        }
    }
    
    /**
     * 根据Model部署流程
     */
    @RequestMapping (value = "deploy/{modelId}")
    @ResponseBody
    public Map<String, Object> deploy(@PathVariable ("modelId") String modelId, RedirectAttributes redirectAttributes)
    {
        Map<String, Object> result = new HashMap<String, Object>();
        try
        {
            Model modelData = repositoryService.getModel(modelId);
            ObjectNode modelNode =
                (ObjectNode) new ObjectMapper().readTree(repositoryService.getModelEditorSource(modelData.getId()));
            byte[] bpmnBytes = null;
            
            BpmnModel model = new BpmnJsonConverter().convertToBpmnModel(modelNode);
            bpmnBytes = new BpmnXMLConverter().convertToXML(model);
            
            String modelName = modelData.getName();
            if(GeneralUtils.isNullOrZeroLength(modelName))
            {
                modelName = "New Model";
            }
            String processName = modelName.replace(".bpmn20.xml", "") + ".bpmn20.xml";
            Deployment deployment =
                repositoryService.createDeployment().name(modelName).addString(processName, new String(bpmnBytes)).deploy();
            redirectAttributes.addFlashAttribute("message", "部署成功，部署ID=" + deployment.getId());
            result.put("message", 1);
        }
        catch (Exception e)
        {
            logger.error("根据模型部署流程失败：modelId={}", modelId, e);
        }
        return result;
    }
    
    /**
     * 导出model对象为指定类型
     *
     * @param modelId 模型ID
     * @param type    导出文件类型(bpmn\json)
     */
    @RequestMapping (value = "export/{modelId}/{type}")
    public void export(@PathVariable ("modelId") String modelId, @PathVariable ("type") String type, HttpServletResponse response)
    {
        try
        {
            Model modelData = repositoryService.getModel(modelId);
            BpmnJsonConverter jsonConverter = new BpmnJsonConverter();
            byte[] modelEditorSource = repositoryService.getModelEditorSource(modelData.getId());
            
            JsonNode editorNode = new ObjectMapper().readTree(modelEditorSource);
            BpmnModel bpmnModel = jsonConverter.convertToBpmnModel(editorNode);
            
            // 处理异常
            if(bpmnModel.getMainProcess() == null)
            {
                response.setStatus(HttpStatus.UNPROCESSABLE_ENTITY.value());
                response.getOutputStream().println("no main process, can't export for type: " + type);
                response.flushBuffer();
                return;
            }
            
            String filename = "";
            byte[] exportBytes = null;
            
            String mainProcessId = bpmnModel.getMainProcess().getId();
            
            if(type.equals("bpmn"))
            {
                
                BpmnXMLConverter xmlConverter = new BpmnXMLConverter();
                exportBytes = xmlConverter.convertToXML(bpmnModel);
                
                filename = mainProcessId + ".bpmn20.xml";
            }
            else if(type.equals("json"))
            {
                
                exportBytes = modelEditorSource;
                filename = mainProcessId + ".json";
                
            }
            
            ByteArrayInputStream in = null;
            if(exportBytes != null)
            {
                in = new ByteArrayInputStream(exportBytes);
                IOUtils.copy(in, response.getOutputStream());
            }
            
            response.setHeader("Content-Disposition", "attachment; filename=" + filename);
            response.flushBuffer();
        }
        catch (Exception e)
        {
            logger.error("导出model的xml文件失败：modelId={}, type={}", modelId, type, e);
        }
    }
    
    @RequestMapping (value = "delete/{modelId}")
    public String delete(@PathVariable ("modelId") String modelId)
    {
        
        repositoryService.deleteModel(modelId);
        return "redirect:/workflow/model/list";
    }
    
}
