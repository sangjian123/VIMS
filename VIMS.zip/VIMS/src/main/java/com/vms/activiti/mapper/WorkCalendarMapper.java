package com.vms.activiti.mapper;

import java.util.List;
import java.util.Map;

import com.vms.activiti.model.WorkCalendar;

public interface WorkCalendarMapper
{
    void initWorkCalendar(List<WorkCalendar> calendars);
    
    void updateWorkCalendar(List<WorkCalendar> calendars);
    
    List<WorkCalendar> findWorkCalendars(WorkCalendar calendar);
    
    void updateWorkCalendarForMonth(WorkCalendar calendar);
    
    List<String> queryWorkCalendarByMonth(WorkCalendar calendar);
    
    String findMaxYear();
    
    List<WorkCalendar> findWorkCalendarByRange(Map<String, Object> params);
    
    void updateWorkCalendarByMonth(WorkCalendar workCalendar);
}
