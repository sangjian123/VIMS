package com.vms.activiti.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.ReadOnlyProcessDefinition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.vms.activiti.model.ActCheckDesc;
import com.vms.activiti.model.ActHiTaskinst;
import com.vms.activiti.service.ActHiTaskinstService;
import com.vms.constant.CommonConstant;
import com.vms.constant.GeneralConstant;
import com.vms.controller.BaseController;
import com.vms.model.Organization;
import com.vms.model.Page;
import com.vms.utils.GeneralUtils;

@Scope ("prototype")
@Controller
@RequestMapping ("/actHiTaskinst")
public class ActHiTaskinstController extends BaseController
{
    
    @Autowired
    private ActHiTaskinstService actHiTaskinstService;
    
    @Autowired
    private RepositoryService repositoryService;
    
    @RequestMapping ("")
    public String index()
    {
        return "/oa/index";
    }
    
    @RequestMapping ("/first")
    public String first(Model model)
    {
        //所有流程名称 pname id
        List<ActHiTaskinst> list = actHiTaskinstService.quaryPnameByPage();
        list.add(0, null);
        model.addAttribute("extra", list);
        Organization organization = getOrganization();
        model.addAttribute("organization", organization);
        return "/oa/actHiTaskinst";
    }
    
    /**
     * 查询流程节点信息
     * act_ru_task act_ru_execution s_app ACT_RE_PROCDEF t_sys_organization act_hi_procinst act_ru_identitylink
     * 	liuchang
     */
    
    @RequestMapping ("/actHiTaskinstList")
    @ResponseBody
    public Map<String, Object> lineLosslist(HttpServletRequest request)
    {
        
        ActHiTaskinst actHiTaskinst = new ActHiTaskinst();
        String applyState = request.getParameter("applyState");
        if(GeneralUtils.isNotNullOrZeroLength(applyState))
        {
            actHiTaskinst.setApplyState(applyState.trim());
        }
        String appNo = request.getParameter("appNo");
        if(GeneralUtils.isNotNullOrZeroLength(appNo))
        {
            actHiTaskinst.setAppNo(appNo.trim());
        }
        String eDate = request.getParameter("eDate");
        if(GeneralUtils.isNotNullOrZeroLength(eDate))
        {
            actHiTaskinst.seteDate(eDate);
        }
        String bDate = request.getParameter("bDate");
        if(GeneralUtils.isNotNullOrZeroLength(bDate))
        {
            actHiTaskinst.setbDate(bDate);
        }
        String id = request.getParameter("id");
        if(GeneralUtils.isNotNullOrZeroLength(id))
        {
            actHiTaskinst.setId(id.trim());
        }
        String pname = request.getParameter("pname");
        if(GeneralUtils.isNotNullOrZeroLength(pname))
        {
            actHiTaskinst.setPname(pname);
        }
        String name = request.getParameter("name");
        if(GeneralUtils.isNotNullOrZeroLength(name))
        {
            actHiTaskinst.setName(name.trim());
        }
        String procInstId = request.getParameter("procInstId");
        if(GeneralUtils.isNotNullOrZeroLength(procInstId))
        {
            actHiTaskinst.setProcInstId(procInstId);
        }
        String suspensionState = request.getParameter("suspensionState");
        if(GeneralUtils.isNotNullOrZeroLength(suspensionState))
        {
            actHiTaskinst.setSuspensionState(suspensionState);
        }
        String psOrgNo = request.getParameter("orgNo");
        if(GeneralUtils.isNotNullOrZeroLength(psOrgNo))
        {
            actHiTaskinst.setPsOrgNo(psOrgNo);
        }
        else
        {
            actHiTaskinst.setPsOrgNo(String.valueOf(super.getOrganization().getId()));
        }
        //模糊查询 consName startUserId userId
        String consName = request.getParameter("consName");
        if(GeneralUtils.isNotNullOrZeroLength(consName))
        {
            consName = consName.trim();
            consName = consName.replaceAll("_", "/_");
            consName = consName.replaceAll("%", "/%");
            actHiTaskinst.setConsName(consName);
        }
        String userId = request.getParameter("userId");
        if(GeneralUtils.isNotNullOrZeroLength(userId))
        {
            userId = userId.trim();
            userId = userId.replaceAll("_", "/_");
            userId = userId.replaceAll("%", "/%");
            actHiTaskinst.setUserId(userId);
        }
        String startUserId = request.getParameter("startUserId");
        if(GeneralUtils.isNotNullOrZeroLength(startUserId))
        {
            startUserId = startUserId.trim();
            startUserId = startUserId.replaceAll("_", "/_");
            startUserId = startUserId.replaceAll("%", "/%");
            actHiTaskinst.setStartUserId(startUserId);
        }
        // 组合标志
        Page<ActHiTaskinst> page = new Page<ActHiTaskinst>(actHiTaskinst);
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            if("handleTime".equals(sortCol))
            {
                sortCol = "HANDLE_TIME";
            }
            
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        page.setPageNo(getCurrentPage(request));
        page.setPageSize(getPageSize(request));
        return ajaxResult(actHiTaskinstService.findgActHiTaskinstByPage(page), true);
    }
    
    @RequestMapping ("/doubleInfo")
    public String doubleInfo(String procInstId, String appNo, Model model)
    {
        model.addAttribute("procInstId", procInstId);
        model.addAttribute("appNo", appNo);
        return "/oa/doubleInfo";
    }
    
    /**
     * 查询 历史任务实例表
     * act_hi_taskinst
     * 	liuchang
     */
    
    @RequestMapping ("/taskinst")
    @ResponseBody
    public Map<String, Object> taskinst(HttpServletRequest request, HttpServletResponse response)
    {
        
        ActHiTaskinst actHiTaskinst = new ActHiTaskinst();
        String procInstId = request.getParameter("procInstId");
        String appNo = request.getParameter("appNo");
        if(GeneralUtils.isNotNullOrZeroLength(procInstId))
        {
            actHiTaskinst.setProcInstId(procInstId.trim());
        }
        if(GeneralUtils.isNotNullOrZeroLength(appNo))
        {
            actHiTaskinst.setAppNo(appNo.trim());
        }
        Map<String, Object> map = new HashMap<String, Object>();
        Page<ActHiTaskinst> page = new Page<ActHiTaskinst>(actHiTaskinst);
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            if("startTime".equals(sortCol))
            {
                sortCol = "START_TIME_";
            }
            if("endTime".equals(sortCol))
            {
                sortCol = "END_TIME_";
            }
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        page.setPageNo(Integer.parseInt(request.getParameter("page")));
        page.setPageSize(Integer.parseInt(request.getParameter("rows")));
        page = actHiTaskinstService.findTaskinstByPage(page);
        map.put("rows", page.getResults());
        map.put("total", page.getTotalRecord());
        return map;
    }
    
    /**
     * 根据流程名称 id 查询节点名称
     * 
     * 	liuchang
     */
    
    @RequestMapping ("/quaryName")
    public @ResponseBody Object quaryName(String name, HttpServletRequest request)
    {
        //所有流程名称 pname name
        ActHiTaskinst actHiTaskinst = new ActHiTaskinst();
        actHiTaskinst.setPname(name);
        List<ActHiTaskinst> revList = new ArrayList<ActHiTaskinst>();
        List<ActHiTaskinst> list = actHiTaskinstService.quaryName(actHiTaskinst);
        if(CollectionUtils.isNotEmpty(list))
        {
            ReadOnlyProcessDefinition deployedProcessDefinition =
                (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(list.get(0)
                    .getId());
            List<ActivityImpl> activities = (List<ActivityImpl>) deployedProcessDefinition.getActivities();
            ActHiTaskinst temp;
            Object actName;
            for(ActivityImpl activityImpl : activities)
            {
                actName = activityImpl.getProperty("name");
                if(null != actName)
                {
                    temp = new ActHiTaskinst();
                    temp.setName(String.valueOf(actName));
                    revList.add(temp);
                }
            }
        }
        return JSON.toJSON(revList);
    }
    
    /**
     * 环节操作备注
     * 
     *
     */
    @RequestMapping ("/insertActDesc")
    @ResponseBody
    public Object insertActDesc(ActCheckDesc actCheckDesc)
    {
        int rt = actHiTaskinstService.insertActDesc(actCheckDesc);
        if(rt == 1)
        {
            return renderSuccess(super.getProperty("oper_success"));
        }
        else
        {
            return renderError(super.getProperty("oper_fail"));
        }
    }
    
    @RequestMapping ("/processedActHiTaskList")
    @ResponseBody
    public Map<String, Object> processedActHiTaskList(HttpServletRequest request)
    {
        
        ActHiTaskinst actHiTaskinst = new ActHiTaskinst();
        String applyState = request.getParameter("applyState");
        if(GeneralUtils.isNotNullOrZeroLength(applyState))
        {
            actHiTaskinst.setApplyState(applyState.trim());
        }
        String appNo = request.getParameter("appNo");
        if(GeneralUtils.isNotNullOrZeroLength(appNo))
        {
            actHiTaskinst.setAppNo(appNo.trim());
        }
        String eDate = request.getParameter("eDate");
        if(GeneralUtils.isNotNullOrZeroLength(eDate))
        {
            actHiTaskinst.seteDate(eDate);
        }
        String bDate = request.getParameter("bDate");
        if(GeneralUtils.isNotNullOrZeroLength(bDate))
        {
            actHiTaskinst.setbDate(bDate);
        }
        String id = request.getParameter("id");
        if(GeneralUtils.isNotNullOrZeroLength(id))
        {
            actHiTaskinst.setId(id.trim());
        }
        String pname = request.getParameter("pname");
        if(GeneralUtils.isNotNullOrZeroLength(pname))
        {
            actHiTaskinst.setPname(pname);
        }
        String name = request.getParameter("name");
        if(GeneralUtils.isNotNullOrZeroLength(name))
        {
            actHiTaskinst.setName(name.trim());
        }
        String procInstId = request.getParameter("procInstId");
        if(GeneralUtils.isNotNullOrZeroLength(procInstId))
        {
            actHiTaskinst.setProcInstId(procInstId);
        }
        String suspensionState = request.getParameter("suspensionState");
        if(GeneralUtils.isNotNullOrZeroLength(suspensionState))
        {
            actHiTaskinst.setSuspensionState(suspensionState);
        }
        String psOrgNo = request.getParameter("psOrgNo");
        if(GeneralUtils.isNotNullOrZeroLength(psOrgNo))
        {
            actHiTaskinst.setPsOrgNo(psOrgNo);
        }
        else
        {
            actHiTaskinst.setPsOrgNo(String.valueOf(super.getOrganization().getId()));
        }
        //模糊查询processUser
        String processUser = request.getParameter("processUser");
        processUser = getCurrentUser().getId();
        processUser = processUser.trim();
        processUser = processUser.replaceAll("_", "/_");
        processUser = processUser.replaceAll("%", "/%");
        actHiTaskinst.setProcessUser(processUser);
        String userId = request.getParameter("userId");
        if(GeneralUtils.isNotNullOrZeroLength(userId))
        {
            userId = userId.trim();
            userId = userId.replaceAll("_", "/_");
            userId = userId.replaceAll("%", "/%");
            actHiTaskinst.setUserId(userId);
        }
        String startUserId = request.getParameter("startUserId");
        if(GeneralUtils.isNotNullOrZeroLength(startUserId))
        {
            startUserId = startUserId.trim();
            startUserId = startUserId.replaceAll("_", "/_");
            startUserId = startUserId.replaceAll("%", "/%");
            actHiTaskinst.setStartUserId(startUserId);
        }
        // 组合标志
        Page<ActHiTaskinst> page = new Page<ActHiTaskinst>(actHiTaskinst);
        String sortCol = request.getParameter(CommonConstant.PAGE_PARAM_ORDER_COL);
        String order = request.getParameter(CommonConstant.PAGE_PARAM_ORDER);
        if(StringUtils.isNotEmpty(sortCol) && StringUtils.isNotEmpty(order))
        {
            if("handleTime".equals(sortCol))
            {
                sortCol = "HANDLE_TIME";
            }
            
            Map<String, Object> params = new HashMap<String, Object>();
            params.put("order", sortCol + GeneralConstant.SPACE + order);
            page.setConditions(params);
        }
        page.setPageNo(getCurrentPage(request));
        page.setPageSize(getPageSize(request));
        return ajaxResult(actHiTaskinstService.processedActHiTaskinstByPage(page), true);
    }
}
