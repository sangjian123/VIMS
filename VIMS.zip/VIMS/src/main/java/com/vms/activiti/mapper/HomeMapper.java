package com.vms.activiti.mapper;

import java.util.List;
import java.util.Map;

import com.vms.activiti.model.PanelInfo;
import com.vms.activiti.model.RunActTime;
import com.vms.activiti.model.SystemNotice;
import com.vms.model.Page;
import com.vms.model.SystemMessageInfo;
import com.vms.model.User;

public interface HomeMapper
{
    List<PanelInfo> getUserPanelInfo(String userId);
    
    List<PanelInfo> getRolePanelInfo(String roleId);
    
    List<SystemMessageInfo> querySystemTopMessageList(Page<SystemMessageInfo> page);
    
    void insertSystemMessage(SystemMessageInfo messageInfo);
    
    void insertBatchMessages(List<SystemMessageInfo> msgList);
    
    List<String> querySysMsgsByIds(List<SystemMessageInfo> msgList);
    
    List<SystemNotice> querySystemNoticeList(SystemNotice systemNotice);
    
    void deleteAllMessages();
    
    void updateBatchMsgStatus(Map<String, Object> params);
    
    void insertBatchMsgToOld(String status);
    
    void deleteBatchOldMsg(String status);
    
    List<RunActTime> queryRunActTimeByIds(List<RunActTime> runActList);
    
    void insertBatchRunActTimes(List<RunActTime> msgList);
    
    void deleteOldRunTaskTime(String status);
    
    void updateBatchRunActTime(List<RunActTime> msgList);
    
    void updateBatchRunActStatus(List<RunActTime> msgList);
    
    void deleteAllRunActTime();
    
    void deleteMultRunTaskTime();
    
    void updateUserWebGuide(User user);
    
}
