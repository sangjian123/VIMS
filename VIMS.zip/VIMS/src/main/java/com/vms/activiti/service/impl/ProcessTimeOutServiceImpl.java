package com.vms.activiti.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vms.activiti.entity.act.ProcessTimeOut;
import com.vms.activiti.mapper.ProcessTimeOutMapper;
import com.vms.activiti.service.ProcessTimeOutService;
import com.vms.model.Page;
import com.vms.utils.ConfigHolder;
import com.vms.utils.UUIDUtils;

@Service
@Transactional
public class ProcessTimeOutServiceImpl implements ProcessTimeOutService
{
    @Autowired
    private ProcessTimeOutMapper processTimeOutMapper;
    
    @Autowired
    protected RepositoryService repositoryService;
    
    @Override
    public Page<ProcessTimeOut> queryProcessTimeOutByPage(Page<ProcessTimeOut> page)
    {
        
        String procDefId = page.getParams().getProcDefId();
        String procName = page.getParams().getProcName();
        
        ProcessDefinitionEntity processDefinition =
            (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(procDefId);
        List<ActivityImpl> activitiList = processDefinition.getActivities();
        List<String> activitiName = new ArrayList<>();
        for(ActivityImpl a : activitiList)
        {
            Object name = a.getProperty("name");
            if(name != null)
            {
                activitiName.add((String) name);
            }
            
        }
        List<ProcessTimeOut> list = processTimeOutMapper.queryProcessTimeOutByPage(page);
        
        List<ProcessTimeOut> rtList = new ArrayList<ProcessTimeOut>();
        
        for(String name : activitiName)
        {
            ProcessTimeOut processTimeOut = new ProcessTimeOut();
            for(ProcessTimeOut p : list)
            {
                if(name.equals(p.getTaskName()))
                {
                    processTimeOut = p;
                    break;
                }
            }
            String id = processTimeOut.getId();
            if(id == null || id.length() <= 0)
            {
                processTimeOut.setDayNum(Integer.parseInt(ConfigHolder.getCfg("FLOW_TIME_OUT_DAY")));
                processTimeOut.setTimeType("01");
                processTimeOut.setTaskName(name);
                processTimeOut.setProcDefId(procDefId);
                processTimeOut.setProcName(procName);
            }
            rtList.add(processTimeOut);
        }
        
        page.setResults(rtList);
        return page;
    }
    
    @Override
    public int insertOrEditProcessTimeOut(ProcessTimeOut processTimeOut)
    {
        int rt;
        String id = processTimeOut.getId();
        if(id == null || id.length() <= 0)
        {
            String uuid = UUIDUtils.generate16Str();
            processTimeOut.setId(uuid);
            rt = processTimeOutMapper.insertProcessTimeOut(processTimeOut);
        }
        else
        {
            rt = processTimeOutMapper.editProcessTimeOut(processTimeOut);
        }
        return rt;
    }
    
    @Override
    public ProcessTimeOut queryProcessTimeOutById(String id)
    {
        
        return processTimeOutMapper.queryProcessTimeOutById(id);
    }
    
    @Override
    public String analyseEditContent(ProcessTimeOut old, ProcessTimeOut processTimeOut)
    {
        
        if(old == null)
        {
            old = new ProcessTimeOut();
            old.setDayNum(Integer.parseInt(ConfigHolder.getCfg("FLOW_TIME_OUT_DAY")));
            old.setTaskName(processTimeOut.getTaskName());
            old.setTimeType(processTimeOut.getTimeType());
        }
        return old.toString() + " -> " + processTimeOut.toString();
    }
    
}