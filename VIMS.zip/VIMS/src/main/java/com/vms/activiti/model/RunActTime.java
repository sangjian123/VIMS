package com.vms.activiti.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class RunActTime implements Serializable
{
    
    /**
     * 
     */
    private static final long serialVersionUID = 388754274010014864L;
    
    private Long id;
    
    private String procDefId;
    
    private String processInstId;
    
    private String taskId;
    
    /**
     * 1-新增,2-变更,3-销户,4-其它
     */
    private String flowType;
    
    /**
     * 01-正常,02-即将超时,03-超时
     */
    private String taskStatus;
    
    /**
     * 01-新装,02-抄表,03-收费,04-勘查,05-勘查
     */
    private String taskType;
    
    private String userId;
    
    private String status;
    
    private Timestamp lastCompTime;
    
    private Timestamp updateTime;
    
    public Long getId()
    {
        return id;
    }
    
    public void setId(Long id)
    {
        this.id = id;
    }
    
    public String getProcDefId()
    {
        return procDefId;
    }
    
    public void setProcDefId(String procDefId)
    {
        this.procDefId = procDefId;
    }
    
    public String getProcessInstId()
    {
        return processInstId;
    }
    
    public void setProcessInstId(String processInstId)
    {
        this.processInstId = processInstId;
    }
    
    public String getTaskId()
    {
        return taskId;
    }
    
    public void setTaskId(String taskId)
    {
        this.taskId = taskId;
    }
    
    public String getTaskStatus()
    {
        return taskStatus;
    }
    
    public void setTaskStatus(String taskStatus)
    {
        this.taskStatus = taskStatus;
    }
    
    public String getTaskType()
    {
        return taskType;
    }
    
    public void setTaskType(String taskType)
    {
        this.taskType = taskType;
    }
    
    public String getUserId()
    {
        return userId;
    }
    
    public void setUserId(String userId)
    {
        this.userId = userId;
    }
    
    public Timestamp getLastCompTime()
    {
        return lastCompTime;
    }
    
    public void setLastCompTime(Timestamp lastCompTime)
    {
        this.lastCompTime = lastCompTime;
    }
    
    public Timestamp getUpdateTime()
    {
        return updateTime;
    }
    
    public void setUpdateTime(Timestamp updateTime)
    {
        this.updateTime = updateTime;
    }
    
    public String getFlowType()
    {
        return flowType;
    }
    
    public void setFlowType(String flowType)
    {
        this.flowType = flowType;
    }
    
    public String getStatus()
    {
        return status;
    }
    
    public void setStatus(String status)
    {
        this.status = status;
    }
    
}
