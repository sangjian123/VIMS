package com.vms.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.vms.utils.DownloadUtils;

@Controller
@RequestMapping ("/test")
public class TestController
{
    
    @RequestMapping ("index")
    public String index()
    {
        return "test/index";
    }
    
    @RequestMapping (value = "/download")
    public void courseTab(HttpServletResponse response, HttpServletRequest request) throws IOException
    {
        String path = request.getSession().getServletContext().getRealPath("/index.jsp");
        DownloadUtils.download(response, path, "temp.jsp");
    }
}
