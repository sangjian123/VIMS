package com.vms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.util.StringUtils;

import com.vms.constant.CommonConstant;
import com.vms.model.DriverDetailInfo;
import com.vms.model.DriverInfo;
import com.vms.service.DriverService;
import com.vms.utils.ExportExecl;

import org.apache.poi.util.IOUtils;

import com.alibaba.fastjson.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/driver")
public class DriverController extends BaseController 
{
	@Autowired
	private DriverService driverService;
	
	private static final String EXPORT_TITLE_KEY = "username,time,startmile,endmile,todaymile";

	@RequestMapping("/query")
	@ResponseBody
	public Object query(HttpServletRequest request) 
	{
		Map<String, Object> map = new HashMap<String, Object>();
		
		String driverName = request.getParameter(CommonConstant.DRIVER_NAME);

		List<DriverInfo> driverInfo = driverService.queryDriverInfo(driverName);

		map.put("list", driverInfo);
		return renderSuccess(map);

	}
	
	
	@RequestMapping("/queryDetailInfo")
	@ResponseBody
	public Object queryDetailInfo(HttpServletRequest request) 
	{
		Map<String, Object> map = new HashMap<String, Object>();
		
		String driverName = request.getParameter(CommonConstant.DRIVER_NAME);
		
        String startTime = request.getParameter(CommonConstant.START_TIME);
        
        String endTime = request.getParameter(CommonConstant.END_TIME);

		List<DriverDetailInfo> driverInfo = driverService.queryDetailInfo(driverName,startTime,endTime);

		map.put("list", driverInfo);
		return renderSuccess(map);

	}
	
	
	@RequestMapping(value = "/exportDetailInfo")
	@ResponseBody
	public Map<String, Object> exportUserInfo(HttpServletRequest request,HttpServletResponse response) 
	{
		
		String driverName = request.getParameter(CommonConstant.DRIVER_NAME);
		
        String startTime = request.getParameter(CommonConstant.START_TIME);
        
        String endTime = request.getParameter(CommonConstant.END_TIME);

		List<DriverDetailInfo> driverInfo = driverService.queryDetailInfo(driverName,startTime,endTime);
		
		BufferedInputStream bins = null;
		OutputStream outs = null;
		BufferedOutputStream bouts = null;
		
		try {
			// 获取excel列字段名
			String[] line = convertToList();
			byte[] b = ExportExecl.createExl(driverInfo,EXPORT_TITLE_KEY.split(","), line);

			bins = new BufferedInputStream(new ByteArrayInputStream(b));
			outs = response.getOutputStream();
			bouts = new BufferedOutputStream(outs);
			response.setContentType("application/x-download");
			Date date = new Date();
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String filename = "exportUserInfos" + format.format(date) + ".xls";
			
			// 设置response内容的类型
			response.setHeader("Content-disposition", "attachment;filename="+ filename);
			
			// 设置头部信息
			int bytesRead = 0;
			byte[] buffer1 = new byte[1024];
			while ((bytesRead = bins.read(buffer1, 0, buffer1.length)) != -1) 
			{
				bouts.write(buffer1, 0, bytesRead);
			}
			bouts.flush();
		} 
		catch (Exception e) 
		{
		} 
		finally 
		{
			IOUtils.closeQuietly(bins);
			IOUtils.closeQuietly(outs);
			IOUtils.closeQuietly(bouts);
		}

		return null;
	}

	private String[] convertToList() 
	{
		String[] line = new String[2];
		try {
			line[0] = ("username");// 用户名称
			line[1] = ("time");// 用户编号
			line[2] = ("startmile");// 用户编号
			line[3] = ("endmile");// 用户编号
			line[4] = ("todaymile");// 用户编号
		} catch (Exception e) {
			logger.error("", e);
		}
		return line;
	}

}