package com.vms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping ("/")
public class RouterController
{
    
    /*@RequestMapping (value = "/login")
    public String login()
    {
        return "login/login";
    }
    
    @RequestMapping (value = "/home")
    public String home()
    {
        return "home/home";
    }*/
    
    @RequestMapping (value = "/liveVideo")
    public String liveVideo()
    {
        return "service/liveVideo";
    }
    
    @RequestMapping (value = "/videoPlayback")
    public String videoPlayback()
    {
        return "service/videoPlayback";
    }
    
    @RequestMapping (value = "/vehiclePosition")
    public String vehiclePosition()
    {
        return "service/vehiclePosition";
    }
    
    @RequestMapping (value = "/historyTrack")
    public String historyTrack()
    {
        return "service/historyTrack";
    }
    
    @RequestMapping (value = "/runReport")
    public String runReport()
    {
        return "service/runReport";
    }
    
    @RequestMapping (value = "/dailyMileageReportForDrivers")
    public String dailyMileageReportForDrivers()
    {
        return "service/dailyMileageReportForDrivers";
    }
}
