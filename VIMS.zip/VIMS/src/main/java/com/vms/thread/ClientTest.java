package com.vms.thread;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

public class ClientTest 
{

	public Socket socket = null;

	public static final String host = "localhost";

	public ClientTest() throws IOException {

		System.out.println("Client is Started.....");
	}

	public static void main(String[] args) throws Exception 
	{
		new ClientTest().Service();

	}

	public void Service() throws IOException, Exception {

		while (true) {

			try {

				socket = new Socket(InetAddress.getLocalHost(), 9998);

				BufferedReader input = getReader(socket);
				PrintWriter out = getWriter(socket);

				System.out.print("Pls input inforation to Server....:");

				BufferedReader local = new BufferedReader(
						new InputStreamReader(System.in));

				String msg = local.readLine();
				out.println("1234570$GPRMC,115656.00,A,3200.299502,N,11845.584927,E,0.0,181.9,030618,4.7,W,A*21");

				System.out.println("Respons from Server is: "
						+ input.readLine());

				if ("bye".equals(msg)) {
					System.out.println("Client will close the connection...");
					break;
				}

			} finally {
				if (socket != null) {
					try {
						socket.close();
					} catch (IOException e) {
						socket = null;
						System.out.println("客户端 finally 异常:" + e.getMessage());
					}
				}
			}

		}

	}

	public BufferedReader getReader(Socket socket) throws IOException {
		return new BufferedReader(
				new InputStreamReader(socket.getInputStream()));
	}

	public PrintWriter getWriter(Socket socket) throws IOException {
		return new PrintWriter(socket.getOutputStream(), true);
	}
}
