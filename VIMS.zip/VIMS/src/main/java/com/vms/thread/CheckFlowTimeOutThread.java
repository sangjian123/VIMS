package com.vms.thread;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.FormService;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.vms.activiti.mapper.ActHiTaskinstMapper;
import com.vms.activiti.mapper.HomeMapper;
import com.vms.activiti.mapper.ProcActTimeMapper;
import com.vms.activiti.mapper.WorkCalendarMapper;
import com.vms.activiti.model.ActHiTaskinst;
import com.vms.activiti.model.ProcActTime;
import com.vms.activiti.model.RunActTime;
import com.vms.activiti.model.WorkCalendar;
import com.vms.activiti.service.FlowTimeOutService;
import com.vms.constant.Config;
import com.vms.constant.ConstantCode;
import com.vms.model.SystemMessageInfo;
import com.vms.utils.ConfigHolder;
import com.vms.utils.FlowTypeUtils;
import com.vms.utils.UUIDUtils;

/**
 * 检验工作流超时
 */
public class CheckFlowTimeOutThread implements Runnable
{
    private static final Logger LOGGER = LoggerFactory.getLogger(CheckFlowTimeOutThread.class);
    
    private static String MSG_STATUS = null;
    
    @Autowired
    private FlowTimeOutService flowTimeOutService;
    
    @Autowired
    private ActHiTaskinstMapper actHiTaskinstMapper;
    
    @Autowired
    private ProcActTimeMapper procActTimeMapper;
    
    @Autowired
    private WorkCalendarMapper workCalendarMapper;
    
    @Autowired
    private HomeMapper homeMapper;
    
    @Autowired
    private FormService formService;
    
    @Override
    public void run()
    {
        scanFlowTimeout();
    }
    
    /**
    * 扫描代办任务
    */
    private void scanFlowTimeout()
    {
        LOGGER.info("CheckFlowTimeOutThread start.");
        List<ActHiTaskinst> taskList = null;
        List<SystemMessageInfo> msgList = null;
        List<String> existIds = null;
        Map<String, Object> map = new HashMap<String, Object>();
        int startIndex = 0;
        int batch = 500;
        int endIndex = batch;
        ProcActTime actTime;
        long dayNum = 7;
        try
        {
            dayNum = Long.valueOf(ConfigHolder.getCfg("FLOW_TIME_OUT_DAY"));
        }
        catch (NumberFormatException e)
        {
            LOGGER.error("scanFlowTimeout get FLOW_TIME_OUT_DAY error : ", e);
            dayNum = 7;
        }
        long spaceNum = 2;
        try
        {
            spaceNum = Long.valueOf(ConfigHolder.getCfg("TASK_REMAINING_DAYS"));
        }
        catch (NumberFormatException e)
        {
            LOGGER.error("scanFlowTimeout get TASK_REMAINING_DAYS error : ", e);
            spaceNum = 2;
        }
        long curDate = new Date().getTime();
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("startDay", new Date(curDate - Config.DAY_TIME * (dayNum + 32)));
        params.put("endDay", new Date(curDate + Config.DAY_TIME * (dayNum + 32)));
        SystemMessageInfo msg;
        Timestamp curTime;
        List<RunActTime> runActList;
        List<RunActTime> existRunActList;
        List<RunActTime> updateActList;
        RunActTime runActTime;
        try
        {
            String msgStatus = getMSG_STATUS();
            if(null == msgStatus)
            {
                setMSG_STATUS(ConstantCode.STRING_2);
                homeMapper.deleteAllMessages();
                homeMapper.deleteAllRunActTime();
            }
            else if(ConstantCode.STRING_0.equals(msgStatus))
            {
                setMSG_STATUS(ConstantCode.STRING_1);
            }
            else
            {
                setMSG_STATUS(ConstantCode.STRING_0);
            }
            if(!ConstantCode.STRING_2.equals(msgStatus))
            {
                homeMapper.deleteMultRunTaskTime();
            }
            msgStatus = getMSG_STATUS();
            List<WorkCalendar> dayList = workCalendarMapper.findWorkCalendarByRange(params);
            List<ProcActTime> actTimeList = procActTimeMapper.findAllProcActTime();
            String taskStatus;
            while(true)
            {
                map.put("START_INDEX", startIndex);
                map.put("END_INDEX", endIndex);
                taskList = actHiTaskinstMapper.findGridTaskByBatch(map);
                if(CollectionUtils.isEmpty(taskList))
                {
                    break;
                }
                runActList = new ArrayList<RunActTime>();
                msgList = new ArrayList<SystemMessageInfo>();
                curTime = new Timestamp(System.currentTimeMillis());
                for(ActHiTaskinst act : taskList)
                {
                    runActTime = new RunActTime();
                    runActTime.setStatus(msgStatus);
                    flowTimeOutService.copyProperties(act, runActTime);
                    runActTime.setFlowType(FlowTypeUtils.getFlowType(act.getPname()));
                    actTime = flowTimeOutService.findActTime(actTimeList, act);
                    taskStatus = flowTimeOutService.checkActTimeOutStatus(dayList, actTime, act, dayNum, spaceNum, runActTime);
                    runActTime.setTaskStatus(taskStatus);
                    if(ConstantCode.STRING_03.equals(taskStatus))
                    {
                        msg = new SystemMessageInfo();
                        msg.setCreateTime(curTime);
                        msg.setStatus(msgStatus);
                        copyProperties(act, msg);
                        msgList.add(msg);
                    }
                    runActList.add(runActTime);
                }
                if(CollectionUtils.isNotEmpty(msgList))
                {
                    if(!ConstantCode.STRING_2.equals(msgStatus))
                    {
                        existIds = homeMapper.querySysMsgsByIds(msgList);
                        if(CollectionUtils.isNotEmpty(existIds))
                        {
                            filterMsgList(existIds, msgList);
                            if(CollectionUtils.isNotEmpty(msgList))
                            {
                                homeMapper.insertBatchMessages(msgList);
                            }
                            params.put("STATUS", msgStatus);
                            params.put("MSGIDS", existIds);
                            homeMapper.updateBatchMsgStatus(params);
                        }
                        else
                        {
                            homeMapper.insertBatchMessages(msgList);
                        }
                        existIds.clear();
                    }
                    else
                    {
                        homeMapper.insertBatchMessages(msgList);
                    }
                }
                
                taskList.clear();
                msgList.clear();
                
                existRunActList = homeMapper.queryRunActTimeByIds(runActList);
                if(CollectionUtils.isNotEmpty(existRunActList))
                {
                    if(!ConstantCode.STRING_2.equals(msgStatus))
                    {
                        updateActList = flowTimeOutService.filterAndGetUpList(existRunActList, runActList, msgStatus);
                        if(CollectionUtils.isNotEmpty(runActList))
                        {
                            homeMapper.insertBatchRunActTimes(runActList);
                        }
                        if(CollectionUtils.isNotEmpty(updateActList))
                        {
                            homeMapper.updateBatchRunActTime(updateActList);
                            flowTimeOutService.filterExistList(existRunActList, updateActList);
                            if(CollectionUtils.isNotEmpty(existRunActList))
                                homeMapper.updateBatchRunActStatus(existRunActList);
                            updateActList.clear();
                        }
                        else
                        {
                            if(CollectionUtils.isNotEmpty(existRunActList))
                                homeMapper.updateBatchRunActStatus(existRunActList);
                        }
                    }
                    else
                    {
                        homeMapper.insertBatchRunActTimes(runActList);
                    }
                }
                else
                {
                    homeMapper.insertBatchRunActTimes(runActList);
                }
                
                runActList.clear();
                existRunActList.clear();
                
                startIndex = endIndex;
                endIndex += batch;
            }
            if(!ConstantCode.STRING_2.equals(msgStatus))
            {
                homeMapper.insertBatchMsgToOld(msgStatus);
                homeMapper.deleteBatchOldMsg(msgStatus);
                homeMapper.deleteOldRunTaskTime(msgStatus);
            }
            LOGGER.info("CheckFlowTimeOutThread end.");
        }
        catch (Exception e)
        {
            LOGGER.error("CheckFlowTimeOutThread error : ", e);
        }
    }
    
    private void filterMsgList(List<String> existIds, List<SystemMessageInfo> msgList)
    {
        for(int i = msgList.size() - 1; i > -1; i--)
        {
            if(existIds.contains(msgList.get(i).getTaskId()))
            {
                msgList.remove(i);
            }
        }
    }
    
    /**
     * 获取开始日期
     * @param dayList
     * @param dayNum
     * @return 日期
     */
    private void copyProperties(ActHiTaskinst act, SystemMessageInfo msg)
    {
        msg.setAppId(act.getAppId());
        msg.setProcDefId(act.getProcDefId());
        msg.setProcessInstId(act.getProcInstId());
        msg.setUserId(act.getUserId());
        try
        {
            String customUrl = formService.getTaskFormData(act.getTaskId()).getFormKey();
            msg.setCustomUrl(customUrl);
        }
        catch (Exception e)
        {
            LOGGER.error("getTaskFormData taskId:" + act.getTaskId(), e);
        }
        msg.setTaskId(act.getTaskId());
        msg.setTaskName(act.getTaskName());
        msg.setTaskDefKey(act.getTaskDefKey());
        msg.setMsgTitle(act.getPname());
        StringBuilder sb =
            new StringBuilder().append(act.getConsName() == null ? act.getStartUserId() : act.getConsName()).append("'s ");
        sb.append(act.getTaskName()).append(" of ").append(act.getPname());
        sb.append(" timeout!");
        msg.setMsgText(sb.toString());
        msg.setId(UUIDUtils.generate16Long());
    }
    
    public synchronized static String getMSG_STATUS()
    {
        return MSG_STATUS;
    }
    
    public synchronized static void setMSG_STATUS(String status)
    {
        MSG_STATUS = status;
    }
    
}
