package com.vms.thread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.vms.service.VehicleService;

public class RecordDeviceInfoThread implements Runnable
{
	private static final Logger LOGGER = LoggerFactory.getLogger (RecordDeviceInfoThread.class);
	
	@Autowired
    private VehicleService vehicleService;
	
	private ServerSocket server;
    
    @Override
    public void run ()
    {
        recordServerStatus ();
    }
    
    /**
    * 记录车载更新的数据
    */
    private void recordServerStatus ()
    {
		try 
		{

			ThreadPoolExecutor taskPools =new ThreadPoolExecutor(20, 50, 2, TimeUnit.SECONDS,new LinkedBlockingQueue<Runnable>(500));
			
			//server = new ServerSocket(9998,20, InetAddress.getLocalHost());
			server = new ServerSocket(9998,20);
			
			server.setReuseAddress(true);
			
			//LOGGER.info("New Server information : " + server.getInetAddress()+ ":" + server.getLocalPort() + " Server is Start....");

			while (true) 
			{
				
				Socket socket = null;

				socket = server.accept();
				
				//LOGGER.info("New Connection: " + socket.getInetAddress()+ ":" + socket.getPort());

				taskPools.submit(new HandlerThread(socket,vehicleService));
			}

		} 
		catch (IOException ex) 
		{
			ex.printStackTrace();
		}
		
    	
    }

}
