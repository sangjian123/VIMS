package com.vms.thread;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vms.service.VehicleService;

public class HandlerThread implements Runnable 
{

	private static final Logger LOGGER = LoggerFactory.getLogger (HandlerThread.class);
	
	public static final double X_PI = Math.PI*3000.0/180;
	
    private VehicleService vehicleService;
	
	public Socket socket;

	public HandlerThread(Socket socket,VehicleService vehicleService1) 
	{
		this.socket = socket;
		vehicleService = vehicleService1;
	}
	
	public HandlerThread() 
	{
	}

	public static BufferedReader getReader(Socket socket) throws IOException 
	{
		return new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}

	public static PrintWriter getWriter(Socket socket) throws IOException 
	{
		return new PrintWriter(socket.getOutputStream(),true);
	}

	@Override
	public void run() 
	{
		try 
		{
			
			StringBuffer currentTime = new StringBuffer();
			
			String deviceID = null;
			
			String flag = null;
			
			String dimension = null;
			
			String dimension_flag = null;
			
			String longitude = null;
			
			String longitude_flag = null;

			BufferedReader input = getReader(socket);

			PrintWriter out = getWriter(socket);
			
			String clientInputStr = input.readLine();
			
			String[] reg_gpsInfo = clientInputStr.split(",");
			
			//解析数据 time
			
			//deviceID = reg_gpsInfo[0].substring(5);
			deviceID = reg_gpsInfo[0].substring(0, reg_gpsInfo[0].indexOf("$"));
			
			currentTime.append("20").append(reg_gpsInfo[9].substring(4))
			   .append(reg_gpsInfo[9].substring(2, 4))
			   .append(reg_gpsInfo[9].substring(0, 2)).append("")
			   .append(reg_gpsInfo[1].subSequence(0, reg_gpsInfo[1].indexOf(".")));
			
			String currentLocalTime = utcToLocal(currentTime.toString());

			flag = reg_gpsInfo[2];
			
			//经度
			dimension = String.valueOf((int)Double.parseDouble(reg_gpsInfo[3]) / 100 + Double.parseDouble(String.format("%.8f", Double.parseDouble(String.format("%.6f",Double.parseDouble(reg_gpsInfo[3]) % 100 ))/60)));
			
			dimension_flag = reg_gpsInfo[4];
			
			//经度
			longitude = String.valueOf((int)Double.parseDouble(reg_gpsInfo[5]) / 100 + Double.parseDouble(String.format("%.8f", Double.parseDouble(String.format("%.6f",Double.parseDouble(reg_gpsInfo[5]) % 100 ))/60)));
			
			longitude_flag = reg_gpsInfo[6];
			
			Double[] data = transform2baiduinfo(Double.parseDouble(dimension),Double.parseDouble(longitude));

			vehicleService.updateVehicleInfo(deviceID,flag,String.valueOf(data[0]),dimension_flag,String.valueOf(data[1]),longitude_flag,currentLocalTime);
			
			
			out.close();
			input.close();

		} catch (IOException e) 
		{
			e.printStackTrace();
		}

		finally 
		{
			try 
			{
				if (socket != null)
					socket.close();

			} catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	public static Double[] transform2baiduinfo(double bdLat,double bdLon)
	{
		Double[] data = new Double[2];
		
		double x = bdLon;
		double y = bdLat;
		
		double z = Math.sqrt(x*x + y*y) + 0.00002 * Math.sin(y*HandlerThread.X_PI);
		
		double theta = Math.atan2(y, x) + 0.000003 * Math.cos(x*HandlerThread.X_PI);
		
		double gcLon = z * Math.cos(theta) + 0.0116788;//+ 0.0065;
		
		double gcLat = z * Math.sin(theta) + 0.004423;//+ 0.006;
		
		data[0] = gcLat;
		data[1] = gcLon;
		return data;
	}
	
	public static String utcToLocal(String utcTime)
	{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date utcDate = null;
        try 
        {
            utcDate = sdf.parse(utcTime);
        } 
        catch (ParseException e) 
        {
            e.printStackTrace();
        }
        sdf.setTimeZone(TimeZone.getDefault());
        String localTime = sdf.format(utcDate.getTime());

        return localTime;
    }
	
	
	public static void main(String[] args)
	{
		StringBuffer currentTime = new StringBuffer();
		
		String deviceID = null;
		
		String flag = null;
		
		String dimension = null;
		
		String dimension_flag = null;
		
		String longitude = null;
		
		String longitude_flag = null;
		
		String clientInputStr = "ID001$GPRMC,115656.00,A,3200.299502,N,11845.584927,E,0.0,181.9,030618,4.7,W,A*21";
		
		String[] reg_gpsInfo = clientInputStr.split(",");
		
		//解析数据 time
		
		deviceID = reg_gpsInfo[0].substring(0, reg_gpsInfo[0].indexOf("$"));
		
		currentTime.append("20").append(reg_gpsInfo[9].substring(4))
		   .append(reg_gpsInfo[9].substring(2, 4))
		   .append(reg_gpsInfo[9].substring(0, 2)).append("")
		   .append(reg_gpsInfo[1].subSequence(0, reg_gpsInfo[1].indexOf(".")));

		flag = reg_gpsInfo[2];
		
		//经度
		//reg_gpsInfo[3] = "3200.279258584085";
		dimension = String.valueOf((int)Double.parseDouble(reg_gpsInfo[3]) / 100 + Double.parseDouble(String.format("%.8f", Double.parseDouble(String.format("%.6f",Double.parseDouble(reg_gpsInfo[3]) % 100 ))/60)));
		
		dimension_flag = reg_gpsInfo[4];
		
		//经度
		//reg_gpsInfo[5] = "11845.590382643672";
		longitude = String.valueOf((int)Double.parseDouble(reg_gpsInfo[5]) / 100 + Double.parseDouble(String.format("%.11f", Double.parseDouble(String.format("%.6f",Double.parseDouble(reg_gpsInfo[5]) % 100 ))/60)));
		
		longitude_flag = reg_gpsInfo[6];
		
		System.out.println(currentTime.toString()+";"+deviceID+";" + flag + ";" + longitude + ";" + longitude_flag + ";" + dimension + ";" + dimension_flag + ";" );
		
		System.out.println(utcToLocal("20180603115656"));
		
		
	}

}
