package com.vms.thread;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vms.service.VehicleService;

public class HandlerThread implements Runnable 
{

	private static final Logger LOGGER = LoggerFactory.getLogger (HandlerThread.class);
	
    private VehicleService vehicleService;
	
	public Socket socket;

	public HandlerThread(Socket socket,VehicleService vehicleService1) 
	{
		this.socket = socket;
		vehicleService = vehicleService1;
	}
	
	public HandlerThread() 
	{
	}

	public static BufferedReader getReader(Socket socket) throws IOException 
	{
		return new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}

	public static PrintWriter getWriter(Socket socket) throws IOException 
	{
		return new PrintWriter(socket.getOutputStream(),true);
	}

	@Override
	public void run() 
	{
		try 
		{
			
			StringBuffer currentTime = new StringBuffer();
			
			String deviceID = null;
			
			String flag = null;
			
			String dimension = null;
			
			String dimension_flag = null;
			
			String longitude = null;
			
			String longitude_flag = null;

			BufferedReader input = getReader(socket);

			PrintWriter out = getWriter(socket);
			
			String clientInputStr = input.readLine();
			
			String[] reg_gpsInfo = clientInputStr.split(",");
			
			//解析数据 time
			
			deviceID = reg_gpsInfo[0].substring(5);
			
			currentTime.append("20").append(reg_gpsInfo[9].substring(4))
			   .append(reg_gpsInfo[9].substring(2, 4))
			   .append(reg_gpsInfo[9].substring(0, 2)).append("")
			   .append(reg_gpsInfo[1].subSequence(0, reg_gpsInfo[1].indexOf(".")));

			flag = reg_gpsInfo[2];
			
			//经度
			
			dimension = String.valueOf((int)Double.parseDouble(reg_gpsInfo[3]) / 100 + ((Double.parseDouble(reg_gpsInfo[3]) / 100) % 1)/60);
			
			dimension_flag = reg_gpsInfo[4];
			
			//经度
			longitude = String.valueOf((int)Double.parseDouble(reg_gpsInfo[5]) / 100 + ((Double.parseDouble(reg_gpsInfo[5]) / 100) % 1)/60);
			
			longitude_flag = reg_gpsInfo[6];
			

			vehicleService.updateVehicleInfo(deviceID,flag,dimension,dimension_flag,longitude,longitude_flag,currentTime.toString());
			
			out.close();
			input.close();

		} catch (IOException e) 
		{
			e.printStackTrace();
		}

		finally 
		{
			try 
			{
				if (socket != null)
					socket.close();

			} catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	
	public static void main(String[] args)
	{
		StringBuffer currentTime = new StringBuffer();
		
		String deviceID = null;
		
		String flag = null;
		
		String dimension = null;
		
		String dimension_flag = null;
		
		String longitude = null;
		
		String longitude_flag = null;
		
		String clientInputStr = "#GPMS123,083640.00,A,3637.2759,N/S,11700.56,E/W,0.0,0.0,200618";
		
		String[] reg_gpsInfo = clientInputStr.split(",");
		
		//解析数据 time
		
		deviceID = reg_gpsInfo[0].substring(5);
		
		currentTime.append("20").append(reg_gpsInfo[9].substring(4))
				   .append(reg_gpsInfo[9].substring(2, 4))
				   .append(reg_gpsInfo[9].substring(0, 2)).append("")
				   .append(reg_gpsInfo[1].subSequence(0, reg_gpsInfo[1].indexOf(".")-1));

		flag = reg_gpsInfo[2];
		
		//经度
		
		dimension = String.valueOf((int)Double.parseDouble(reg_gpsInfo[3]) / 100 + ((Double.parseDouble(reg_gpsInfo[3]) / 100) % 1)/60);
		
		dimension_flag = reg_gpsInfo[4];
		
		//经度
		longitude = String.valueOf((int)Double.parseDouble(reg_gpsInfo[5]) / 100 + ((Double.parseDouble(reg_gpsInfo[5]) / 100) % 1)/60);
		
		longitude_flag = reg_gpsInfo[6];
		
		System.out.println(currentTime.toString()+";"+deviceID+";" + flag + ";" + longitude + ";" + longitude_flag + ";" + dimension + ";" + dimension_flag + ";" );
	}

}
