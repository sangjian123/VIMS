package com.vms.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletResponse;

/**
 * @Title: DownUtil.java
 * @Description:文件下载工具类
 * @author ChoviWu
 */
public class DownloadUtils
{
    
    /**
     *
     * @Description: 下载的模板
     * @param @param response
     * @param @param path 路径名
     * @param @param name 模板名称
     * @param @throws IOException
     * @return void
     * @throws
     */
    public static void download(HttpServletResponse response, String path, String name) throws IOException
    {
        
        Long fileLength = new File(path).length();// 文件的长度
        System.out.println("文件的长度：" + fileLength);
        if(fileLength != 0)
        {
            response.reset();
            response.setContentType("application/octet-stream;charset=utf-8"); // 改成输出excel文件
            try
            {
                response.setHeader("Content-disposition", "attachment; filename="
                    + new String(name.getBytes("utf-8"), "ISO8859-1"));
                response.setHeader("Content-Length", String.valueOf(fileLength));
            }
            catch (UnsupportedEncodingException e)
            {
                e.printStackTrace();
            }
            BufferedInputStream bis = null;
            BufferedOutputStream bos = null;
            FileInputStream fis = null;
            try
            {
                fis = new FileInputStream(path);
                bis = new BufferedInputStream(fis);
                // 输出流
                bos = new BufferedOutputStream(response.getOutputStream());
                byte[] buff = new byte[2048];
                int bytesread;
                // 写文件
                while(-1 != (bytesread = bis.read(buff, 0, buff.length)))
                {
                    bos.write(buff, 0, bytesread);
                }
                fis.close();
                
            }
            catch (FileNotFoundException e)
            {
                System.out.println("File is Not Exsist!");
                
            }
        }
    }
}