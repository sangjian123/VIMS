package com.vms.utils;

import java.util.HashSet;
import java.util.Set;

import com.vms.constant.ConstantCode;

public class FlowTypeUtils
{
    private static Set<String> addSet = new HashSet<String>();
    
    private static Set<String> updateSet = new HashSet<String>();
    
    private static Set<String> delSet = new HashSet<String>();
    static
    {
        addSet.add("HVInstallation");
        addSet.add("LVNon-residentInstallation");
        addSet.add("ResidentInstallation");
        addSet.add("AppResidentNewInstall");
        
        updateSet.add("AccountTransfer");
        updateSet.add("CapacityChange");
        updateSet.add("CategoryChange");
        updateSet.add("PauseTran");
        updateSet.add("ResumeTran");
        updateSet.add("Rename");
        updateSet.add("MeteringDeviceFault");
        
        delSet.add("AccountDeactivation");
    }
    
    public static boolean isNew(String flowName)
    {
        if(addSet.contains(flowName))
        {
            return true;
        }
        return false;
    }
    
    public static boolean isUpdate(String flowName)
    {
        if(updateSet.contains(flowName))
        {
            return true;
        }
        return false;
    }
    
    public static boolean isDel(String flowName)
    {
        if(delSet.contains(flowName))
        {
            return true;
        }
        return false;
    }
    
    public static boolean isCrmFlow(String flowName)
    {
        if(addSet.contains(flowName) || updateSet.contains(flowName) || delSet.contains(flowName))
        {
            return true;
        }
        return false;
    }
    
    public static String getFlowType(String flowName)
    {
        String rev = ConstantCode.STRING_4;
        if(isNew(flowName))
        {
            rev = ConstantCode.STRING_1;
        }
        else if(isUpdate(flowName))
        {
            rev = ConstantCode.STRING_2;
        }
        else if(isDel(flowName))
        {
            rev = ConstantCode.STRING_3;
        }
        return rev;
    }
}
