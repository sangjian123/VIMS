package com.vms.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExportExecl
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ExportExecl.class);
    
    public static <T> byte[] createExl(List<T> assetList, String[] cellNames, String[] titles)
    {
        ByteArrayOutputStream os = null;
        HSSFWorkbook wb = null;
        //logger.info("*****************创建Excel  Step 1******************************");
        try
        {
            List<List<T>> lists = splitList(assetList);
            //创建HSSFWorkbook对象(excel的文档对象)
            wb = new HSSFWorkbook();
            List<T> list = null;
            for(int i = 0; i < lists.size(); i++)
            {
                //建立新的sheet对象（excel的表单）
                HSSFSheet sheet = wb.createSheet("Sheet" + (i + 1));
                //在sheet里创建第一行，参数为行索引(excel的行)，可以是0～65535之间的任何一个
                HSSFRow row1 = sheet.createRow(0);
                //设置行高
                row1.setHeightInPoints(20);
                HSSFCellStyle styleHead = wb.createCellStyle();
                styleHead.setAlignment((short) 2);
                HSSFFont headFont = wb.createFont();
                headFont.setBoldweight((short) 700);
                headFont.setFontName("宋体");
                headFont.setFontHeightInPoints((short) 10);
                styleHead.setFont(headFont);
                styleHead.setAlignment((short) 0);
                styleHead.setFillPattern((short) 1);
                styleHead.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
                styleHead.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
                //创建单元格（excel的单元格，参数为列索引，可以是0～255之间的任何一个
                for(int f = 0; f < titles.length ; f++)
                {
                    HSSFCell cell1 = row1.createCell(f);
                    //设置单元格宽度
                    sheet.setColumnWidth(cell1.getColumnIndex(), 100 * 60);
                    //设置标题名称
                    //logger.info(titles[f]);
                    if(titles[f].indexOf(",") < 0)
                    {
                        cell1.setCellValue(titles[f]);
                        
                    }
                    else
                    {
                        String[] codes = titles[f].split(",");
                        String[] args = new String[codes.length - 1];
                        for(int s = 1; s < codes.length; s++)
                        {
                            args[s - 1] = codes[s];
                        }
                        
                        cell1.setCellValue(codes[0]);
                    }
                    //logger.info("*****************创建Excel  Step 2.0******************************");
                    cell1.setCellStyle(styleHead);
                    //logger.info("*****************创建Excel  Step 2.1******************************");
                }

                list = lists.get(i);
                //在sheet里创建第二行
                //logger.info("*****************创建Excel  Step 2.2******************************");
                for(int j = 0; j < list.size(); j++)
                {
                    HSSFRow row = sheet.createRow(j + 1);
                    Class<? extends Object> classType = list.get(j).getClass();
                    for(int t = 0; t < cellNames.length; t++)
                    {
                        String methodName = "get" + cellNames[t].toLowerCase();
                        Method[] methods = classType.getDeclaredMethods();
                        Method m1 = null;
                        for(int m = 0; m < methods.length; m++)
                        {
                            if(methods[m].getName().toLowerCase().equals(methodName))
                            {
                                m1 = classType.getDeclaredMethod(methods[m].getName());
                            }
                        }
                        Object obj = m1.invoke(list.get(j));
                        HSSFCell cell = row.createCell(t);
                        if(obj != null)
                        {
                            cell.setCellValue(obj.toString());
                        }
                    }
                }
            }
            os = new ByteArrayOutputStream();
            wb.write(os);
            byte[] b = os.toByteArray();
            
			//logger.info("*****************创建Excel Step 3******************************");
			//logger.info(new String(b));
            
            return b;
        }
        catch (Exception e)
        {

            return new byte[0];
        }
        finally
        {
            if(os != null)
            {
                try
                {
                    os.close();
                }
                catch (IOException e)
                {
                }
            }
            if(wb != null)
            {
                try
                {
                    wb.close();
                }
                catch (IOException e)
                {
                }
            }
        }
    }
    
    /**
     *  行业用电 到出，数据为null时返回   --
     *  标题 时从前台传过来的， 没有 经过国际化转换
     *  专用
     * @param assetList
     * @param cellNames
     * @param titles
     * @return
     */
    public static <T> byte[] createExlInd(List<T> assetList, String[] cellNames, String[] titles)
    {
        ByteArrayOutputStream os = null;
        HSSFWorkbook wb = null;
        try
        {
            List<List<T>> lists = splitList(assetList);
            //创建HSSFWorkbook对象(excel的文档对象)
            wb = new HSSFWorkbook();
            List<T> list = null;
            for(int i = 0; i < lists.size(); i++)
            {
                //建立新的sheet对象（excel的表单）
                HSSFSheet sheet = wb.createSheet("Sheet" + (i + 1));
                //在sheet里创建第一行，参数为行索引(excel的行)，可以是0～65535之间的任何一个
                HSSFRow row1 = sheet.createRow(0);
                //设置行高
                row1.setHeightInPoints(20);
                HSSFCellStyle styleHead = wb.createCellStyle();
                styleHead.setAlignment((short) 2);
                HSSFFont headFont = wb.createFont();
                headFont.setBoldweight((short) 700);
                headFont.setFontName("宋体");
                headFont.setFontHeightInPoints((short) 10);
                styleHead.setFont(headFont);
                styleHead.setAlignment((short) 0);
                styleHead.setFillPattern((short) 1);
                styleHead.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
                styleHead.setFillForegroundColor(HSSFColor.PALE_BLUE.index);
                //创建单元格（excel的单元格，参数为列索引，可以是0～255之间的任何一个
                for(int f = 0; f < titles.length; f++)
                {
                    HSSFCell cell1 = row1.createCell(f);
                    //设置单元格宽度
                    sheet.setColumnWidth(cell1.getColumnIndex(), 100 * 60);
                    //设置标题名称
                    // cell1.setCellValue(I18nUtils.getI18nMsg(titles[f]));
                    cell1.setCellValue(titles[f]);
                    
                    cell1.setCellStyle(styleHead);
                }
                list = lists.get(i);
                //在sheet里创建第二行
                for(int j = 0; j < list.size(); j++)
                {
                    HSSFRow row = sheet.createRow(j + 1);
                    Class<? extends Object> classType = list.get(j).getClass();
                    for(int t = 0; t < cellNames.length; t++)
                    {
                        String methodName = "get" + cellNames[t].toLowerCase();
                        Method[] methods = classType.getDeclaredMethods();
                        Method m1 = null;
                        for(int m = 0; m < methods.length; m++)
                        {
                            if(methods[m].getName().toLowerCase().equals(methodName))
                            {
                                m1 = classType.getDeclaredMethod(methods[m].getName());
                            }
                        }
                        Object obj = m1.invoke(list.get(j));
                        HSSFCell cell = row.createCell(t);
                        if(obj != null)
                        {
                            cell.setCellValue(obj.toString());
                        }
                        else
                        {
                            cell.setCellValue("-");
                        }
                    }
                }
            }
            os = new ByteArrayOutputStream();
            wb.write(os);
            byte[] b = os.toByteArray();
            return b;
        }
        catch (Exception e)
        {
            LOGGER.error("导出excel error", e);
            return new byte[0];
        }
        finally
        {
            if(os != null)
            {
                try
                {
                    os.close();
                }
                catch (IOException e)
                {
                    LOGGER.error("导出excel os close error", e);
                }
            }
            if(wb != null)
            {
                try
                {
                    wb.close();
                }
                catch (IOException e)
                {
                    LOGGER.error("导出excel wb close error", e);
                }
            }
        }
    }
    
    private static <T> List<List<T>> splitList(List<T> assetList)
    {
        List<List<T>> lists = new ArrayList<List<T>>();
        int length = assetList.size();
        int listSize = length % 10000 == 0 ? length / 10000 : length / 10000 + 1;
        for(int i = 0; i < listSize; i++)
        {
            List<T> aList = new ArrayList<T>();
            for(int j = i * 10000; j <= 10000 * (i + 1) - 1; j++)
            {
                if(j <= length - 1)
                {
                    aList.add(assetList.get(j));
                }
            }
            lists.add(aList);
        }
        return lists;
    }
    
}
