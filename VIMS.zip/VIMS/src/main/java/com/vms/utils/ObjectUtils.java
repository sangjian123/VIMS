package com.vms.utils;


import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.vms.constant.GeneralConstant;

public final class ObjectUtils {
    private static ThreadLocal<Map<String, String>> maps = new ThreadLocal<Map<String, String>>();

    /**
     * <默认构造函数>
     */
    private ObjectUtils() {
    }

    /**
     *  将key=value,key2=value2,...转换为Map
     * @param params 要分割的参数
     * @return 分割后的Map
     * @author 王伟
     */
    public static Map<String, String> parseParam(String params) {
        return parseParam(params, ',', '=');
    }

    /**
     * 奇数是key紧邻的参数是value，参数的个数必须为偶数
     * @param key key
     * @param params params
     * @return 参数Map
     * @author 王伟
     */
    public static Map<String, String> parseParam(String key, Object... params) {
        Map<String, String> queryParamMap = maps.get();
        if (null == queryParamMap) {
            queryParamMap = new HashMap<String, String>();
            maps.set(queryParamMap);
        }
        else {
            queryParamMap.clear();
        }

        if (GeneralUtils.isNotNullOrZeroLength(key)) {
            if (params != null && (params.length % GeneralConstant.NUM_2 == GeneralConstant.NUM_1)) {
                String value;
                for (int i = GeneralConstant.NUM_0; i < params.length; i++) {
                    if (i == GeneralConstant.NUM_0) {
                        value = String.valueOf(params[i]);
                    }
                    else {
                        key = String.valueOf(params[i]);
                        value = String.valueOf(params[++i]);

                    }
                    queryParamMap.put(key, value);
                }
            }
            else {
                queryParamMap.put(key, null);
            }
        }

        return queryParamMap;
    }

    /**
     *  将key=value,key2=value2,...转换为Map
     * @param params params
     * @param paramSplit paramSplit
     * @param valueSplit valueSplit
     * @return 分割后的Map
     * @author 王伟
     */
    public static Map<String, String> parseParam(String params, char paramSplit, char valueSplit) {
        Map<String, String> paramMap = maps.get();
        if (null == paramMap) {
            paramMap = new HashMap<String, String>();
            maps.set(paramMap);
        }
        else {
            paramMap.clear();
        }

        if (GeneralUtils.isNotNullOrZeroLength(params)) {
            String[] paramArray = StringUtils.split(params, paramSplit);
            for (String param : paramArray) {
                String[] entry = StringUtils.splitPreserveAllTokens(param, valueSplit);
                if (GeneralConstant.NUM_1 == entry.length) {
                    paramMap.put(entry[GeneralConstant.NUM_0], null);
                }
                else {
                    paramMap.put(entry[GeneralConstant.NUM_0], entry[GeneralConstant.NUM_1]);
                }
            }
        }

        return paramMap;
    }
}

