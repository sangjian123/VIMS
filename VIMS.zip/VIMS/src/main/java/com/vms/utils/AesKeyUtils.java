package com.vms.utils;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vms.constant.GeneralConstant;

/**
 * Aes加密工具类
 *
 * @author tfl
 * @date 2016年12月5日 下午3:10:42
 */
public class AesKeyUtils
{
    private static final Logger LOGGER = LoggerFactory.getLogger(AesKeyUtils.class);
    
    /**
     * 加密算法是AES
     */
    private static final String ALGORITHM = "AES";
    
    private static final String SECURE_ALGORITHM = "SHA1PRNG";
    
    private static final int KEY_SIZE = 128;
    
    /**
     * cookie中url加密私钥
     */
    private static final String ENCRYPT_COOKIE_URL_KEY = "ami@&**@@@@";
    
    /**
     * 加密
     *
     * @param content
     *            待加密内容
     * @return
     */
    public static String encrypt(String content, String keyStr)
    {
        try
        {
            KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);
            SecureRandom secureRandom = SecureRandom.getInstance(SECURE_ALGORITHM);
            secureRandom.setSeed(keyStr.getBytes(GeneralConstant.CHARACTER_CODING));
            kgen.init(KEY_SIZE, secureRandom);
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM);// 创建密码器
            byte[] byteContent = content.getBytes(GeneralConstant.CHARACTER_CODING);
            cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化
            byte[] result = cipher.doFinal(byteContent);
            return bytes2Hex(result); // 加密
        }
        catch (Exception e)
        {
            LOGGER.error("AesKeyUtils.encrypt Error : ", e);
        }
        return null;
    }
    
    /**
     * 解密
     * 
     * @param content
     *            待解密内容
     * @return
     */
    public static String decrypt(String content, String keyStr)
    {
        try
        {
            KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);
            SecureRandom secureRandom = SecureRandom.getInstance(SECURE_ALGORITHM);
            secureRandom.setSeed(keyStr.getBytes(GeneralConstant.CHARACTER_CODING));
            kgen.init(KEY_SIZE, secureRandom);
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALGORITHM);// 创建密码器
            cipher.init(Cipher.DECRYPT_MODE, key);// 初始化
            byte[] result = cipher.doFinal(hexStr2Byte(content));
            return new String(result, GeneralConstant.CHARACTER_CODING); // 加密
        }
        catch (Exception e)
        {
            LOGGER.error("AesKeyUtils.decrypt Error : " + e);
        }
        return null;
    }
    
    public static void main(String[] args)
    {
        System.out
            .println(decrypt(
                "9a839afe443ba3e99252640ff4536dfdf1e9c75e9a93efe219dc64a9da2d142abf3249c3b8f6b23643d1483b82ef8cd8096ed41dcdf4eb9c5e258d68893f27c6288f7ca724f79c64ed088306ddd53bd82f4c8b555b227812672ce2479bad9f6ceec39509931e58db05b12110ff45acdc7a5ecc293c814698381e1890a1dbcdb5abeb0ed7250a6a28a62678aeec88d0567c9c9f7d3c6a62c30f87938225b1001ad63ca899fa3f8822ea9575a572177114a942f14f78ddbaa1715706326890fdb481f7664219d8ad1a38a25942bf98461714a5b08dd3a7fc7ab67229c7a60489810a1b66f1369927ef3082cd232cbae2e53f3c6bac37c16a369e3953b3ef019c55b22e0f37e09559db0951dbcccd4458eaa6376b03d1bf02828895c2510c697a7a0e5e5cdb35cbacde212b7662558dcd00af965a9abc40e337c27dadb6a9192f547ca2aa90af5a1f6df6281aa5b502e2a54b610a15196528cc3ad4bd5147f8e78945f633cdef605857286da2aec2f639d84c2dc0b63b22dc8cc104f1cae0125f6eed96b9b3fe4945bc3a303dea9e055d71584f56de259ae2dd3bacafb8e5b80ff2e927215b0ce0e20b69f24f7f8037a8f4931e95330f43353088fa167b30d3e13166edf2d6e603949b946c7a697878f1ce4f5954ae362a02f454a7a2d50dd36b420aba9b3599172612136f338a78294bc964e807c3ec69414f2e5c32be9d1b6828c1e104ef347918b23440b279cbc30d318e6675c6c9e835efd9b419d39081068c191e019a7870c0259583b174354b377812f86b7923514b4dc8e3f0b71275a2e8",
                "YW1pQDE2IU5KJg=="));
        
        System.out
            .println(encrypt(
                "/substation/insertGsubs,/mainTransformer/addMTran,/gtline/doAddGTline,/gmline/addMline,/line/addLine,/gtg/saveOrUpdate,/gtrans/saveOrUpdate,/mainTransformer/addMTran,/gridExport/importGridData,/gridExport/exportGridData,/gridExport/gridTemplateDownload,/assetarchive/addMeter,/assetarchive/addMeterByImport,/findStockManagerController/doPutintoStock,/findStockManagerController/doPutintoStockAll,/lowInstallApp/saveOrUpdateAppInfo,/highInstallApp/saveOrUpdateAppInfo,/readingPlan/insetNormalPlan,/archivesMaintenance/addUserInfo,/archivesElectricPlan/addElectricPlan",
                "YW1pQDE2IU5KJg=="));
    }
    
    /**
     * 转为16进制
     *
     * @param bts
     *            加密后内容
     * @return
     */
    private static String bytes2Hex(byte[] bts)
    {
        StringBuilder des = new StringBuilder();
        String tmp = null;
        for(int i = 0; i < bts.length; i++)
        {
            tmp = Integer.toHexString(bts[i] & 0xFF);
            if(tmp.length() == 1)
            {
                des.append("0");
            }
            des.append(tmp);
        }
        return des.toString();
    }
    
    /**将16进制转换为二进制 
     * @param hexStr 
     * @return 
     */
    public static byte[] hexStr2Byte(String hexStr)
    {
        if(hexStr.length() < 1)
            return null;
        byte[] result = new byte[hexStr.length() / 2];
        for(int i = 0; i < hexStr.length() / 2; i++)
        {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte) (high * 16 + low);
        }
        return result;
    }
    
    /**
     * 给保存在cookie中的url加密
     *
     * @param url
     *            需要加密的url
     * @return 加密后密文
     */
    public static String encryptCookieURL(String url)
    {
        if(StringUtils.isBlank(url))
        {
            return url;
        }
        try
        {
            byte[] urlBytes = url.getBytes(GeneralConstant.CHARACTER_CODING);
            SecureRandom secureRandom = SecureRandom.getInstance(SECURE_ALGORITHM);
            secureRandom.setSeed(ENCRYPT_COOKIE_URL_KEY.getBytes(GeneralConstant.CHARACTER_CODING));
            
            KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);
            kgen.init(KEY_SIZE, secureRandom);
            
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALGORITHM);
            
            // 创建密码器
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] result = cipher.doFinal(urlBytes);
            
            return new String(Base64.encodeBase64(result), GeneralConstant.CHARACTER_CODING);
        }
        catch (NoSuchAlgorithmException e)
        {
            LOGGER.error("AesKeyUtils.encryptCookieURL Error : ", e);
        }
        catch (NoSuchPaddingException e)
        {
            LOGGER.error("AesKeyUtils.encryptCookieURL Error : ", e);
        }
        catch (InvalidKeyException e)
        {
            LOGGER.error("AesKeyUtils.encryptCookieURL Error : ", e);
        }
        catch (BadPaddingException e)
        {
            LOGGER.error("AesKeyUtils.encryptCookieURL Error : ", e);
        }
        catch (IllegalBlockSizeException e)
        {
            LOGGER.error("AesKeyUtils.encryptCookieURL Error : ", e);
        }
        catch (UnsupportedEncodingException e)
        {
            LOGGER.error("AesKeyUtils.encryptCookieURL Error : ", e);
        }
        return null;
    }
    
    /**
     * 给加密后的cookie中的url解密
     *
     * @param code
     *            加密后的url
     * @return 解密后的url
     */
    public static String decryptCookieURL(String code)
    {
        if(StringUtils.isBlank(code))
        {
            return code;
        }
        try
        {
            
            // 进行Base64解密
            byte[] encryptBytes = Base64.decodeBase64(code.getBytes(GeneralConstant.CHARACTER_CODING));
            SecureRandom secureRandom = SecureRandom.getInstance(SECURE_ALGORITHM);
            secureRandom.setSeed(ENCRYPT_COOKIE_URL_KEY.getBytes(GeneralConstant.CHARACTER_CODING));
            
            KeyGenerator kgen = KeyGenerator.getInstance(ALGORITHM);
            kgen.init(KEY_SIZE, secureRandom);
            
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, ALGORITHM);
            
            // 创建密码器
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] result = cipher.doFinal(encryptBytes);
            
            return new String(result, GeneralConstant.CHARACTER_CODING);
        }
        catch (NoSuchAlgorithmException e)
        {
            LOGGER.error("AesKeyUtils.decryptCookieURL Error : ", e);
        }
        catch (NoSuchPaddingException e)
        {
            LOGGER.error("AesKeyUtils.decryptCookieURL Error : ", e);
        }
        catch (InvalidKeyException e)
        {
            LOGGER.error("AesKeyUtils.decryptCookieURL Error : ", e);
        }
        catch (IllegalBlockSizeException e)
        {
            LOGGER.error("AesKeyUtils.decryptCookieURL Error : ", e);
        }
        catch (BadPaddingException e)
        {
            LOGGER.error("AesKeyUtils.decryptCookieURL Error : ", e);
        }
        catch (UnsupportedEncodingException e)
        {
            LOGGER.error("AesKeyUtils.decryptCookieURL Error : ", e);
        }
        
        return null;
    }
    
}